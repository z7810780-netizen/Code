# INSTRUCTIONS FOR CODESPACES / CURSOR / GITHUB COPILOT / AI ASSISTANTS

If you are an AI Assistant or automated build agent debugging or building this Android project in GitHub Codespaces or VS Code:

## 1. Project Type
This is a standard **Android Gradle Project** written in Kotlin and HTML5/JS.
- **Root Build File**: `build.gradle.kts`
- **App Module**: `app/build.gradle.kts`
- **Gradle Wrapper**: `gradlew` and `gradlew.bat`
- **Native Android Activity**: `app/src/main/java/com/myselfsinghcodeeditor/MainActivity.kt`
- **Web Application Assets**: `app/src/main/assets/index.html`

## 2. How to Build the Debug APK
Execute the following commands in the bash terminal:
```bash
chmod +x gradlew
./gradlew assembleDebug --stacktrace
```

If Java SDK or Android SDK is missing in Codespaces, run:
```bash
chmod +x build-apk-codespace.sh
./build-apk-codespace.sh
```

## 3. Output Location of Compiled APK
Upon successful completion of `./gradlew assembleDebug`, the compiled APK will be at:
`app/build/outputs/apk/debug/app-debug.apk`

## 4. Debugging & Common Issues
- **Permission Denied on gradlew**: Run `chmod +x gradlew`
- **JAVA_HOME / JDK Error**: Ensure Java 17 is installed (`openjdk-17-jdk`).
- **Offline Assets**: The entire IDE web application is packaged in `app/src/main/assets/index.html`. It is loaded by `MainActivity.kt` via `webView.loadUrl("file:///android_asset/index.html")`.
