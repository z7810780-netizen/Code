# GitHub Codespaces Quick Build Guide

To build the `app-debug.apk` in GitHub Codespaces:

1. Open Terminal in Codespaces (`Ctrl + ` ` or `Cmd + ` `).
2. Run:
   ```bash
   chmod +x build-apk-codespace.sh
   ./build-apk-codespace.sh
   ```
3. Download the generated APK from:
   `app/build/outputs/apk/debug/app-debug.apk`
