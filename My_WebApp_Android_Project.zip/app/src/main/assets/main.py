import sys

def main():
    print("Welcome to MYself_EDITOR - Python Runner!")
    languages = ["Kotlin", "Java", "Python", "JavaScript", "Rust", "C++"]
    print(f"Supported mobile IDE languages: {', '.join(languages)}")

if __name__ == "__main__":
    main()