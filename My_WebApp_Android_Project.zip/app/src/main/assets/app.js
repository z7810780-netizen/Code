// Interactive JavaScript logic
let count = 0;
const btn = document.getElementById('counterBtn');

if (btn) {
  btn.addEventListener('click', () => {
    count++;
    btn.textContent = `Clicks: ${count}`;
    console.log(`[MYself_EDITOR] Counter updated to ${count}`);
  });
}

console.log('MYself_EDITOR Web Preview initialized.');