#!/bin/bash
set -e

echo "====================================================="
echo " Setting up Android SDK & Building MYself_EDITOR APK"
echo "====================================================="

export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    echo ">> Installing Android SDK command-line tools..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq openjdk-17-jdk wget unzip

    mkdir -p "$ANDROID_HOME/cmdline-tools"
    cd "$ANDROID_HOME/cmdline-tools"
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmdline-tools.zip
    unzip -q cmdline-tools.zip
    rm -f cmdline-tools.zip
    mv cmdline-tools latest 2>/dev/null || true
fi

export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

echo ">> Accepting Android SDK licenses and installing Android 34 build-tools..."
yes | sdkmanager --licenses > /dev/null 2>&1 || true
sdkmanager --install "platforms;android-34" "build-tools;34.0.0" "platform-tools" > /dev/null 2>&1

cd "$(dirname "$0")"

echo "sdk.dir=$ANDROID_HOME" > local.properties
chmod +x gradlew

echo ">> Compiling Android Debug APK..."
./gradlew assembleDebug

echo ""
echo "====================================================="
echo " ✅ APK BUILD SUCCESSFUL!"
echo " Output: app/build/outputs/apk/debug/app-debug.apk"
echo "====================================================="
