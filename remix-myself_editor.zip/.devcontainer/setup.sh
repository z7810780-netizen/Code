#!/usr/bin/env bash
set -e

echo "=== Setting up Android SDK environment for MYself_EDITOR ==="

# Set Android Home
export ANDROID_HOME="/workspaces/android-sdk"
export ANDROID_SDK_ROOT="/workspaces/android-sdk"
mkdir -p "$ANDROID_HOME/cmdline-tools"

# Download official command-line tools if not present
if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    echo "Downloading Android commandlinetools..."
    curl -sS -o /tmp/cmdline-tools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
    unzip -q /tmp/cmdline-tools.zip -d "$ANDROID_HOME/cmdline-tools"
    mv "$ANDROID_HOME/cmdline-tools/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
    rm /tmp/cmdline-tools.zip
fi

export PATH="$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools"

# Accept licenses
echo "Accepting Android SDK licenses..."
yes | sdkmanager --licenses > /dev/null 2>&1 || true

# Install required SDK platforms and build tools
echo "Installing Android SDK packages (platforms;android-34, build-tools;34.0.0)..."
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0"

# Make gradlew executable
chmod +x ./gradlew 2>/dev/null || true

echo "=== Android build environment ready! ==="
echo "You can now run: ./gradlew assembleDebug"
