# ProGuard rules for MYself_EDITOR
-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.myselfsinghcodeeditor.** { *; }
