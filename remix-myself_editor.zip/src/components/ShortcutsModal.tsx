import React from 'react';
import { Keyboard, X } from 'lucide-react';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'Ctrl + S', desc: 'Save current active file' },
    { key: 'Ctrl + O', desc: 'Quick open file modal' },
    { key: 'Ctrl + N', desc: 'Create new file' },
    { key: 'Ctrl + W', desc: 'Close current active tab' },
    { key: 'Ctrl + F', desc: 'Find in document' },
    { key: 'Ctrl + H', desc: 'Find and Replace' },
    { key: 'Ctrl + G', desc: 'Go to specific line' },
    { key: 'Ctrl + Z', desc: 'Undo edit' },
    { key: 'Ctrl + Y', desc: 'Redo edit' },
    { key: 'Ctrl + /', desc: 'Toggle single-line comment' },
    { key: 'Ctrl + Enter', desc: 'Toggle Web Preview & Run' },
    { key: 'Ctrl + `', desc: 'Toggle Terminal panel' },
    { key: 'Tab', desc: 'Indent selection / Insert tab spaces' },
    { key: 'Shift + Tab', desc: 'Unindent selection' },
  ];

  return (
    <div
      id="shortcuts-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-150 p-4"
      onClick={onClose}
    >
      <div
        id="shortcuts-modal-content"
        className="w-full max-w-lg bg-zinc-900 border border-zinc-700/80 rounded-2xl shadow-2xl p-6 text-zinc-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-zinc-800">
          <div className="flex items-center gap-2 text-base font-bold text-white">
            <Keyboard className="w-5 h-5 text-cyan-400" />
            <span>Keyboard Shortcuts</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-[60vh] overflow-y-auto pr-1">
          {shortcuts.map((s, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-2 rounded-lg bg-zinc-950/60 border border-zinc-800/80"
            >
              <span className="text-xs text-zinc-400">{s.desc}</span>
              <kbd className="px-2 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-[11px] font-mono text-cyan-300 font-semibold shadow-xs">
                {s.key}
              </kbd>
            </div>
          ))}
        </div>

        <div className="mt-5 pt-3 border-t border-zinc-800 flex justify-between items-center text-xs text-zinc-400">
          <span>Physical & external Bluetooth keyboards fully supported</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg font-medium text-xs transition-colors"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
