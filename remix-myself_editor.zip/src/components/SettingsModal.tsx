import React from 'react';
import { Settings, X, Palette, Type, Sliders, ShieldCheck } from 'lucide-react';
import { EditorSettings, EditorTheme } from '../types';
import { THEMES } from '../utils/themes';

interface SettingsModalProps {
  isOpen: boolean;
  settings: EditorSettings;
  onUpdateSettings: (newSettings: Partial<EditorSettings>) => void;
  onReplaySplash: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  settings,
  onUpdateSettings,
  onReplaySplash,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="settings-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-150 p-4"
      onClick={onClose}
    >
      <div
        id="settings-modal-content"
        className="w-full max-w-xl bg-zinc-900 border border-zinc-700/80 rounded-2xl shadow-2xl p-6 text-zinc-200 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-zinc-800 shrink-0">
          <div className="flex items-center gap-2 text-base font-bold text-white">
            <Settings className="w-5 h-5 text-cyan-400" />
            <span>Editor Preferences & System Settings</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="space-y-6 overflow-y-auto pr-1">
          {/* Section 1: Appearance & Theme */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-wider mb-3">
              <Palette className="w-3.5 h-3.5" />
              <span>Theme & Appearance</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {Object.entries(THEMES).map(([themeKey, config]) => {
                const isSelected = settings.theme === themeKey;
                return (
                  <button
                    key={themeKey}
                    onClick={() => onUpdateSettings({ theme: themeKey as EditorTheme })}
                    className={`p-2.5 rounded-xl border text-left flex flex-col gap-1 transition-all ${
                      isSelected
                        ? 'border-cyan-500 bg-cyan-500/10 shadow-sm'
                        : 'border-zinc-800 bg-zinc-950/60 hover:border-zinc-700 hover:bg-zinc-800/40'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <div
                        className="w-3 h-3 rounded-full border border-white/20"
                        style={{ backgroundColor: config.accentColor }}
                      />
                      <span className="text-xs font-semibold text-white truncate">
                        {config.name}
                      </span>
                    </div>
                    <span className="text-[10px] text-zinc-400 capitalize">
                      {config.isDark ? 'Dark Mode' : 'Light Mode'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 2: Typography */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-wider mb-3">
              <Type className="w-3.5 h-3.5" />
              <span>Typography & Sizing</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-zinc-950/60 p-4 rounded-xl border border-zinc-800/80">
              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Font Size ({settings.fontSize}px)
                </label>
                <input
                  type="range"
                  min="11"
                  max="24"
                  step="1"
                  value={settings.fontSize}
                  onChange={(e) => onUpdateSettings({ fontSize: Number(e.target.value) })}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Font Family
                </label>
                <select
                  value={settings.fontFamily}
                  onChange={(e) => onUpdateSettings({ fontFamily: e.target.value })}
                  className="w-full bg-zinc-900 border border-zinc-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value='Consolas, "Courier New", monospace'>Consolas / Monospace</option>
                  <option value='"Fira Code", monospace'>Fira Code</option>
                  <option value='"JetBrains Mono", monospace'>JetBrains Mono</option>
                  <option value='"Source Code Pro", monospace'>Source Code Pro</option>
                  <option value='Menlo, Monaco, monospace'>Menlo / Monaco</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 3: Editor Behaviors */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-wider mb-3">
              <Sliders className="w-3.5 h-3.5" />
              <span>Editor Behavior & Formatting</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-zinc-950/60 p-4 rounded-xl border border-zinc-800/80">
              <label className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800/60 cursor-pointer hover:bg-zinc-800/50">
                <span className="text-xs text-zinc-300">Word Wrap</span>
                <input
                  type="checkbox"
                  checked={settings.wordWrap}
                  onChange={(e) => onUpdateSettings({ wordWrap: e.target.checked })}
                  className="accent-cyan-500 rounded cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800/60 cursor-pointer hover:bg-zinc-800/50">
                <span className="text-xs text-zinc-300">Auto Close Brackets</span>
                <input
                  type="checkbox"
                  checked={settings.autoCloseBrackets}
                  onChange={(e) => onUpdateSettings({ autoCloseBrackets: e.target.checked })}
                  className="accent-cyan-500 rounded cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800/60 cursor-pointer hover:bg-zinc-800/50">
                <span className="text-xs text-zinc-300">Auto Close Quotes</span>
                <input
                  type="checkbox"
                  checked={settings.autoCloseQuotes}
                  onChange={(e) => onUpdateSettings({ autoCloseQuotes: e.target.checked })}
                  className="accent-cyan-500 rounded cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800/60 cursor-pointer hover:bg-zinc-800/50">
                <span className="text-xs text-zinc-300">Auto Indent</span>
                <input
                  type="checkbox"
                  checked={settings.autoIndent}
                  onChange={(e) => onUpdateSettings({ autoIndent: e.target.checked })}
                  className="accent-cyan-500 rounded cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800/60 cursor-pointer hover:bg-zinc-800/50">
                <span className="text-xs text-zinc-300">Show Line Numbers</span>
                <input
                  type="checkbox"
                  checked={settings.showLineNumbers}
                  onChange={(e) => onUpdateSettings({ showLineNumbers: e.target.checked })}
                  className="accent-cyan-500 rounded cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800/60 cursor-pointer hover:bg-zinc-800/50">
                <span className="text-xs text-zinc-300">Highlight Active Line</span>
                <input
                  type="checkbox"
                  checked={settings.highlightActiveLine}
                  onChange={(e) => onUpdateSettings({ highlightActiveLine: e.target.checked })}
                  className="accent-cyan-500 rounded cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800/60 cursor-pointer hover:bg-zinc-800/50">
                <span className="text-xs text-zinc-300">Auto-Save Changes</span>
                <input
                  type="checkbox"
                  checked={settings.autoSave}
                  onChange={(e) => onUpdateSettings({ autoSave: e.target.checked })}
                  className="accent-cyan-500 rounded cursor-pointer"
                />
              </label>

              <div className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/60 border border-zinc-800/60">
                <span className="text-xs text-zinc-300">Tab Size</span>
                <select
                  value={settings.tabSize}
                  onChange={(e) => onUpdateSettings({ tabSize: Number(e.target.value) })}
                  className="bg-zinc-950 border border-zinc-700 rounded px-2 py-1 text-xs text-white"
                >
                  <option value="2">2 Spaces</option>
                  <option value="4">4 Spaces</option>
                  <option value="8">8 Spaces</option>
                </select>
              </div>
            </div>
          </div>

          {/* Section 4: Experience & Splash Test */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 uppercase tracking-wider mb-3">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Splash Screen & Transitions</span>
            </div>

            <div className="bg-zinc-950/60 p-4 rounded-xl border border-zinc-800/80 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold text-white">Replay MYself_SINGH Splash</p>
                <p className="text-[11px] text-zinc-400">
                  Preview the fixed 3s smooth intro without black screen flicker.
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onReplaySplash();
                }}
                className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-cyan-300 border border-cyan-500/30 rounded-lg text-xs font-medium transition-colors"
              >
                Replay Splash
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 mt-4 border-t border-zinc-800 shrink-0 flex items-center justify-between text-xs text-zinc-500">
          <span>Settings persist automatically in local storage</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-semibold text-xs transition-colors shadow-md"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
