import React, { useState, useEffect, useRef } from 'react';
import { CornerDownLeft, X, Hash } from 'lucide-react';

interface GoToLineModalProps {
  isOpen: boolean;
  maxLine: number;
  currentLine: number;
  onGoToLine: (line: number) => void;
  onClose: () => void;
}

export const GoToLineModal: React.FC<GoToLineModalProps> = ({
  isOpen,
  maxLine,
  currentLine,
  onGoToLine,
  onClose,
}) => {
  const [inputLine, setInputLine] = useState(String(currentLine));
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setInputLine(String(currentLine));
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 50);
    }
  }, [isOpen, currentLine]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const line = parseInt(inputLine, 10);
    if (!isNaN(line)) {
      onGoToLine(Math.max(1, Math.min(line, maxLine)));
      onClose();
    }
  };

  return (
    <div
      id="goto-line-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-in fade-in duration-150 p-4"
      onClick={onClose}
    >
      <div
        id="goto-line-modal-content"
        className="w-full max-w-sm bg-zinc-900 border border-zinc-700/80 rounded-xl shadow-2xl p-5 text-zinc-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <Hash className="w-4 h-4 text-cyan-400" />
            <span>Go to Line</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs text-zinc-400 mb-1.5 font-medium">
              Type line number between 1 and {maxLine}:
            </label>
            <div className="relative">
              <input
                ref={inputRef}
                type="number"
                min={1}
                max={maxLine}
                value={inputLine}
                onChange={(e) => setInputLine(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-500 font-mono"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-xs font-medium text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg shadow-md transition-colors"
            >
              <span>Jump</span>
              <CornerDownLeft className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
