import React, { useState, useRef, useEffect } from 'react';
import {
  Folder,
  Save,
  Check,
  Play,
  Terminal,
  Settings,
  Hash,
  Search,
  Smartphone,
  ChevronDown,
  Sun,
  Moon,
  Maximize2,
  Minimize2,
  ZoomIn,
  ZoomOut,
  HardDrive,
  FolderInput,
} from 'lucide-react';
import { THEMES } from '../utils/themes';
import { EditorTheme } from '../types';

interface HeaderProps {
  appName: string;
  theme: string;
  isModified: boolean;
  onSave: () => void;
  onRunPreview: () => void;
  onToggleTerminal: () => void;
  onToggleExplorer: () => void;
  onOpenSettings: () => void;
  onOpenShortcuts: () => void;
  onOpenGoToLine: () => void;
  onOpenSearch: () => void;
  onOpenExportApk: () => void;
  onOpenPhoneFolder?: () => void;
  syncedFolderName?: string | null;
  onNewFile: () => void;
  onToggleTheme: () => void;
  onZoomIn?: () => void;
  onZoomOut?: () => void;
  onResetZoom?: () => void;
  zoomLevel?: number;
  isPreviewOpen: boolean;
  isTerminalOpen: boolean;
  isExplorerOpen: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  appName,
  theme,
  isModified,
  onSave,
  onRunPreview,
  onToggleTerminal,
  onToggleExplorer,
  onOpenSettings,
  onOpenShortcuts,
  onOpenGoToLine,
  onOpenSearch,
  onOpenExportApk,
  onOpenPhoneFolder,
  syncedFolderName,
  onNewFile,
  onToggleTheme,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  zoomLevel = 100,
  isPreviewOpen,
  isTerminalOpen,
  isExplorerOpen,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(() => !!document.fullscreenElement);
  const [isSavedJustNow, setIsSavedJustNow] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const themeConfig = THEMES[theme as EditorTheme] || THEMES['monokai'] || THEMES['vs-dark'];
  const isDark = themeConfig.isDark;

  const handleSaveWithFeedback = () => {
    onSave();
    setIsSavedJustNow(true);
    setTimeout(() => setIsSavedJustNow(false), 1500);
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        }
      }
    } catch (e) {
      console.warn('Fullscreen request failed:', e);
    }
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setActiveMenu(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleMenu = (name: string) => {
    setActiveMenu(activeMenu === name ? null : name);
  };

  return (
    <header
      id="app-main-header"
      className="h-11 border-b flex items-center justify-between px-2 sm:px-3 shrink-0 select-none z-30 relative transition-colors duration-150 gap-1 sm:gap-2 overflow-x-auto no-scrollbar"
      style={{
        backgroundColor: themeConfig.headerBg,
        borderColor: themeConfig.borderColor,
      }}
    >
      {/* Left: Brand & Menus */}
      <div className="flex items-center gap-1.5 sm:gap-3 shrink-0" ref={menuRef}>
        {/* Brand Logo (also toggles File Explorer) & Name */}
        <div className="flex items-center gap-1.5 sm:gap-2 pr-1.5 sm:pr-3 border-r border-white/10 shrink-0">
          <button
            onClick={onToggleExplorer}
            title={isExplorerOpen ? "Close File Explorer" : "Open File Explorer"}
            className="w-7 h-7 rounded-lg bg-white flex items-center justify-center text-black font-black text-xs font-serif shadow-sm active:scale-95 transition-transform cursor-pointer hover:ring-2 hover:ring-cyan-400 shrink-0"
          >
            S
          </button>
          <div className="flex flex-col shrink-0">
            <span className="serif text-xs sm:text-sm font-semibold tracking-[0.15em] uppercase text-white whitespace-nowrap">
              {appName}
            </span>
            <span className="text-[8px] sm:text-[9px] uppercase tracking-[0.2em] text-white/50 font-mono -mt-0.5 whitespace-nowrap">
              STUDIO • MYself_SINGH
            </span>
          </div>
        </div>

        {/* Dropdown Menus: File, Edit, View, Run, Help */}
        <div className="hidden sm:flex items-center gap-0.5 text-xs text-white/70">
          {/* File Menu */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('file')}
              className={`px-2.5 py-1 rounded-md hover:bg-white/5 hover:text-white transition-colors flex items-center gap-1 ${
                activeMenu === 'file' ? 'bg-white/10 text-white' : ''
              }`}
            >
              <span>File</span>
              <ChevronDown className="w-3 h-3 opacity-50" />
            </button>
            {activeMenu === 'file' && (
              <div className="absolute left-0 top-full mt-1 w-52 bg-[#0c0c0c] border border-white/10 rounded-xl shadow-2xl py-1 z-50 animate-in fade-in duration-100 text-xs backdrop-blur-md">
                <button
                  onClick={() => {
                    onNewFile();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-white/90"
                >
                  <span>New File</span>
                  <span className="text-[10px] text-white/40 font-mono">Ctrl+N</span>
                </button>
                <button
                  onClick={() => {
                    onSave();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-white/90"
                >
                  <span>Save File</span>
                  <span className="text-[10px] text-white/40 font-mono">Ctrl+S</span>
                </button>
                {onOpenPhoneFolder && (
                  <button
                    onClick={() => {
                      onOpenPhoneFolder();
                      setActiveMenu(null);
                    }}
                    className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-emerald-400 font-medium"
                  >
                    <span>Import / Open Folder...</span>
                    <span className="text-[10px] text-emerald-500/80 font-mono">DIRECT</span>
                  </button>
                )}
                <div className="h-px bg-white/10 my-1" />
                <button
                  onClick={() => {
                    onOpenExportApk();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-cyan-400 font-medium"
                >
                  <span>Export & Host (InfinityFree / ZIP)</span>
                  <span className="text-[10px] text-cyan-500/80 font-mono">WEB / ZIP</span>
                </button>
              </div>
            )}
          </div>

          {/* Edit Menu */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('edit')}
              className={`px-2.5 py-1 rounded-md hover:bg-white/5 hover:text-white transition-colors flex items-center gap-1 ${
                activeMenu === 'edit' ? 'bg-white/10 text-white' : ''
              }`}
            >
              <span>Edit</span>
              <ChevronDown className="w-3 h-3 opacity-50" />
            </button>
            {activeMenu === 'edit' && (
              <div className="absolute left-0 top-full mt-1 w-48 bg-[#0c0c0c] border border-white/10 rounded-xl shadow-2xl py-1 z-50 animate-in fade-in duration-100 text-xs backdrop-blur-md">
                <button
                  onClick={() => {
                    onOpenSearch();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-white/90"
                >
                  <span>Find & Replace</span>
                  <span className="text-[10px] text-white/40 font-mono">Ctrl+F</span>
                </button>
                <button
                  onClick={() => {
                    onOpenGoToLine();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-white/90"
                >
                  <span>Go to Line...</span>
                  <span className="text-[10px] text-white/40 font-mono">Ctrl+G</span>
                </button>
              </div>
            )}
          </div>

          {/* View Menu */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('view')}
              className={`px-2.5 py-1 rounded-md hover:bg-white/5 hover:text-white transition-colors flex items-center gap-1 ${
                activeMenu === 'view' ? 'bg-white/10 text-white' : ''
              }`}
            >
              <span>View</span>
              <ChevronDown className="w-3 h-3 opacity-50" />
            </button>
            {activeMenu === 'view' && (
              <div className="absolute left-0 top-full mt-1 w-48 bg-[#0c0c0c] border border-white/10 rounded-xl shadow-2xl py-1 z-50 animate-in fade-in duration-100 text-xs backdrop-blur-md">
                <button
                  onClick={() => {
                    onToggleExplorer();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-white/90"
                >
                  <span>{isExplorerOpen ? 'Hide Explorer' : 'Show Explorer'}</span>
                </button>
                <button
                  onClick={() => {
                    onRunPreview();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-white/90"
                >
                  <span>{isPreviewOpen ? 'Hide Web Preview' : 'Show Web Preview'}</span>
                </button>
                <button
                  onClick={() => {
                    onToggleTerminal();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-white/90"
                >
                  <span>{isTerminalOpen ? 'Hide Terminal' : 'Show Terminal'}</span>
                </button>
              </div>
            )}
          </div>

          {/* Help Menu */}
          <div className="relative">
            <button
              onClick={() => toggleMenu('help')}
              className={`px-2.5 py-1 rounded-md hover:bg-white/5 hover:text-white transition-colors flex items-center gap-1 ${
                activeMenu === 'help' ? 'bg-white/10 text-white' : ''
              }`}
            >
              <span>Help</span>
              <ChevronDown className="w-3 h-3 opacity-50" />
            </button>
            {activeMenu === 'help' && (
              <div className="absolute left-0 top-full mt-1 w-48 bg-[#0c0c0c] border border-white/10 rounded-xl shadow-2xl py-1 z-50 animate-in fade-in duration-100 text-xs backdrop-blur-md">
                <button
                  onClick={() => {
                    onOpenShortcuts();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-white/90"
                >
                  <span>Shortcuts</span>
                  <span className="text-[10px] text-white/40 font-mono">F1</span>
                </button>
                <button
                  onClick={() => {
                    onOpenSettings();
                    setActiveMenu(null);
                  }}
                  className="w-full px-3 py-1.5 flex items-center justify-between hover:bg-white/5 text-left text-white/90"
                >
                  <span>Preferences</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Right: Quick Action Buttons */}
      <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
        {/* Quick Light / Dark Mode Toggle Button */}
        <button
          onClick={onToggleTheme}
          title={isDark ? "Switch to Light View" : "Switch to Dark View"}
          className="p-1.5 rounded-lg border transition-all flex items-center gap-1 text-xs font-medium shrink-0"
          style={{
            borderColor: themeConfig.borderColor,
            backgroundColor: isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.06)',
            color: themeConfig.textColor,
          }}
        >
          {isDark ? (
            <>
              <Sun className="w-4 h-4 text-amber-400 shrink-0" />
              <span className="hidden lg:inline text-[11px]">Light View</span>
            </>
          ) : (
            <>
              <Moon className="w-4 h-4 text-indigo-400 shrink-0" />
              <span className="hidden lg:inline text-[11px]">Dark View</span>
            </>
          )}
        </button>

        {/* Zoom Controls with Limits (10px to 28px) */}
        <div
          className="hidden md:flex items-center rounded-lg border px-1 py-0.5 gap-0.5 text-xs font-mono shrink-0"
          style={{
            borderColor: themeConfig.borderColor,
            backgroundColor: isDark ? 'rgba(255, 255, 255, 0.03)' : 'rgba(0, 0, 0, 0.03)',
            color: themeConfig.textColor,
          }}
        >
          <button
            onClick={onZoomOut}
            title="Zoom Out (Ctrl+-)"
            className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100 transition-colors"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onResetZoom}
            title="Reset Zoom to 100% (Ctrl+0)"
            className="px-1.5 py-0.5 text-[11px] font-semibold opacity-80 hover:opacity-100 transition-opacity"
          >
            {zoomLevel}%
          </button>
          <button
            onClick={onZoomIn}
            title="Zoom In (Ctrl++)"
            className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100 transition-colors"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Fullscreen Toggle */}
        <button
          onClick={toggleFullscreen}
          title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen Mode"}
          className="p-1.5 rounded-lg border transition-colors hidden sm:block shrink-0"
          style={{
            borderColor: themeConfig.borderColor,
            backgroundColor: isFullscreen ? (isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.1)') : 'transparent',
            color: themeConfig.textColor,
          }}
        >
          {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
        </button>

        {/* Search */}
        <button
          onClick={onOpenSearch}
          title="Find & Replace in document (Ctrl+F)"
          className="p-1.5 rounded-lg border transition-colors shrink-0"
          style={{
            borderColor: themeConfig.borderColor,
            color: themeConfig.textColor,
          }}
        >
          <Search className="w-4 h-4" />
        </button>

        {/* Go to line */}
        <button
          onClick={onOpenGoToLine}
          title="Go to line (Ctrl+G)"
          className="p-1.5 rounded-lg border transition-colors hidden sm:block shrink-0"
          style={{
            borderColor: themeConfig.borderColor,
            color: themeConfig.textColor,
          }}
        >
          <Hash className="w-4 h-4" />
        </button>

        {/* Save */}
        <button
          onClick={handleSaveWithFeedback}
          title="Save file (Ctrl+S)"
          className={`p-1.5 rounded-lg border transition-all active:scale-95 flex items-center gap-1 shrink-0 ${
            isSavedJustNow
              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 ring-2 ring-emerald-500/30'
              : isModified
              ? 'animate-pulse ring-1 ring-cyan-400'
              : ''
          }`}
          style={{
            borderColor: isSavedJustNow ? undefined : (isModified ? themeConfig.accentColor : themeConfig.borderColor),
            backgroundColor: isSavedJustNow ? undefined : (isModified ? (isDark ? 'rgba(255,255,255,0.2)' : 'rgba(0,0,0,0.1)') : 'transparent'),
            color: isSavedJustNow ? undefined : themeConfig.textColor,
          }}
        >
          {isSavedJustNow ? <Check className="w-4 h-4 text-emerald-400" /> : <Save className="w-4 h-4" />}
        </button>

        <div className="h-4 w-px bg-black/10 dark:bg-white/10 mx-0.5 hidden xs:block shrink-0" />

        {/* Live Preview Button */}
        <button
          onClick={onRunPreview}
          title="Toggle Live Web Preview"
          className="flex items-center gap-1 sm:gap-1.5 px-2 sm:px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all shadow-xs shrink-0"
          style={{
            backgroundColor: isPreviewOpen ? themeConfig.accentColor : (isDark ? '#27272a' : '#e4e4e7'),
            color: isPreviewOpen ? (isDark ? '#000000' : '#ffffff') : themeConfig.textColor,
          }}
        >
          <Play className={`w-3.5 h-3.5 ${isPreviewOpen ? 'fill-current' : ''}`} />
          <span className="hidden xs:inline">Preview</span>
        </button>

        {/* Terminal Toggle */}
        <button
          onClick={onToggleTerminal}
          title="Toggle Terminal Shell"
          className="p-1.5 rounded-lg border transition-colors hidden sm:block shrink-0"
          style={{
            borderColor: isTerminalOpen ? themeConfig.accentColor : themeConfig.borderColor,
            backgroundColor: isTerminalOpen ? (isDark ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.1)') : 'transparent',
            color: themeConfig.textColor,
          }}
        >
          <Terminal className="w-4 h-4" />
        </button>



        {/* Export Android APK / ZIP Button */}
        {onOpenExportApk && (
          <button
            onClick={onOpenExportApk}
            title="Export Project (.ZIP) & Android APK Bundle"
            className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-all hover:scale-[1.02] active:scale-95 shrink-0"
            style={{
              borderColor: themeConfig.accentColor,
              backgroundColor: isDark ? 'rgba(166, 226, 46, 0.15)' : 'rgba(6, 182, 212, 0.15)',
              color: isDark ? '#a6e22e' : '#0284c7',
            }}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="font-mono text-[11px] font-bold">Export</span>
          </button>
        )}

        {/* Settings Button */}
        <button
          onClick={onOpenSettings}
          title="Preferences & Theme"
          className="p-1.5 rounded-lg border transition-colors shrink-0 active:scale-95"
          style={{
            borderColor: themeConfig.borderColor,
            backgroundColor: isDark ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.05)',
            color: themeConfig.textColor,
          }}
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};

