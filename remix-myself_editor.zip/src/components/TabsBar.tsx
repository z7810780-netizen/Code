import React from 'react';
import { X, Plus, Circle } from 'lucide-react';
import { EditorFile } from '../types';
import { THEMES } from '../utils/themes';

interface TabsBarProps {
  files: EditorFile[];
  openFileIds: string[];
  activeFileId: string;
  onSelectTab: (fileId: string) => void;
  onCloseTab: (fileId: string, e: React.MouseEvent) => void;
  onNewFile: () => void;
  theme: string;
}

export const TabsBar: React.FC<TabsBarProps> = ({
  files,
  openFileIds,
  activeFileId,
  onSelectTab,
  onCloseTab,
  onNewFile,
  theme,
}) => {
  const themeConfig = THEMES[theme as keyof typeof THEMES] || THEMES['sophisticated-dark'] || THEMES['vs-dark'];

  const openFiles = openFileIds
    .map((id) => files.find((f) => f.id === id))
    .filter((f): f is EditorFile => f !== undefined);

  return (
    <div
      id="editor-tabs-bar"
      className="h-9 flex items-center border-b overflow-x-auto select-none shrink-0 scrollbar-none"
      style={{
        backgroundColor: themeConfig.sidebarBg,
        borderColor: themeConfig.borderColor,
        color: themeConfig.textColor,
      }}
    >
      <div className="flex items-center h-full">
        {openFiles.map((file) => {
          const isActive = file.id === activeFileId;

          return (
            <div
              key={file.id}
              onClick={() => onSelectTab(file.id)}
              className={`group h-full flex items-center gap-2 px-3.5 border-r cursor-pointer transition-all text-xs border-t-2 ${
                isActive
                  ? 'font-semibold'
                  : 'opacity-60 hover:opacity-100 border-t-transparent hover:bg-black/5 dark:hover:bg-white/5'
              }`}
              style={{
                backgroundColor: isActive
                  ? themeConfig.activeTabBg
                  : themeConfig.inactiveTabBg,
                borderTopColor: isActive ? themeConfig.accentColor : 'transparent',
                borderRightColor: themeConfig.borderColor,
                borderBottomColor: themeConfig.borderColor,
                borderLeftColor: themeConfig.borderColor,
                color: themeConfig.textColor,
              }}
            >
              <span className="font-mono text-xs tracking-tight">{file.name}</span>

              {/* Dirty Unsaved Dot or Close Button */}
              {file.isModified ? (
                <div
                  onClick={(e) => onCloseTab(file.id, e)}
                  title="Unsaved changes - click to close"
                  className="w-4 h-4 flex items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10"
                >
                  <Circle className="w-1.5 h-1.5 fill-current text-cyan-400 group-hover:hidden" />
                  <X className="w-3 h-3 opacity-60 hover:opacity-100 hidden group-hover:block" />
                </div>
              ) : (
                <button
                  onClick={(e) => onCloseTab(file.id, e)}
                  className="w-4 h-4 flex items-center justify-center rounded-full hover:bg-black/10 dark:hover:bg-white/10 opacity-40 hover:opacity-100 transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          );
        })}

        {/* Add Tab Button */}
        <button
          onClick={onNewFile}
          title="New File"
          className="h-full px-2.5 flex items-center justify-center opacity-50 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
