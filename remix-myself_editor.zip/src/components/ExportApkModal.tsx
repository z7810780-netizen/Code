import React, { useState } from 'react';
import {
  Download,
  X,
  CheckCircle2,
  Terminal,
  Copy,
  Check,
  Globe,
  Smartphone,
  Sparkles,
  Server,
  FolderArchive,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';
import { EditorFile, EditorTheme } from '../types';
import { THEMES } from '../utils/themes';
import {
  generateAndroidProjectZip,
  generateInfinityFreeZip,
  triggerBlobDownload,
} from '../utils/projectExporter';

interface ExportApkModalProps {
  isOpen: boolean;
  files: EditorFile[];
  onClose: () => void;
  theme?: string;
}

export const ExportApkModal: React.FC<ExportApkModalProps> = ({
  isOpen,
  files,
  onClose,
  theme = 'monokai',
}) => {
  const [activeTab, setActiveTab] = useState<'infinityfree' | 'android'>('infinityfree');
  const [copiedCmd, setCopiedCmd] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const themeConfig =
    THEMES[theme as EditorTheme] || THEMES['monokai'] || THEMES['vs-dark'];
  const isDark = themeConfig.isDark;

  if (!isOpen) return null;

  const buildCommand = './gradlew assembleDebug';

  const copyToClipboard = (text: string, type: 'cmd' | 'url') => {
    navigator.clipboard.writeText(text);
    if (type === 'cmd') {
      setCopiedCmd(true);
      setTimeout(() => setCopiedCmd(false), 2000);
    } else {
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    }
  };

  // Export 1-Click InfinityFree Web Hosting ZIP
  const handleExportInfinityFree = async () => {
    setIsExporting(true);
    try {
      const zipBlob = await generateInfinityFreeZip(files);
      triggerBlobDownload(zipBlob, 'MYself_EDITOR_InfinityFree_Web.zip');
    } catch (err) {
      console.error('Failed to generate InfinityFree web package:', err);
    } finally {
      setIsExporting(false);
    }
  };

  // Export Android Studio Project ZIP
  const handleExportAndroidZip = async () => {
    setIsExporting(true);
    try {
      const zipBlob = await generateAndroidProjectZip(files, {
        packageName: 'com.myselfsinghcodeeditor',
        appName: 'MYself_EDITOR',
        versionName: '1.0.0',
        versionCode: 1,
        exportType: 'ide',
      });
      triggerBlobDownload(zipBlob, 'MYself_EDITOR_Android_Project.zip');
    } catch (err) {
      console.error('Failed to generate Android project ZIP:', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div
      id="export-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm animate-in fade-in duration-150 p-4 select-none"
      onClick={onClose}
    >
      <div
        id="export-modal-content"
        className="w-full max-w-xl border rounded-2xl shadow-2xl p-5 sm:p-6 flex flex-col max-h-[92vh] transition-colors"
        style={{
          backgroundColor: isDark ? '#101217' : '#ffffff',
          borderColor: themeConfig.borderColor,
          color: themeConfig.textColor,
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between pb-3.5 mb-3.5 border-b shrink-0"
          style={{ borderColor: themeConfig.borderColor }}
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/25 text-cyan-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold flex items-center gap-2">
                <span>Export & Host MYself_EDITOR</span>
              </h2>
              <p className="text-xs opacity-70">
                Host on InfinityFree, cPanel, or build Android APK
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md opacity-70 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex bg-black/20 p-1 rounded-xl border border-white/10 mb-4 shrink-0">
          <button
            onClick={() => setActiveTab('infinityfree')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'infinityfree'
                ? 'bg-cyan-500 text-white shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Server className="w-3.5 h-3.5" />
            <span>InfinityFree Web Hosting (1-Click)</span>
          </button>
          <button
            onClick={() => setActiveTab('android')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'android'
                ? 'bg-cyan-500 text-white shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Android APK Project</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="space-y-4 overflow-y-auto pr-1">
          {activeTab === 'infinityfree' ? (
            /* InfinityFree Tab */
            <>
              <div
                className="p-4 rounded-xl border flex flex-col gap-3"
                style={{
                  backgroundColor: isDark ? 'rgba(6, 182, 212, 0.08)' : 'rgba(6, 182, 212, 0.04)',
                  borderColor: 'rgba(6, 182, 212, 0.25)',
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-cyan-950 border border-cyan-500/40 shadow-md flex items-center justify-center shrink-0 text-cyan-400">
                    <Globe className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-cyan-400">Ready-To-Upload InfinityFree ZIP</h3>
                      <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        100% Free
                      </span>
                    </div>
                    <p className="text-xs opacity-80 mt-0.5 leading-snug">
                      Includes <code>index.html</code>, Apache <code>.htaccess</code>, and full editor engine. Just upload to your <code>htdocs/</code> folder!
                    </p>
                  </div>
                </div>

                {/* Features Included */}
                <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-cyan-500/15">
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span className="text-slate-300">Splash screen with photo</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span className="text-slate-300">Preview any .html file</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span className="text-slate-300">Local files & folders</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span className="text-slate-300">Apache .htaccess included</span>
                  </div>
                </div>
              </div>

              {/* Step-by-Step InfinityFree Guide */}
              <div className="p-3.5 rounded-xl bg-black/30 border border-white/10 space-y-2.5 text-xs">
                <div className="flex items-center justify-between font-bold text-cyan-300">
                  <span>How to host on InfinityFree:</span>
                  <span className="text-[10px] text-white/50">Takes &lt; 1 minute</span>
                </div>
                <div className="space-y-2 text-[11px] text-slate-300">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">1</span>
                    <div>
                      Click <strong>"Download Web Package (.ZIP)"</strong> below to get <code>MYself_EDITOR_InfinityFree_Web.zip</code>.
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">2</span>
                    <div>
                      Log in to <strong>InfinityFree Control Panel</strong> ➔ click <strong>Online File Manager</strong>.
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">3</span>
                    <div>
                      Open your <code>htdocs</code> folder, upload & extract the ZIP file (or upload the extracted <code>index.html</code> & <code>.htaccess</code>).
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px] shrink-0 mt-0.5">4</span>
                    <div>
                      Open your website domain (e.g. <code>http://yourname.infinityfreeapp.com</code>). <strong>Your website is live immediately!</strong>
                    </div>
                  </div>
                </div>
              </div>
            </>
          ) : (
            /* Android APK Tab */
            <>
              <div
                className="p-4 rounded-xl border flex flex-col gap-3"
                style={{
                  backgroundColor: isDark ? 'rgba(6, 182, 212, 0.06)' : 'rgba(6, 182, 212, 0.04)',
                  borderColor: 'rgba(6, 182, 212, 0.25)',
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-xl bg-slate-900 border border-cyan-500/40 shadow-md flex items-center justify-center shrink-0">
                    <span className="font-mono text-cyan-400 font-extrabold text-base">&lt;/&gt;</span>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-cyan-400">Android Studio / Codespace Project</h3>
                      <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        APK Ready
                      </span>
                    </div>
                    <p className="text-xs opacity-80 mt-0.5 leading-snug">
                      Complete Gradle project with vector launcher icons, Kotlin MainActivity, and GitHub Actions CI/CD.
                    </p>
                  </div>
                </div>
              </div>

              {/* Codespace Build Command */}
              <div className="space-y-2">
                <label className="block text-xs font-semibold opacity-90 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Codespace Build Command</span>
                  </span>
                </label>
                <div
                  className="flex items-center gap-2 p-2 rounded-xl border"
                  style={{
                    backgroundColor: isDark ? '#090a0f' : '#f4f4f5',
                    borderColor: themeConfig.borderColor,
                  }}
                >
                  <code className="flex-1 text-xs text-cyan-300 font-mono">bash build-apk-codespace.sh</code>
                  <button
                    onClick={() => copyToClipboard('bash build-apk-codespace.sh', 'cmd')}
                    className="px-2.5 py-1 rounded-lg border text-xs flex items-center gap-1 transition-colors hover:bg-white/10"
                    style={{ borderColor: themeConfig.borderColor }}
                  >
                    {copiedCmd ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div
          className="pt-4 mt-4 border-t shrink-0 flex items-center justify-between"
          style={{ borderColor: themeConfig.borderColor }}
        >
          <button
            onClick={onClose}
            className="px-3.5 py-2 rounded-xl text-xs opacity-70 hover:opacity-100 hover:bg-white/10 transition-colors"
          >
            Close
          </button>
          {activeTab === 'infinityfree' ? (
            <button
              onClick={handleExportInfinityFree}
              disabled={isExporting}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-600 hover:from-emerald-400 hover:to-cyan-500 text-white font-bold text-xs transition-all shadow-lg active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'Packaging Website ZIP...' : 'Download Web Package (.ZIP)'}</span>
            </button>
          ) : (
            <button
              onClick={handleExportAndroidZip}
              disabled={isExporting}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs transition-all shadow-lg active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>{isExporting ? 'Creating Android ZIP...' : 'Download Android Project (.ZIP)'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
