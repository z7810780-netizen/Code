import React, { useRef, useEffect, useState, useMemo, useLayoutEffect, useCallback } from 'react';
import {
  EditorFile,
  EditorSettings,
  EditorTheme,
  SearchState,
} from '../types';
import { tokenizeLine, HighlightToken } from '../utils/syntax';
import { THEMES } from '../utils/themes';
import {
  FileCode,
  Check,
  ChevronDown,
  ChevronRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface EditorAreaProps {
  file: EditorFile | null;
  settings: EditorSettings;
  searchState: SearchState;
  onContentChange: (newContent: string) => void;
  onSave: () => void;
  onCursorChange?: (line: number, col: number, selectionLen: number) => void;
  onZoomIn?: () => void;
  onZoomOut?: () => void;
  onResetZoom?: () => void;
}

export const EditorArea: React.FC<EditorAreaProps> = ({
  file,
  settings,
  searchState,
  onContentChange,
  onSave,
  onCursorChange,
  onZoomIn,
  onZoomOut,
  onResetZoom,
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);
  const highlightOverlayRef = useRef<HTMLDivElement>(null);

  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1, selLen: 0 });
  const [foldedLines, setFoldedLines] = useState<Set<number>>(new Set());
  const [lineHeights, setLineHeights] = useState<number[]>([]);
  const lineRefs = useRef<(HTMLDivElement | null)[]>([]);

  const themeConfig = THEMES[settings.theme] || THEMES['monokai'] || THEMES['vs-dark'];

  // Lines calculation
  const lines = useMemo(() => {
    if (!file) return [];
    return file.content.split('\n');
  }, [file?.content]);

  // Synchronize line height measurements for accurate gutter line numbering on wrapped lines
  const updateLineHeights = useCallback(() => {
    if (!highlightOverlayRef.current) return;
    const newHeights = lines.map((_, idx) => {
      const el = lineRefs.current[idx];
      return el ? el.getBoundingClientRect().height : 0;
    });
    setLineHeights((prev) => {
      if (
        prev.length === newHeights.length &&
        prev.every((h, i) => Math.abs(h - newHeights[i]) < 0.5)
      ) {
        return prev;
      }
      return newHeights;
    });
  }, [lines]);

  useLayoutEffect(() => {
    updateLineHeights();
  }, [lines, settings.fontSize, settings.fontFamily, settings.wordWrap, settings.tabSize, updateLineHeights]);

  useEffect(() => {
    const container = highlightOverlayRef.current;
    if (!container) return;

    const observer = new ResizeObserver(() => {
      updateLineHeights();
    });

    observer.observe(container);
    lineRefs.current.forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => {
      observer.disconnect();
    };
  }, [lines, updateLineHeights]);

  // Compute all search matches positions across all lines
  const searchMatches = useMemo(() => {
    if (!searchState.isOpen || !searchState.query || !file) {
      return { matches: [] as { lineIdx: number; startCol: number; endCol: number; matchIdx: number }[], total: 0 };
    }

    try {
      let flags = 'g';
      if (!searchState.caseSensitive) flags += 'i';
      let pattern = searchState.query;
      if (!searchState.useRegex) {
        pattern = pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      }
      if (searchState.matchWholeWord) {
        pattern = `\\b${pattern}\\b`;
      }

      const regex = new RegExp(pattern, flags);
      const matches: { lineIdx: number; startCol: number; endCol: number; matchIdx: number }[] = [];
      let globalIdx = 0;

      lines.forEach((lineText, lineIdx) => {
        let match;
        // Reset regex state for each line or execute on line
        const lineRegex = new RegExp(pattern, flags);
        while ((match = lineRegex.exec(lineText)) !== null) {
          if (match[0].length === 0) {
            lineRegex.lastIndex++;
            continue;
          }
          matches.push({
            lineIdx,
            startCol: match.index,
            endCol: match.index + match[0].length,
            matchIdx: globalIdx,
          });
          globalIdx++;
        }
      });

      return { matches, total: globalIdx };
    } catch (e) {
      return { matches: [], total: 0 };
    }
  }, [searchState.isOpen, searchState.query, searchState.caseSensitive, searchState.matchWholeWord, searchState.useRegex, lines, file]);

  // Auto-scroll to active search match
  useEffect(() => {
    if (!searchState.isOpen || searchMatches.total === 0 || !textareaRef.current) return;
    const currentMatch = searchMatches.matches[searchState.currentMatchIndex % searchMatches.total];
    if (currentMatch) {
      const lineNum = currentMatch.lineIdx + 1;
      const approxLineHeight = settings.fontSize * 1.6;
      const targetScrollTop = Math.max(0, (currentMatch.lineIdx - 3) * approxLineHeight);

      if (textareaRef.current) {
        textareaRef.current.scrollTop = targetScrollTop;
      }
      if (lineNumbersRef.current) {
        lineNumbersRef.current.scrollTop = targetScrollTop;
      }
      if (highlightOverlayRef.current) {
        highlightOverlayRef.current.scrollTop = targetScrollTop;
      }
    }
  }, [searchState.currentMatchIndex, searchMatches, settings.fontSize]);

  // Sync scroll
  const handleScroll = (e: React.UIEvent<HTMLTextAreaElement>) => {
    const top = e.currentTarget.scrollTop;
    const left = e.currentTarget.scrollLeft;
    if (lineNumbersRef.current) lineNumbersRef.current.scrollTop = top;
    if (highlightOverlayRef.current) {
      highlightOverlayRef.current.scrollTop = top;
      highlightOverlayRef.current.scrollLeft = left;
    }
  };

  // Track cursor position
  const updateCursor = () => {
    const textarea = textareaRef.current;
    if (!textarea || !file) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const textBefore = file.content.substring(0, start);
    const lineList = textBefore.split('\n');
    const currentLine = lineList.length;
    const currentCol = lineList[lineList.length - 1].length + 1;
    const selLen = Math.abs(end - start);

    setCursorPos({ line: currentLine, col: currentCol, selLen });
    onCursorChange?.(currentLine, currentCol, selLen);
  };

  // Keyboard handler for tabs, brackets, auto-indent, shortcuts
  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    const textarea = textareaRef.current;
    if (!textarea || !file) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const val = file.content;

    // Ctrl + S (Save)
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      onSave();
      return;
    }

    // Ctrl + Plus / Equal (Zoom In)
    if ((e.ctrlKey || e.metaKey) && (e.key === '=' || e.key === '+')) {
      e.preventDefault();
      onZoomIn?.();
      return;
    }

    // Ctrl + Minus (Zoom Out)
    if ((e.ctrlKey || e.metaKey) && (e.key === '-' || e.key === '_')) {
      e.preventDefault();
      onZoomOut?.();
      return;
    }

    // Ctrl + 0 (Reset Zoom)
    if ((e.ctrlKey || e.metaKey) && e.key === '0') {
      e.preventDefault();
      onResetZoom?.();
      return;
    }

    // Tab key
    if (e.key === 'Tab') {
      e.preventDefault();
      const tabStr = settings.useSpaces ? ' '.repeat(settings.tabSize) : '\t';

      if (e.shiftKey) {
        // Unindent
        const lineStart = val.lastIndexOf('\n', start - 1) + 1;
        const lineText = val.substring(lineStart);
        if (lineText.startsWith('  ')) {
          const updated = val.substring(0, lineStart) + lineText.substring(2);
          onContentChange(updated);
          setTimeout(() => {
            textarea.selectionStart = textarea.selectionEnd = Math.max(lineStart, start - 2);
          }, 0);
        }
      } else {
        // Insert Tab
        const updated = val.substring(0, start) + tabStr + val.substring(end);
        onContentChange(updated);
        setTimeout(() => {
          textarea.selectionStart = textarea.selectionEnd = start + tabStr.length;
        }, 0);
      }
      return;
    }

    // Auto-indent on Enter
    if (e.key === 'Enter' && settings.autoIndent) {
      e.preventDefault();
      const currentLineStart = val.lastIndexOf('\n', start - 1) + 1;
      const currentLineText = val.substring(currentLineStart, start);
      const match = currentLineText.match(/^(\s+)/);
      let indent = match ? match[1] : '';

      // Extra indent if previous char was { or ( or [
      const prevChar = val[start - 1];
      const nextChar = val[start];
      let insertText = '\n' + indent;

      if (prevChar === '{' || prevChar === '(' || prevChar === '[') {
        const extra = settings.useSpaces ? ' '.repeat(settings.tabSize) : '\t';
        if (nextChar === '}' || nextChar === ')' || nextChar === ']') {
          insertText = '\n' + indent + extra + '\n' + indent;
          const updated = val.substring(0, start) + insertText + val.substring(end);
          onContentChange(updated);
          setTimeout(() => {
            textarea.selectionStart = textarea.selectionEnd = start + indent.length + extra.length + 1;
          }, 0);
          return;
        } else {
          insertText = '\n' + indent + extra;
        }
      }

      const updated = val.substring(0, start) + insertText + val.substring(end);
      onContentChange(updated);
      setTimeout(() => {
        textarea.selectionStart = textarea.selectionEnd = start + insertText.length;
      }, 0);
      return;
    }

    // Auto Close Brackets & Quotes
    if (settings.autoCloseBrackets || settings.autoCloseQuotes) {
      const pairs: Record<string, string> = {
        '(': ')',
        '[': ']',
        '{': '}',
        '"': '"',
        "'": "'",
        '`': '`',
      };

      if (pairs[e.key]) {
        // Don't duplicate if already next
        if (val[start] === pairs[e.key] && (e.key === '"' || e.key === "'" || e.key === '`' || e.key === ')' || e.key === ']' || e.key === '}')) {
          e.preventDefault();
          textarea.selectionStart = textarea.selectionEnd = start + 1;
          return;
        }

        e.preventDefault();
        const close = pairs[e.key];
        const selected = val.substring(start, end);
        const updated = val.substring(0, start) + e.key + selected + close + val.substring(end);
        onContentChange(updated);
        setTimeout(() => {
          textarea.selectionStart = textarea.selectionEnd = start + 1 + selected.length;
        }, 0);
        return;
      }
    }
  };

  const getTokenColor = (token: HighlightToken): string => {
    switch (token.type) {
      case 'keyword':
        return themeConfig.keywordColor;
      case 'type':
        return themeConfig.typeColor || themeConfig.functionColor;
      case 'string':
        return themeConfig.stringColor;
      case 'number':
        return themeConfig.numberColor;
      case 'comment':
        return themeConfig.commentColor;
      case 'function':
        return themeConfig.functionColor;
      case 'tag':
        return themeConfig.tagColor;
      case 'attr':
        return themeConfig.attrColor;
      case 'operator':
        return themeConfig.operatorColor || themeConfig.accentColor;
      case 'punctuation':
        return themeConfig.textColor;
      default:
        return themeConfig.textColor;
    }
  };

  // Handle wheel zoom (Ctrl + Wheel)
  const handleWheel = (e: React.WheelEvent<HTMLTextAreaElement>) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      if (e.deltaY < 0) {
        onZoomIn?.();
      } else if (e.deltaY > 0) {
        onZoomOut?.();
      }
    }
  };

  // Render tokens for a line with search highlight overlays
  const renderLineWithSearchHighlights = (line: string, lineIdx: number) => {
    const tokens = tokenizeLine(line, file.language);
    const lineMatches = searchMatches.matches.filter((m) => m.lineIdx === lineIdx);

    if (lineMatches.length === 0 || !searchState.isOpen || !searchState.query) {
      return tokens.map((tok, tokIdx) => (
        <span
          key={tokIdx}
          style={{
            color: getTokenColor(tok),
            fontStyle: tok.type === 'comment' ? 'italic' : 'normal',
          }}
        >
          {tok.text}
        </span>
      ));
    }

    // Line has search matches: we slice each token into contiguous matched vs non-matched sub-segments
    let charOffset = 0;
    const resultSpans: React.ReactNode[] = [];

    tokens.forEach((tok, tokIdx) => {
      const tokStart = charOffset;
      const tokEnd = charOffset + tok.text.length;
      charOffset = tokEnd;

      // Find all matches that intersect with [tokStart, tokEnd]
      const intersectingMatches = lineMatches.filter(
        (m) => m.startCol < tokEnd && m.endCol > tokStart
      );

      if (intersectingMatches.length === 0) {
        // No match in this token - render entire token
        resultSpans.push(
          <span
            key={`tok-${tokIdx}`}
            style={{
              color: getTokenColor(tok),
              fontStyle: tok.type === 'comment' ? 'italic' : 'normal',
            }}
          >
            {tok.text}
          </span>
        );
        return;
      }

      // There are matches within this token. Slices within [tokStart, tokEnd]:
      let localCursor = 0; // relative to tokStart (0 to tok.text.length)

      intersectingMatches.forEach((m, mIdx) => {
        const matchTokStart = Math.max(0, m.startCol - tokStart);
        const matchTokEnd = Math.min(tok.text.length, m.endCol - tokStart);

        // 1. Non-matched prefix before this match
        if (matchTokStart > localCursor) {
          const prefixText = tok.text.substring(localCursor, matchTokStart);
          resultSpans.push(
            <span
              key={`tok-${tokIdx}-unm-${localCursor}`}
              style={{
                color: getTokenColor(tok),
                fontStyle: tok.type === 'comment' ? 'italic' : 'normal',
              }}
            >
              {prefixText}
            </span>
          );
        }

        // 2. Contiguous matched text segment (e.g. |web|site instead of |w|e|b|site)
        if (matchTokEnd > matchTokStart) {
          const matchedText = tok.text.substring(matchTokStart, matchTokEnd);
          const isCurrentActive =
            m.matchIdx === (searchState.currentMatchIndex % (searchMatches.total || 1));

          resultSpans.push(
            <span
              key={`tok-${tokIdx}-match-${mIdx}-${matchTokStart}`}
              className={`inline rounded-xs font-semibold transition-all ${
                isCurrentActive
                  ? 'bg-cyan-400 text-black font-extrabold ring-2 ring-cyan-200 shadow-md shadow-cyan-400/50'
                  : 'bg-amber-400/40 text-amber-200 ring-1 ring-amber-400/80'
              }`}
              style={{
                color: isCurrentActive ? '#000000' : undefined,
                paddingLeft: '1px',
                paddingRight: '1px',
              }}
            >
              {matchedText}
            </span>
          );
          localCursor = Math.max(localCursor, matchTokEnd);
        }
      });

      // 3. Any trailing non-matched suffix
      if (localCursor < tok.text.length) {
        const suffixText = tok.text.substring(localCursor);
        resultSpans.push(
          <span
            key={`tok-${tokIdx}-suffix-${localCursor}`}
            style={{
              color: getTokenColor(tok),
              fontStyle: tok.type === 'comment' ? 'italic' : 'normal',
            }}
          >
            {suffixText}
          </span>
        );
      }
    });

    return resultSpans;
  };

  if (!file) {
    return (
      <div
        id="empty-editor-placeholder"
        className="flex-1 flex flex-col items-center justify-center p-8 select-none text-zinc-500"
        style={{ backgroundColor: themeConfig.editorBg }}
      >
        <FileCode className="w-16 h-16 text-zinc-600 mb-4 stroke-1" />
        <h3 className="text-base font-semibold text-zinc-300">No File Open</h3>
        <p className="text-xs text-zinc-500 mt-1">Select a file from the explorer or create a new one.</p>
      </div>
    );
  }

  const gutterWidth = settings.showLineNumbers
    ? Math.max(38, Math.ceil(String(lines.length).length * (settings.fontSize * 0.65) + 24))
    : 0;

  return (
    <div
      id="editor-main-viewport"
      className="flex-1 flex flex-col h-full overflow-hidden relative"
      style={{ backgroundColor: themeConfig.editorBg }}
    >
      {/* Editor Content Box */}
      <div className="flex-1 flex relative overflow-hidden">
        {/* Line Numbers Gutter */}
        {settings.showLineNumbers && (
          <div
            ref={lineNumbersRef}
            id="editor-line-numbers"
            className="select-none py-3 px-3 border-r overflow-hidden text-right font-mono shrink-0 transition-all"
            style={{
              backgroundColor: themeConfig.gutterBg,
              borderColor: themeConfig.borderColor,
              fontSize: `${settings.fontSize}px`,
              fontFamily: settings.fontFamily,
              lineHeight: 1.6,
              color: '#71717a',
              width: `${gutterWidth}px`,
            }}
          >
            {lines.map((_, idx) => {
              const lineNum = idx + 1;
              const isCurrent = lineNum === cursorPos.line;
              const hasSearchMatch = searchMatches.matches.some((m) => m.lineIdx === idx);
              const isSearchActiveLine = searchMatches.matches.some(
                (m) => m.lineIdx === idx && m.matchIdx === (searchState.currentMatchIndex % (searchMatches.total || 1))
              );
              const h = lineHeights[idx];

              return (
                <div
                  key={lineNum}
                  style={{
                    height: h && h > 0 ? `${h}px` : undefined,
                    minHeight: `${settings.fontSize * 1.6}px`,
                    lineHeight: 1.6,
                  }}
                  className={`cursor-pointer transition-colors flex items-start justify-end ${
                    isSearchActiveLine
                      ? 'text-cyan-400 font-extrabold'
                      : hasSearchMatch
                      ? 'text-amber-400 font-bold'
                      : isCurrent
                      ? 'text-white font-bold'
                      : 'hover:text-white'
                  }`}
                >
                  {lineNum}
                </div>
              );
            })}
          </div>
        )}

        {/* Highlight Rendering Underlay */}
        <div
          ref={highlightOverlayRef}
          aria-hidden="true"
          className="absolute inset-0 pointer-events-none overflow-hidden select-none font-mono py-3"
          style={{
            left: `${gutterWidth}px`,
            paddingLeft: '16px',
            paddingRight: '16px',
            fontSize: `${settings.fontSize}px`,
            fontFamily: settings.fontFamily,
            lineHeight: 1.6,
            whiteSpace: settings.wordWrap ? 'pre-wrap' : 'pre',
            wordBreak: settings.wordWrap ? 'break-word' : 'normal',
            tabSize: settings.tabSize,
          }}
        >
          {lines.map((line, lineIdx) => {
            const isCurrent = lineIdx + 1 === cursorPos.line;

            return (
              <div
                key={lineIdx}
                ref={(el) => {
                  lineRefs.current[lineIdx] = el;
                }}
                className="leading-[1.6] relative"
                style={{
                  backgroundColor:
                    settings.highlightActiveLine && isCurrent
                      ? themeConfig.activeLineBg
                      : 'transparent',
                }}
              >
                {renderLineWithSearchHighlights(line, lineIdx)}
                {line.length === 0 && <span>&nbsp;</span>}
              </div>
            );
          })}
        </div>

        {/* Real Transparent Textarea Input */}
        <textarea
          ref={textareaRef}
          id="editor-textarea-input"
          value={file.content}
          onChange={(e) => onContentChange(e.target.value)}
          onKeyDown={handleKeyDown}
          onWheel={handleWheel}
          onClick={updateCursor}
          onKeyUp={updateCursor}
          onSelect={updateCursor}
          onScroll={handleScroll}
          spellCheck={false}
          autoCapitalize="off"
          autoComplete="off"
          autoCorrect="off"
          className="flex-1 resize-none bg-transparent outline-none z-10 font-mono py-3 pl-4 pr-4 border-0 leading-[1.6] focus:ring-0"
          style={{
            fontSize: `${settings.fontSize}px`,
            fontFamily: settings.fontFamily,
            color: 'transparent', // Text rendered by syntax layer
            caretColor: themeConfig.textColor,
            whiteSpace: settings.wordWrap ? 'pre-wrap' : 'pre',
            wordBreak: settings.wordWrap ? 'break-word' : 'normal',
            tabSize: settings.tabSize,
          }}
        />
      </div>

      {/* Status Bar */}
      <div
        id="editor-status-bar"
        className="h-6 px-3 flex items-center justify-between border-t text-[11px] select-none font-mono shrink-0"
        style={{
          backgroundColor: themeConfig.gutterBg,
          borderColor: themeConfig.borderColor,
          color: '#71717a',
        }}
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <span className="text-zinc-400">Ln {cursorPos.line}, Col {cursorPos.col}</span>
            {cursorPos.selLen > 0 && (
              <span className="text-cyan-400">({cursorPos.selLen} selected)</span>
            )}
          </div>
          <span className="text-zinc-600">•</span>
          <span className="text-zinc-400 uppercase font-semibold text-[10px] px-1.5 py-0.2 rounded bg-zinc-800/80">
            {file.language}
          </span>
          <span className="text-zinc-600">•</span>
          <span className="text-zinc-400">{lines.length} lines</span>
        </div>

        <div className="flex items-center gap-3">
          <span>{file.encoding || 'UTF-8'}</span>
          <span className="text-zinc-600">•</span>
          <span>{file.lineEnding || 'LF'}</span>
          <span className="text-zinc-600">•</span>
          <span>Spaces: {settings.tabSize}</span>
          <span className="text-zinc-600">•</span>
          <span className="text-emerald-400 flex items-center gap-1 font-semibold">
            <Check className="w-3 h-3" />
            <span>Ready</span>
          </span>
        </div>
      </div>
    </div>
  );
};
