import React, { useState, useRef, useEffect } from 'react';
import {
  Terminal as TerminalIcon,
  Trash2,
  Maximize2,
  Minimize2,
  X,
  Play,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { EditorFile, TerminalOutput, EditorTheme } from '../types';
import { THEMES } from '../utils/themes';

interface TerminalPanelProps {
  files: EditorFile[];
  onCreateFile: (name: string, content?: string) => void;
  onDeleteFile: (fileId: string) => void;
  onOpenFile: (fileId: string) => void;
  onBuildApk: () => void;
  isOpen: boolean;
  onClose: () => void;
  theme?: string;
}

export const TerminalPanel: React.FC<TerminalPanelProps> = ({
  files,
  onCreateFile,
  onDeleteFile,
  onOpenFile,
  onBuildApk,
  isOpen,
  onClose,
  theme = 'monokai',
}) => {
  const themeConfig = THEMES[theme as EditorTheme] || THEMES['monokai'] || THEMES['vs-dark'];
  const isDark = themeConfig.isDark;

  const [outputs, setOutputs] = useState<TerminalOutput[]>([
    {
      id: 'init-1',
      type: 'system',
      text: 'MYself_EDITOR Terminal [Version 2.4.0-pro]',
      timestamp: new Date().toLocaleTimeString(),
    },
    {
      id: 'init-2',
      type: 'system',
      text: 'Type "help" to see available shell commands or "./gradlew assembleDebug" to build APK.',
      timestamp: new Date().toLocaleTimeString(),
    },
  ]);
  const [currentInput, setCurrentInput] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [isExpanded, setIsExpanded] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [outputs]);

  if (!isOpen) return null;

  const addOutput = (type: TerminalOutput['type'], text: string) => {
    setOutputs((prev) => [
      ...prev,
      {
        id: Math.random().toString(36).substring(2, 9),
        type,
        text,
        timestamp: new Date().toLocaleTimeString(),
      },
    ]);
  };

  const handleCommand = (rawCmd: string) => {
    const trimmed = rawCmd.trim();
    if (!trimmed) return;

    // Add command to output
    addOutput('command', `$ ${trimmed}`);
    setHistory((prev) => [...prev, trimmed]);
    setHistoryIndex(-1);
    setCurrentInput('');

    const parts = trimmed.split(' ');
    const command = parts[0].toLowerCase();
    const args = parts.slice(1);

    switch (command) {
      case 'help':
        addOutput(
          'stdout',
          `Available commands:
  ls, dir               - List project files & sizes
  cat <file>            - View file content
  touch <file>          - Create a new file
  rm <file>             - Remove a file
  open <file>           - Open file in editor tab
  pwd                   - Print current directory
  echo <text>           - Print text to terminal
  clear, cls            - Clear terminal screen
  run, node, python     - Execute JavaScript / Python file
  gradlew, ./gradlew    - Run Gradle command (e.g., ./gradlew assembleDebug)
  whoami                - Display user environment info
  date                  - Show current timestamp
  version               - Show MYself_EDITOR version info`
        );
        break;

      case 'ls':
      case 'dir':
        if (files.length === 0) {
          addOutput('stdout', '(Empty directory)');
        } else {
          const list = files
            .map(
              (f) =>
                `${f.name.padEnd(20)} [${f.language.toUpperCase().padEnd(10)}] ${(f.content.length + ' B').padStart(8)}`
            )
            .join('\n');
          addOutput('stdout', list);
        }
        break;

      case 'pwd':
        addOutput('stdout', '/workspace/MYself_EDITOR');
        break;

      case 'whoami':
        addOutput('stdout', 'myself_singh@android-ide-workspace');
        break;

      case 'date':
        addOutput('stdout', new Date().toString());
        break;

      case 'version':
        addOutput('stdout', 'MYself_EDITOR v2.4.0 (Kotlin + React + WebView Engine)');
        break;

      case 'clear':
      case 'cls':
        setOutputs([]);
        break;

      case 'cat':
        if (!args[0]) {
          addOutput('stderr', 'Error: Specify file name. Example: cat index.html');
        } else {
          const target = files.find(
            (f) => f.name.toLowerCase() === args[0].toLowerCase() || f.path === args[0]
          );
          if (target) {
            addOutput('stdout', target.content);
          } else {
            addOutput('stderr', `cat: ${args[0]}: No such file`);
          }
        }
        break;

      case 'touch':
        if (!args[0]) {
          addOutput('stderr', 'Error: Specify file name. Example: touch app.ts');
        } else {
          const existing = files.find((f) => f.name.toLowerCase() === args[0].toLowerCase());
          if (existing) {
            addOutput('stderr', `touch: file '${args[0]}' already exists`);
          } else {
            onCreateFile(args[0], '');
            addOutput('stdout', `Created file: ${args[0]}`);
          }
        }
        break;

      case 'rm':
        if (!args[0]) {
          addOutput('stderr', 'Error: Specify file name. Example: rm temp.js');
        } else {
          const target = files.find((f) => f.name.toLowerCase() === args[0].toLowerCase());
          if (target) {
            onDeleteFile(target.id);
            addOutput('stdout', `Removed file: ${args[0]}`);
          } else {
            addOutput('stderr', `rm: cannot remove '${args[0]}': No such file`);
          }
        }
        break;

      case 'open':
        if (!args[0]) {
          addOutput('stderr', 'Error: Specify file name. Example: open index.html');
        } else {
          const target = files.find((f) => f.name.toLowerCase() === args[0].toLowerCase());
          if (target) {
            onOpenFile(target.id);
            addOutput('stdout', `Opened ${args[0]} in editor.`);
          } else {
            addOutput('stderr', `open: file '${args[0]}' not found`);
          }
        }
        break;

      case 'echo':
        addOutput('stdout', args.join(' '));
        break;

      case 'node':
      case 'run':
      case 'python':
        if (!args[0]) {
          addOutput('stderr', `Usage: ${command} <filename>`);
        } else {
          const target = files.find((f) => f.name.toLowerCase() === args[0].toLowerCase());
          if (!target) {
            addOutput('stderr', `File '${args[0]}' not found.`);
          } else if (target.language === 'javascript') {
            try {
              let logs: string[] = [];
              const customConsole = {
                log: (...a: any[]) => logs.push(a.join(' ')),
                warn: (...a: any[]) => logs.push('[WARN] ' + a.join(' ')),
                error: (...a: any[]) => logs.push('[ERROR] ' + a.join(' ')),
              };
              const runner = new Function('console', target.content);
              runner(customConsole);
              addOutput(
                'stdout',
                logs.length > 0 ? logs.join('\n') : '[Process finished with exit code 0]'
              );
            } catch (err: any) {
              addOutput('stderr', `Runtime Error: ${err.message}`);
            }
          } else if (target.language === 'python') {
            addOutput(
              'stdout',
              `[Python 3.11 Execution simulation]\nRunning ${target.name}...\nOutput:\nWelcome to MYself_EDITOR - Python Runner!\nSupported mobile IDE languages: Kotlin, Java, Python, JavaScript, Rust, C++\n[Process completed successfully]`
            );
          } else {
            addOutput('stdout', `Execution of ${target.language} scripts simulated.`);
          }
        }
        break;

      case './gradlew':
      case 'gradlew':
        if (args.includes('assembleDebug') || args.includes('build')) {
          addOutput(
            'system',
            `> Task :app:preBuild UP-TO-DATE
> Task :app:preDebugBuild UP-TO-DATE
> Task :app:compileDebugKotlin
> Task :app:mergeDebugAssets
> Task :app:processDebugResources
> Task :app:compileDebugJavaWithJavac
> Task :app:dexBuilderDebug
> Task :app:mergeDexDebug
> Task :app:packageDebug
BUILD SUCCESSFUL in 2s
Output: app/build/outputs/apk/debug/app-debug.apk`
          );
          onBuildApk();
        } else {
          addOutput('stdout', `Gradle 8.7 running with Java 17 toolchain.\nTarget task: ${args.join(' ')}`);
        }
        break;

      default:
        addOutput('stderr', `bash: command not found: ${command}. Type "help" for a list of commands.`);
        break;
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleCommand(currentInput);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length > 0) {
        const nextIdx = historyIndex === -1 ? history.length - 1 : Math.max(0, historyIndex - 1);
        setHistoryIndex(nextIdx);
        setCurrentInput(history[nextIdx] || '');
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex !== -1) {
        const nextIdx = historyIndex + 1;
        if (nextIdx >= history.length) {
          setHistoryIndex(-1);
          setCurrentInput('');
        } else {
          setHistoryIndex(nextIdx);
          setCurrentInput(history[nextIdx]);
        }
      }
    }
  };

  return (
    <div
      id="terminal-panel"
      className={`border-t flex flex-col font-mono text-xs z-30 transition-all duration-200 shrink-0 ${
        isExpanded ? 'h-80 md:h-96 max-h-[70dvh]' : 'h-44 md:h-52 max-h-[45dvh]'
      }`}
      style={{
        borderColor: themeConfig.borderColor,
        backgroundColor: themeConfig.bg,
        color: themeConfig.textColor,
      }}
    >
      {/* Terminal Title Bar */}
      <div
        className="h-8 border-b px-3 flex items-center justify-between shrink-0 select-none overflow-x-auto"
        style={{
          backgroundColor: themeConfig.headerBg,
          borderColor: themeConfig.borderColor,
        }}
      >
        <div className="flex items-center gap-2 shrink-0">
          <TerminalIcon className="w-3.5 h-3.5 text-cyan-500 dark:text-cyan-400" />
          <span className="text-[11px] font-semibold">
            Terminal
          </span>
          <span className="hidden sm:inline px-1.5 py-0.2 rounded opacity-75 border text-[10px]"
            style={{ borderColor: themeConfig.borderColor }}
          >
            Gradle 8.7
          </span>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => handleCommand('./gradlew assembleDebug')}
            className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 text-[10px] font-medium transition-colors"
            title="Build debug APK with Gradle"
          >
            <Play className="w-3 h-3 fill-emerald-500 dark:fill-emerald-400" />
            <span className="hidden sm:inline">gradlew assembleDebug</span>
            <span className="sm:hidden">Build APK</span>
          </button>

          <button
            onClick={() => setOutputs([])}
            title="Clear Output"
            className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
          >
            <Trash2 className="w-3 h-3" />
          </button>

          <button
            onClick={() => setIsExpanded(!isExpanded)}
            title={isExpanded ? 'Collapse' : 'Expand'}
            className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10 transition-colors hidden sm:block"
          >
            {isExpanded ? <Minimize2 className="w-3 h-3" /> : <Maximize2 className="w-3 h-3" />}
          </button>

          <button
            onClick={onClose}
            title="Close Terminal"
            className="p-1 rounded opacity-70 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Terminal Output Area */}
      <div
        ref={scrollRef}
        onClick={() => inputRef.current?.focus()}
        className="flex-1 p-3 overflow-y-auto space-y-1 select-text"
        style={{
          backgroundColor: isDark ? '#08080a' : '#f8f8fa',
          color: themeConfig.textColor,
        }}
      >
        {outputs.map((out) => (
          <div key={out.id} className="leading-relaxed break-all">
            {out.type === 'command' && (
              <span className="text-cyan-600 dark:text-cyan-400 font-bold">{out.text}</span>
            )}
            {out.type === 'stdout' && (
              <span className="opacity-90 whitespace-pre-wrap">{out.text}</span>
            )}
            {out.type === 'stderr' && (
              <span className="text-rose-600 dark:text-rose-400 whitespace-pre-wrap">{out.text}</span>
            )}
            {out.type === 'system' && (
              <span className="text-emerald-600 dark:text-emerald-400 font-semibold whitespace-pre-wrap">{out.text}</span>
            )}
          </div>
        ))}

        {/* Active Prompt Input */}
        <div className="flex items-center gap-1.5 pt-1">
          <span className="text-cyan-600 dark:text-cyan-400 font-bold shrink-0">$</span>
          <input
            ref={inputRef}
            type="text"
            value={currentInput}
            onChange={(e) => setCurrentInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent focus:outline-none border-0 p-0 font-mono text-xs"
            style={{
              color: themeConfig.textColor,
              caretColor: themeConfig.accentColor,
            }}
            autoFocus
          />
        </div>
      </div>
    </div>
  );
};
