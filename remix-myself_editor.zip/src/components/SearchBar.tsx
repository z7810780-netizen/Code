import React, { useRef, useEffect } from 'react';
import {
  Search,
  Replace,
  ChevronDown,
  ChevronUp,
  X,
  CaseSensitive,
  WholeWord,
  Regex,
  ArrowRightLeft,
} from 'lucide-react';
import { SearchState, EditorTheme } from '../types';
import { THEMES } from '../utils/themes';

interface SearchBarProps {
  searchState: SearchState;
  onSearchChange: (updates: Partial<SearchState>) => void;
  onFindNext: () => void;
  onFindPrev: () => void;
  onReplaceCurrent: () => void;
  onReplaceAll: () => void;
  onClose: () => void;
  theme?: string;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchState,
  onSearchChange,
  onFindNext,
  onFindPrev,
  onReplaceCurrent,
  onReplaceAll,
  onClose,
  theme = 'monokai',
}) => {
  const findInputRef = useRef<HTMLInputElement>(null);
  const replaceInputRef = useRef<HTMLInputElement>(null);
  const themeConfig = THEMES[theme as EditorTheme] || THEMES['monokai'] || THEMES['vs-dark'];
  const isDark = themeConfig.isDark;

  useEffect(() => {
    if (searchState.isOpen && findInputRef.current) {
      findInputRef.current.focus();
      findInputRef.current.select();
    }
  }, [searchState.isOpen]);

  if (!searchState.isOpen) return null;

  return (
    <div
      id="editor-search-bar"
      className="absolute top-2 right-2 sm:right-4 z-40 border shadow-2xl rounded-2xl p-3 flex flex-col gap-2.5 w-[calc(100vw-16px)] sm:w-auto sm:min-w-[420px] sm:max-w-md backdrop-blur-lg text-xs animate-in fade-in slide-in-from-top-2 duration-150"
      style={{
        backgroundColor: isDark ? 'rgba(20, 20, 24, 0.98)' : 'rgba(255, 255, 255, 0.98)',
        borderColor: themeConfig.borderColor,
        color: themeConfig.textColor,
      }}
    >
      {/* Header bar with title and close */}
      <div
        className="flex items-center justify-between pb-1 border-b text-[11px] font-medium"
        style={{ borderColor: themeConfig.borderColor }}
      >
        <div className="flex items-center gap-1.5 font-semibold text-cyan-500 dark:text-cyan-400">
          <ArrowRightLeft className="w-3.5 h-3.5" />
          <span>Find & Replace</span>
        </div>
        <div className="flex items-center gap-2">
          {searchState.query && (
            <span className="text-[11px] font-mono font-bold text-amber-600 dark:text-amber-400">
              {searchState.matchesCount > 0
                ? `${searchState.currentMatchIndex + 1} of ${searchState.matchesCount} matches`
                : 'No matches found'}
            </span>
          )}
          <button
            onClick={onClose}
            title="Close (Esc)"
            className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Find Input Row */}
      <div className="flex items-center gap-1.5">
        <Search className="w-3.5 h-3.5 opacity-50 shrink-0 ml-0.5" />
        <div className="relative flex-1">
          <input
            ref={findInputRef}
            type="text"
            placeholder="Search query in code..."
            value={searchState.query}
            onChange={(e) => onSearchChange({ query: e.target.value })}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                if (e.shiftKey) onFindPrev();
                else onFindNext();
              } else if (e.key === 'Escape') {
                e.preventDefault();
                onClose();
              }
            }}
            className="w-full rounded-lg px-2.5 py-1.5 text-xs border focus:outline-none focus:ring-1 focus:ring-cyan-500"
            style={{
              backgroundColor: isDark ? '#09090b' : '#f4f4f5',
              borderColor: themeConfig.borderColor,
              color: themeConfig.textColor,
            }}
          />
        </div>

        {/* Search Modifiers */}
        <div
          className="flex items-center gap-0.5 border rounded-lg p-0.5 shrink-0"
          style={{
            borderColor: themeConfig.borderColor,
            backgroundColor: isDark ? '#09090b' : '#f4f4f5',
          }}
        >
          <button
            onClick={() => onSearchChange({ caseSensitive: !searchState.caseSensitive })}
            title="Match Case (Alt+C)"
            className={`p-1.5 rounded-md transition-colors ${
              searchState.caseSensitive
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                : 'opacity-60 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10'
            }`}
          >
            <CaseSensitive className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onSearchChange({ matchWholeWord: !searchState.matchWholeWord })}
            title="Match Whole Word (Alt+W)"
            className={`p-1.5 rounded-md transition-colors ${
              searchState.matchWholeWord
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                : 'opacity-60 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10'
            }`}
          >
            <WholeWord className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onSearchChange({ useRegex: !searchState.useRegex })}
            title="Use Regular Expression (Alt+R)"
            className={`p-1.5 rounded-md transition-colors ${
              searchState.useRegex
                ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/50'
                : 'opacity-60 hover:opacity-100 hover:bg-black/10 dark:hover:bg-white/10'
            }`}
          >
            <Regex className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Prev / Next */}
        <div className="flex items-center gap-0.5 shrink-0">
          <button
            onClick={onFindPrev}
            title="Previous Match (Shift+Enter)"
            disabled={!searchState.query || searchState.matchesCount === 0}
            className="p-1.5 rounded-lg border disabled:opacity-40 disabled:pointer-events-none transition-colors"
            style={{
              backgroundColor: isDark ? '#27272a' : '#e4e4e7',
              borderColor: themeConfig.borderColor,
            }}
          >
            <ChevronUp className="w-4 h-4" />
          </button>
          <button
            onClick={onFindNext}
            title="Next Match (Enter)"
            disabled={!searchState.query || searchState.matchesCount === 0}
            className="p-1.5 rounded-lg border disabled:opacity-40 disabled:pointer-events-none transition-colors"
            style={{
              backgroundColor: isDark ? '#27272a' : '#e4e4e7',
              borderColor: themeConfig.borderColor,
            }}
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Replace Input Row (Visible and Default) */}
      <div className="flex items-center gap-1.5">
        <Replace className="w-3.5 h-3.5 opacity-50 shrink-0 ml-0.5" />
        <input
          ref={replaceInputRef}
          type="text"
          placeholder="Replace with..."
          value={searchState.replaceQuery}
          onChange={(e) => onSearchChange({ replaceQuery: e.target.value })}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              onReplaceCurrent();
            }
          }}
          className="flex-1 rounded-lg px-2.5 py-1.5 text-xs border focus:outline-none focus:ring-1 focus:ring-cyan-500"
          style={{
            backgroundColor: isDark ? '#09090b' : '#f4f4f5',
            borderColor: themeConfig.borderColor,
            color: themeConfig.textColor,
          }}
        />

        {/* Replace Action Buttons */}
        <button
          onClick={onReplaceCurrent}
          disabled={!searchState.query || searchState.matchesCount === 0}
          className="px-2.5 py-1.5 border disabled:opacity-40 disabled:pointer-events-none rounded-lg text-xs font-semibold transition-colors shrink-0 active:scale-95"
          style={{
            backgroundColor: isDark ? '#27272a' : '#e4e4e7',
            borderColor: themeConfig.borderColor,
          }}
        >
          Replace
        </button>
        <button
          onClick={onReplaceAll}
          disabled={!searchState.query || searchState.matchesCount === 0}
          className="px-2.5 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white disabled:opacity-40 disabled:pointer-events-none rounded-lg text-xs font-bold transition-colors shrink-0 active:scale-95 shadow-xs"
        >
          Replace All
        </button>
      </div>
    </div>
  );
};
