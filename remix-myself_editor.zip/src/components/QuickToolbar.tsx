import React from 'react';
import {
  Undo,
  Redo,
  Scissors,
  Copy,
  Clipboard,
  Code,
  CornerDownLeft,
  Braces,
  Save,
  WrapText,
  Sparkles,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import { THEMES } from '../utils/themes';

interface QuickToolbarProps {
  onUndo: () => void;
  onRedo: () => void;
  onInsertSymbol: (symbol: string) => void;
  onToggleComment: () => void;
  onSave: () => void;
  onToggleWrap: () => void;
  onZoomIn?: () => void;
  onZoomOut?: () => void;
  onResetZoom?: () => void;
  zoomLevel?: number;
  isWrapped: boolean;
  theme: string;
}

export const QuickToolbar: React.FC<QuickToolbarProps> = ({
  onUndo,
  onRedo,
  onInsertSymbol,
  onToggleComment,
  onSave,
  onToggleWrap,
  onZoomIn,
  onZoomOut,
  onResetZoom,
  zoomLevel = 100,
  isWrapped,
  theme,
}) => {
  const themeConfig = THEMES[theme as keyof typeof THEMES] || THEMES['sophisticated-dark'] || THEMES['vs-dark'];
  const isDark = themeConfig.isDark;

  const quickSymbols = ['{', '}', '(', ')', '[', ']', '<', '>', '=', ':', ';', '"', "'", '`', '/', '!', '$', '.', '_', '->', '=>'];

  return (
    <div
      id="quick-mobile-toolbar"
      className="h-9 border-t flex items-center px-2 gap-1.5 overflow-x-auto select-none shrink-0 scrollbar-none z-20 transition-colors"
      style={{
        backgroundColor: themeConfig.sidebarBg,
        borderColor: themeConfig.borderColor,
        color: themeConfig.textColor,
      }}
    >
      {/* Quick Action buttons */}
      <button
        onClick={onUndo}
        title="Undo"
        className="p-1.5 rounded-md opacity-60 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
      >
        <Undo className="w-3.5 h-3.5" />
      </button>
      <button
        onClick={onRedo}
        title="Redo"
        className="p-1.5 rounded-md opacity-60 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
      >
        <Redo className="w-3.5 h-3.5" />
      </button>

      <button
        onClick={onToggleComment}
        title="Toggle Comment (//)"
        className="px-2 py-1 rounded-md text-[11px] font-mono opacity-60 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
      >
        //
      </button>

      <button
        onClick={onToggleWrap}
        title="Toggle Word Wrap"
        className={`p-1.5 rounded-md transition-colors ${
          isWrapped
            ? 'bg-black/15 dark:bg-white/20 opacity-100 font-bold'
            : 'opacity-60 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/10'
        }`}
      >
        <WrapText className="w-3.5 h-3.5" />
      </button>

      {/* Zoom In/Out on mobile bar */}
      <div className="flex items-center gap-0.5 border rounded-md px-1 py-0.5 text-xs font-mono"
        style={{
          borderColor: themeConfig.borderColor,
          backgroundColor: isDark ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.03)',
        }}
      >
        <button
          onClick={onZoomOut}
          title="Zoom Out (Ctrl+-)"
          className="p-1 rounded opacity-60 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
        >
          <ZoomOut className="w-3 h-3" />
        </button>
        <button
          onClick={onResetZoom}
          title="Reset Zoom to 100%"
          className="px-1 text-[10px] font-semibold opacity-80 hover:opacity-100"
        >
          {zoomLevel}%
        </button>
        <button
          onClick={onZoomIn}
          title="Zoom In (Ctrl++)"
          className="p-1 rounded opacity-60 hover:opacity-100 hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
        >
          <ZoomIn className="w-3 h-3" />
        </button>
      </div>

      <div
        className="h-4 w-px mx-0.5 shrink-0 opacity-20"
        style={{ backgroundColor: themeConfig.borderColor }}
      />

      {/* Code Insertion Quick Chips */}
      <div className="flex items-center gap-1">
        {quickSymbols.map((sym) => (
          <button
            key={sym}
            onClick={() => onInsertSymbol(sym)}
            className="px-2.5 py-1 rounded-md border text-xs font-mono font-medium transition-all shrink-0 active:scale-95 shadow-2xs hover:opacity-100"
            style={{
              backgroundColor: isDark ? '#121212' : '#f4f4f5',
              borderColor: themeConfig.borderColor,
              color: themeConfig.textColor,
            }}
          >
            {sym}
          </button>
        ))}
      </div>
    </div>
  );
};
