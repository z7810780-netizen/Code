import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  RotateCw,
  Smartphone,
  Tablet,
  Monitor,
  Terminal,
  ExternalLink,
  X,
  Sparkles,
} from 'lucide-react';
import { EditorFile } from '../types';

interface LivePreviewProps {
  files: EditorFile[];
  isOpen: boolean;
  onClose: () => void;
}

type DeviceMode = 'responsive' | 'mobile' | 'tablet' | 'desktop';

export const LivePreview: React.FC<LivePreviewProps> = ({ files, isOpen, onClose }) => {
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('responsive');
  const [consoleLogs, setConsoleLogs] = useState<{ type: string; message: string; time: string }[]>([]);
  const [showConsole, setShowConsole] = useState(false);
  const [key, setKey] = useState(0);
  const iframeRef = useRef<HTMLIFrameElement>(null);

  const htmlFiles = files.filter((f) => f.name.endsWith('.html') || f.language === 'html');
  const [selectedHtmlFileId, setSelectedHtmlFileId] = useState<string>(() => {
    return htmlFiles[0]?.id || '';
  });

  // Keep selected file in sync if valid
  const currentHtmlFile = htmlFiles.find((f) => f.id === selectedHtmlFileId) || htmlFiles[0] || files.find((f) => f.name.endsWith('.html') || f.language === 'html');

  const cssFiles = files.filter((f) => f.name.endsWith('.css') || f.language === 'css');
  const jsFiles = files.filter((f) => (f.name.endsWith('.js') || f.language === 'javascript') && !f.name.endsWith('.config.js'));

  // Generate bundled HTML
  const generatePreviewDoc = () => {
    let rawHtml = currentHtmlFile?.content || `<!DOCTYPE html>
<html>
<head><title>Preview</title></head>
<body style="font-family:sans-serif;padding:24px;text-align:center;">
  <h2>No HTML file found</h2>
  <p>Create an <code>.html</code> file to preview.</p>
</body>
</html>`;

    // Inject CSS
    const inlineCss = cssFiles.map((c) => `<style id="injected-css-${c.name}">\n${c.content}\n</style>`).join('\n');

    // Inject JS with console interceptor
    const consoleInterceptor = `
      <script>
        (function() {
          const origLog = console.log;
          const origWarn = console.warn;
          const origErr = console.error;
          function post(type, args) {
            try {
              window.parent.postMessage({
                source: 'myself-editor-preview',
                type: type,
                message: Array.from(args).map(a => typeof a === 'object' ? JSON.stringify(a) : String(a)).join(' ')
              }, '*');
            } catch(e) {}
          }
          console.log = function() { post('log', arguments); origLog.apply(console, arguments); };
          console.warn = function() { post('warn', arguments); origWarn.apply(console, arguments); };
          console.error = function() { post('error', arguments); origErr.apply(console, arguments); };
          window.onerror = function(msg, url, line) {
            post('error', ['Uncaught Error: ' + msg + ' (line ' + line + ')']);
          };
        })();
      </script>
    `;

    const inlineJs = jsFiles.map((j) => `<script id="injected-js-${j.name}">\n${j.content}\n</script>`).join('\n');

    // Insert interceptor and styles right before </head> or at start
    if (rawHtml.includes('</head>')) {
      rawHtml = rawHtml.replace('</head>', `${consoleInterceptor}\n${inlineCss}\n</head>`);
    } else {
      rawHtml = `${consoleInterceptor}\n${inlineCss}\n${rawHtml}`;
    }

    // Insert scripts right before </body> or at end
    if (rawHtml.includes('</body>')) {
      rawHtml = rawHtml.replace('</body>', `${inlineJs}\n</body>`);
    } else {
      rawHtml = `${rawHtml}\n${inlineJs}`;
    }

    return rawHtml;
  };

  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (e.data && e.data.source === 'myself-editor-preview') {
        const time = new Date().toLocaleTimeString();
        setConsoleLogs((prev) => [
          ...prev.slice(-49),
          { type: e.data.type, message: e.data.message, time },
        ]);
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  if (!isOpen) return null;

  const handleRefresh = () => {
    setKey((prev) => prev + 1);
  };

  const getContainerWidth = () => {
    switch (deviceMode) {
      case 'mobile':
        return 'w-full max-w-[360px] aspect-[9/16] max-h-[82vh] shadow-2xl rounded-3xl border-[8px] border-zinc-800';
      case 'tablet':
        return 'w-[768px] h-[800px] shadow-2xl rounded-xl border-4 border-zinc-700';
      case 'desktop':
        return 'w-[1024px] h-[700px] shadow-2xl rounded-lg border-2 border-zinc-700';
      default:
        return 'w-full h-full';
    }
  };

  return (
    <div
      id="live-preview-panel"
      className="flex-1 flex flex-col h-full bg-zinc-950 relative select-none"
    >
      {/* Top Bar */}
      <div className="min-h-11 bg-zinc-900 border-b border-zinc-800 px-3 py-1.5 flex items-center justify-between flex-wrap gap-2 shrink-0">
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={onClose}
            title="Exit Fullscreen Preview"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/20 border border-red-500/40 text-red-300 hover:bg-red-500/30 font-semibold text-xs transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
            <span>Exit</span>
          </button>

          <div className="h-4 w-px bg-zinc-800 mx-1 hidden sm:block" />

          {/* HTML File Selector Dropdown */}
          {htmlFiles.length > 0 && (
            <select
              value={currentHtmlFile?.id || ''}
              onChange={(e) => setSelectedHtmlFileId(e.target.value)}
              title="Select HTML file to preview"
              className="bg-zinc-950 text-white text-xs px-2.5 py-1.5 rounded-lg border border-zinc-800 outline-none cursor-pointer font-mono"
            >
              {htmlFiles.map((hf) => (
                <option key={hf.id} value={hf.id}>
                  {hf.name}
                </option>
              ))}
            </select>
          )}

          {/* Device toggle buttons */}
          <div className="flex items-center bg-zinc-950 rounded-lg p-0.5 border border-zinc-800">
            <button
              onClick={() => setDeviceMode('responsive')}
              title="Fluid Responsive"
              className={`px-2 py-1 rounded text-xs flex items-center gap-1 transition-colors ${
                deviceMode === 'responsive'
                  ? 'bg-zinc-800 text-white font-medium shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Fluid
            </button>
            <button
              onClick={() => setDeviceMode('mobile')}
              title="Mobile (375x667)"
              className={`p-1 rounded transition-colors ${
                deviceMode === 'mobile'
                  ? 'bg-zinc-800 text-white shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setDeviceMode('tablet')}
              title="Tablet (768x1024)"
              className={`p-1 rounded transition-colors ${
                deviceMode === 'tablet'
                  ? 'bg-zinc-800 text-white shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Tablet className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setDeviceMode('desktop')}
              title="Desktop (1024px)"
              className={`p-1 rounded transition-colors ${
                deviceMode === 'desktop'
                  ? 'bg-zinc-800 text-white shadow-xs'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Monitor className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right action controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowConsole(!showConsole)}
            title="Toggle Console output"
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs border transition-colors ${
              showConsole
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                : 'text-zinc-400 hover:text-white border-zinc-800 hover:bg-zinc-800'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Console</span>
            {consoleLogs.length > 0 && (
              <span className="px-1.5 py-0.2 bg-zinc-800 rounded-full text-[10px] text-zinc-300">
                {consoleLogs.length}
              </span>
            )}
          </button>

          <button
            onClick={handleRefresh}
            title="Reload Preview"
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <RotateCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Frame Container */}
      <div className="flex-1 overflow-auto bg-zinc-950 flex items-center justify-center p-2 relative">
        <div className={`transition-all duration-200 bg-white overflow-hidden ${getContainerWidth()}`}>
          <iframe
            key={key}
            ref={iframeRef}
            srcDoc={generatePreviewDoc()}
            title="Live Preview"
            sandbox="allow-scripts allow-modals allow-same-origin allow-forms"
            className="w-full h-full border-0 bg-white"
          />
        </div>

        {/* Live Console Drawer */}
        {showConsole && (
          <div className="absolute bottom-0 left-0 right-0 h-48 bg-zinc-900/95 border-t border-zinc-700/80 shadow-2xl backdrop-blur-md flex flex-col z-30">
            <div className="h-7 bg-zinc-950 px-3 flex items-center justify-between border-b border-zinc-800 text-[11px] text-zinc-400">
              <div className="flex items-center gap-2 font-mono">
                <Terminal className="w-3 h-3 text-cyan-400" />
                <span>Console Output</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setConsoleLogs([])}
                  className="hover:text-white text-[10px] underline cursor-pointer"
                >
                  Clear Logs
                </button>
                <button
                  onClick={() => setShowConsole(false)}
                  className="hover:text-white"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-2 font-mono text-xs space-y-1 select-text">
              {consoleLogs.length === 0 ? (
                <div className="text-zinc-600 italic">No console logs yet.</div>
              ) : (
                consoleLogs.map((log, i) => (
                  <div
                    key={i}
                    className={`flex items-start gap-2 py-0.5 border-b border-zinc-800/40 text-[11px] ${
                      log.type === 'error'
                        ? 'text-rose-400 bg-rose-950/20'
                        : log.type === 'warn'
                        ? 'text-amber-400 bg-amber-950/20'
                        : 'text-zinc-300'
                    }`}
                  >
                    <span className="text-zinc-500 text-[10px] shrink-0">{log.time}</span>
                    <span className="shrink-0 font-bold uppercase text-[9px] px-1 rounded bg-zinc-800 text-zinc-400">
                      {log.type}
                    </span>
                    <span className="break-all">{log.message}</span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
