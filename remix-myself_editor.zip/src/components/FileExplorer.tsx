import React, { useState, useRef } from 'react';
import {
  FilePlus,
  FolderPlus,
  Upload,
  Download,
  Trash2,
  Edit2,
  Copy,
  FileCode,
  Folder,
  FolderOpen,
  ChevronRight,
  ChevronDown,
  Search,
  Check,
  X,
  Code2,
  FileText,
  Share2,
  MoreVertical,
  HardDrive,
} from 'lucide-react';
import { EditorFile, EditorTheme } from '../types';
import { THEMES } from '../utils/themes';

interface FileExplorerProps {
  files: EditorFile[];
  activeFileId: string;
  onSelectFile: (fileId: string) => void;
  onCreateFile: (name: string, content?: string) => void;
  onRenameFile: (fileId: string, newName: string) => void;
  onDeleteFile: (fileId: string) => void;
  onDuplicateFile: (fileId: string) => void;
  isOpen: boolean;
  onClose: () => void;
  onOpenExportApk?: () => void;
  onOpenPhoneFolder?: () => void;
  syncedFolderName?: string | null;
  theme?: string;
}

export const FileExplorer: React.FC<FileExplorerProps> = ({
  files,
  activeFileId,
  onSelectFile,
  onCreateFile,
  onRenameFile,
  onDeleteFile,
  onDuplicateFile,
  isOpen,
  onClose,
  onOpenExportApk,
  onOpenPhoneFolder,
  syncedFolderName,
  theme = 'monokai',
}) => {
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [editingFileId, setEditingFileId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [searchFilter, setSearchFilter] = useState('');
  const [contextMenuFile, setContextMenuFile] = useState<EditorFile | null>(null);
  const pressTimerRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleTouchStart = (file: EditorFile) => {
    pressTimerRef.current = window.setTimeout(() => {
      setContextMenuFile(file);
    }, 500);
  };

  const handleTouchEnd = () => {
    if (pressTimerRef.current) {
      clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
  };

  const themeConfig = THEMES[theme as EditorTheme] || THEMES['monokai'] || THEMES['vs-dark'];
  const isDark = themeConfig.isDark;

  if (!isOpen) return null;

  const handleStartCreate = () => {
    setIsCreatingFile(true);
    setNewFileName('');
  };

  const handleConfirmCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newFileName.trim();
    if (trimmed) {
      onCreateFile(trimmed, '');
      setIsCreatingFile(false);
      setNewFileName('');
    }
  };

  const handleStartRename = (file: EditorFile, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingFileId(file.id);
    setRenameValue(file.name);
  };

  const handleConfirmRename = (fileId: string) => {
    const trimmed = renameValue.trim();
    if (trimmed) {
      onRenameFile(fileId, trimmed);
    }
    setEditingFileId(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFiles = e.target.files;
    if (!uploadedFiles || uploadedFiles.length === 0) return;

    (Array.from(uploadedFiles) as File[]).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const content = ev.target?.result as string;
        onCreateFile(file.name, content || '');
      };
      reader.readAsText(file);
    });

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const getFileIcon = (fileName: string) => {
    const ext = fileName.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'html':
      case 'htm':
        return <span className="text-white/90 font-bold text-[9px] px-1 py-0.2 bg-white/10 rounded">HTML</span>;
      case 'css':
      case 'scss':
        return <span className="text-white/80 font-bold text-[9px] px-1 py-0.2 bg-white/10 rounded">CSS</span>;
      case 'js':
      case 'jsx':
        return <span className="text-white font-bold text-[9px] px-1 py-0.2 bg-white/15 rounded">JS</span>;
      case 'ts':
      case 'tsx':
        return <span className="text-white font-bold text-[9px] px-1 py-0.2 bg-white/15 rounded">TS</span>;
      case 'kt':
      case 'kts':
        return <span className="text-white font-bold text-[9px] px-1 py-0.2 bg-white/15 rounded">KT</span>;
      case 'java':
        return <span className="text-white font-bold text-[9px] px-1 py-0.2 bg-white/15 rounded">JAVA</span>;
      case 'py':
        return <span className="text-white font-bold text-[9px] px-1 py-0.2 bg-white/15 rounded">PY</span>;
      case 'json':
        return <span className="text-white/70 font-bold text-[9px] px-1 py-0.2 bg-white/10 rounded">JSON</span>;
      case 'md':
        return <span className="text-white/60 font-bold text-[9px] px-1 py-0.2 bg-white/10 rounded">MD</span>;
      default:
        return <FileCode className="w-3.5 h-3.5 text-white/50" />;
    }
  };

  const filteredFiles = files.filter((f) =>
    f.name.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div
      id="file-explorer-sidebar"
      className="w-72 max-w-[85vw] border-r flex flex-col h-full shrink-0 select-none text-xs transition-colors shadow-2xl md:shadow-none"
      style={{
        backgroundColor: themeConfig.sidebarBg,
        borderColor: themeConfig.borderColor,
        color: themeConfig.textColor,
      }}
    >
      {/* Title Header */}
      <div
        className="h-11 border-b px-2.5 flex items-center justify-between shrink-0 gap-1.5"
        style={{
          backgroundColor: themeConfig.headerBg,
          borderColor: themeConfig.borderColor,
        }}
      >
        <button
          onClick={onOpenPhoneFolder}
          title={
            syncedFolderName
              ? `Directly connected to: ${syncedFolderName}. Click to switch phone storage folder.`
              : 'Click to open and sync phone storage folder directly'
          }
          className="flex items-center gap-1.5 px-2 py-1 rounded-lg text-[11px] font-bold uppercase border transition-all active:scale-95 text-left min-w-0 shadow-xs cursor-pointer hover:brightness-125"
          style={{
            borderColor: syncedFolderName ? '#10b981' : themeConfig.borderColor,
            backgroundColor: syncedFolderName
              ? 'rgba(16, 185, 129, 0.15)'
              : isDark
              ? 'rgba(255, 255, 255, 0.08)'
              : 'rgba(0, 0, 0, 0.06)',
            color: syncedFolderName ? '#10b981' : themeConfig.textColor,
          }}
        >
          <Folder className="w-3.5 h-3.5 shrink-0 text-emerald-400" />
          <span className="serif shrink-0 tracking-wider">EXPLORER</span>
          <span
            className={`text-[9px] font-mono px-1.5 py-0.5 rounded border shrink-0 truncate max-w-[85px] normal-case ${
              syncedFolderName
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-semibold'
                : 'bg-white/10 text-white/70 border-white/20'
            }`}
          >
            {syncedFolderName ? `📁 ${syncedFolderName}` : '📂 Open'}
          </span>
        </button>

        <div className="flex items-center gap-1">
          <button
            onClick={handleStartCreate}
            title="New File"
            className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100 transition-colors"
          >
            <FilePlus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              if (onOpenPhoneFolder) {
                onOpenPhoneFolder();
              } else {
                fileInputRef.current?.click();
              }
            }}
            title="Import File / Open Phone Storage Folder"
            className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100 transition-colors text-emerald-400"
          >
            <Upload className="w-3.5 h-3.5" />
          </button>
          {onOpenExportApk && (
            <button
              onClick={onOpenExportApk}
              title="Export Project (.ZIP)"
              className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100 transition-colors text-cyan-500"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            onClick={onClose}
            title="Close Explorer"
            className="p-1 rounded-md hover:bg-black/10 dark:hover:bg-white/10 opacity-70 hover:opacity-100 transition-colors md:hidden ml-1 text-red-400"
          >
            <X className="w-4 h-4" />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>
      </div>

      {/* Filter bar */}
      <div
        className="p-2 border-b"
        style={{ borderColor: themeConfig.borderColor }}
      >
        <div className="relative">
          <Search className="w-3 h-3 opacity-40 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search files..."
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            className="w-full rounded-lg pl-7 pr-6 py-1 text-[11px] border focus:outline-none focus:ring-1 transition-colors"
            style={{
              backgroundColor: isDark ? '#0c0c0c' : '#ffffff',
              borderColor: themeConfig.borderColor,
              color: themeConfig.textColor,
            }}
          />
          {searchFilter && (
            <button
              onClick={() => setSearchFilter('')}
              className="absolute right-2 top-1/2 -translate-y-1/2 opacity-40 hover:opacity-100"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      {/* File List */}
      <div className="flex-1 overflow-y-auto p-1.5 space-y-0.5">
        {/* New File Inline Form */}
        {isCreatingFile && (
          <form
            onSubmit={handleConfirmCreate}
            className="p-1.5 rounded-lg border flex items-center gap-1.5 mb-1 shadow-md"
            style={{
              backgroundColor: isDark ? '#141414' : '#f4f4f5',
              borderColor: themeConfig.accentColor,
            }}
          >
            <FilePlus className="w-3.5 h-3.5 shrink-0" style={{ color: themeConfig.accentColor }} />
            <input
              type="text"
              placeholder="e.g. script.js"
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') setIsCreatingFile(false);
              }}
              autoFocus
              className="flex-1 rounded px-1.5 py-0.5 text-xs border focus:outline-none"
              style={{
                backgroundColor: isDark ? '#000000' : '#ffffff',
                borderColor: themeConfig.borderColor,
                color: themeConfig.textColor,
              }}
            />
            <button
              type="submit"
              className="p-0.5 text-emerald-500 hover:text-emerald-400"
            >
              <Check className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setIsCreatingFile(false)}
              className="p-0.5 opacity-40 hover:opacity-100"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </form>
        )}

        {filteredFiles.length === 0 ? (
          <div className="p-4 text-center opacity-40 text-xs italic">
            No files found
          </div>
        ) : (
          filteredFiles.map((file) => {
            const isActive = file.id === activeFileId;
            const isEditing = editingFileId === file.id;

            return (
              <div
                key={file.id}
                onClick={() => onSelectFile(file.id)}
                onTouchStart={() => handleTouchStart(file)}
                onTouchEnd={handleTouchEnd}
                onMouseDown={() => handleTouchStart(file)}
                onMouseUp={handleTouchEnd}
                className={`group flex items-center justify-between px-2.5 py-1.5 rounded-lg cursor-pointer transition-all border ${
                  isActive
                    ? 'font-medium shadow-xs'
                    : 'border-transparent hover:bg-black/5 dark:hover:bg-white/5 opacity-80 hover:opacity-100'
                }`}
                style={{
                  backgroundColor: isActive
                    ? (isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.08)')
                    : 'transparent',
                  borderColor: isActive ? themeConfig.borderColor : 'transparent',
                }}
              >
                <div className="flex items-center gap-2 min-w-0 flex-1 mr-1">
                  <div className="w-6 flex items-center justify-center shrink-0">
                    {getFileIcon(file.name)}
                  </div>

                  {isEditing ? (
                    <input
                      type="text"
                      value={renameValue}
                      onChange={(e) => setRenameValue(e.target.value)}
                      onClick={(e) => e.stopPropagation()}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleConfirmRename(file.id);
                        if (e.key === 'Escape') setEditingFileId(null);
                      }}
                      onBlur={() => handleConfirmRename(file.id)}
                      autoFocus
                      className="border rounded px-1 text-xs focus:outline-none w-full font-mono"
                      style={{
                        backgroundColor: isDark ? '#000000' : '#ffffff',
                        borderColor: themeConfig.borderColor,
                        color: themeConfig.textColor,
                      }}
                    />
                  ) : (
                    <span className="truncate font-mono text-xs">
                      {file.name}
                    </span>
                  )}
                </div>

                {/* Options / Action Menu Button (Also accessible via Tap & Hold) */}
                {!isEditing && (
                  <div className="flex items-center gap-0.5 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setContextMenuFile(file);
                      }}
                      title="File Options (Tap & Hold or click)"
                      className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10 opacity-60 hover:opacity-100 transition-opacity"
                    >
                      <MoreVertical className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Tap & Hold Context Menu Modal */}
      {contextMenuFile && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#121214] border border-zinc-700 rounded-xl p-4 max-w-xs w-full shadow-2xl text-white space-y-3">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
              <span className="font-mono font-semibold text-xs truncate max-w-[200px]" style={{ color: themeConfig.accentColor }}>
                {contextMenuFile.name}
              </span>
              <button onClick={() => setContextMenuFile(null)} className="opacity-50 hover:opacity-100 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex flex-col gap-1.5 text-xs">
              <button
                onClick={() => {
                  onSelectFile(contextMenuFile.id);
                  setContextMenuFile(null);
                }}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-left transition-colors font-medium cursor-pointer"
              >
                <FolderOpen className="w-4 h-4 text-cyan-400" />
                <span>Open File</span>
              </button>

              <button
                onClick={() => {
                  const blob = new Blob([contextMenuFile.content], { type: 'text/plain;charset=utf-8' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = contextMenuFile.name;
                  a.click();
                  URL.revokeObjectURL(url);
                  setContextMenuFile(null);
                }}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-left transition-colors font-medium cursor-pointer"
              >
                <Share2 className="w-4 h-4 text-emerald-400" />
                <span>Share / Download File</span>
              </button>

              <button
                onClick={() => {
                  const file = contextMenuFile;
                  setContextMenuFile(null);
                  setEditingFileId(file.id);
                  setRenameValue(file.name);
                }}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-left transition-colors font-medium cursor-pointer"
              >
                <Edit2 className="w-4 h-4 text-amber-400" />
                <span>Rename File</span>
              </button>

              <button
                onClick={() => {
                  onDeleteFile(contextMenuFile.id);
                  setContextMenuFile(null);
                }}
                className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-left transition-colors font-medium text-red-400 cursor-pointer border border-red-500/30"
              >
                <Trash2 className="w-4 h-4 text-red-400" />
                <span>Delete File</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer Info */}
      <div
        className="p-2.5 border-t text-[10px] opacity-50 flex items-center justify-between"
        style={{
          backgroundColor: themeConfig.headerBg,
          borderColor: themeConfig.borderColor,
        }}
      >
        <span>{files.length} files</span>
        <span className="font-mono tracking-wider uppercase">MYself_SINGH</span>
      </div>
    </div>
  );
};
