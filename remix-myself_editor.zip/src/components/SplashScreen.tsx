import React, { useEffect, useState } from 'react';
import { ArrowRight, Code2 } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
  durationMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  durationMs = 2800,
}) => {
  const [progress, setProgress] = useState(0);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [imageError, setImageError] = useState(false);

  useEffect(() => {
    const startTime = Date.now();
    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / (durationMs - 400)) * 100));
      setProgress(pct);

      if (elapsed >= durationMs - 400) {
        setIsFadingOut(true);
      }

      if (elapsed >= durationMs) {
        clearInterval(interval);
        onFinish();
      }
    }, 30);

    return () => clearInterval(interval);
  }, [durationMs, onFinish]);

  return (
    <div
      id="myself-singh-loader"
      className={`fixed inset-0 z-[999999] flex items-center justify-center transition-opacity duration-500 ease-out select-none ${
        isFadingOut ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      style={{
        background:
          'radial-gradient(circle at center, #1c1c20 0%, #0c0c0e 45%, #050505 100%)',
        color: '#ffffff',
      }}
    >
      {/* Skip Button */}
      <button
        onClick={onFinish}
        className="absolute top-6 right-6 flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium text-white/60 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all cursor-pointer backdrop-blur-md shadow-lg"
        title="Skip intro"
      >
        <span>Skip</span>
        <ArrowRight className="w-3.5 h-3.5" />
      </button>

      <div className="w-[90%] max-w-[420px] text-center flex flex-col items-center">
        {/* Logo */}
        {!imageError ? (
          <img
            className="w-[120px] h-[120px] object-cover rounded-[28px] mb-[25px] shadow-[0_20px_60px_rgba(0,0,0,0.8)] animate-in fade-in zoom-in-75 duration-700 border border-white/15"
            src="https://i.ibb.co/m5z9k5gN/file-00000000f12071fa8b8a18fc6b32d937.png"
            alt="MYself_SINGH"
            onError={() => setImageError(true)}
            referrerPolicy="no-referrer"
          />
        ) : (
          <div className="w-[120px] h-[120px] rounded-[28px] mb-[25px] bg-[#0e0e0e] flex items-center justify-center shadow-[0_20px_60px_rgba(0,0,0,0.8)] border border-white/20 animate-in fade-in zoom-in-75 duration-700">
            <span className="serif text-3xl font-black text-white">S</span>
          </div>
        )}

        {/* Title */}
        <h1 className="serif m-0 mb-2 text-[28px] sm:text-[32px] font-normal tracking-[0.2em] uppercase text-white">
          MYself_SINGH
        </h1>

        {/* Subtitle */}
        <div className="m-0 mb-[36px] text-white/40 text-[11px] tracking-[0.25em] uppercase font-mono">
          Sophisticated Studio • Mobile IDE
        </div>

        {/* Progress Bar Track */}
        <div className="w-full max-w-[280px] h-[3px] mx-auto overflow-hidden rounded-full bg-white/10 relative">
          <div
            className="h-full rounded-full bg-white transition-all ease-linear"
            style={{
              width: `${progress}%`,
              boxShadow: '0 0 14px rgba(255, 255, 255, 0.9)',
            }}
          />
        </div>

        {/* Loading status & percentage */}
        <div className="mt-[15px] text-white/50 text-[11px] tracking-[0.2em] font-mono flex items-center justify-center gap-2">
          <span>INITIALIZING</span>
          <span className="text-white font-semibold">{progress}%</span>
        </div>

        {/* Creator Info */}
        <div className="mt-[44px] text-white/30 text-[9px] tracking-[0.3em] uppercase font-mono">
          STUDIO EDITION
          <strong className="serif block mt-[6px] text-white/90 text-[13px] tracking-[0.2em] font-medium">
            MYself_SINGH
          </strong>
        </div>
      </div>
    </div>
  );
};
