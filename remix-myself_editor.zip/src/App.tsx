import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  EditorFile,
  EditorSettings,
  EditorTheme,
  SearchState,
} from './types';
import { DEFAULT_FILES } from './utils/defaultFiles';
import { THEMES } from './utils/themes';
import { detectLanguage } from './utils/syntax';
import {
  openDeviceFolder,
  saveFileToDeviceStorage,
  createFileInDeviceFolder,
  deleteFileFromDeviceFolder,
} from './utils/localStorageAccess';
import { SplashScreen } from './components/SplashScreen';
import { Header } from './components/Header';
import { TabsBar } from './components/TabsBar';
import { FileExplorer } from './components/FileExplorer';
import { EditorArea } from './components/EditorArea';
import { QuickToolbar } from './components/QuickToolbar';
import { LivePreview } from './components/LivePreview';
import { TerminalPanel } from './components/TerminalPanel';
import { SearchBar } from './components/SearchBar';
import { SettingsModal } from './components/SettingsModal';
import { GoToLineModal } from './components/GoToLineModal';
import { ShortcutsModal } from './components/ShortcutsModal';
import { ExportApkModal } from './components/ExportApkModal';

const DEFAULT_SETTINGS: EditorSettings = {
  theme: 'monokai',
  fontSize: 14,
  fontFamily: '"JetBrains Mono", "Fira Code", Consolas, monospace',
  tabSize: 2,
  useSpaces: true,
  wordWrap: false,
  autoCloseBrackets: true,
  autoCloseQuotes: true,
  autoIndent: true,
  showLineNumbers: true,
  highlightActiveLine: true,
  showWhitespace: false,
  autoSave: true,
  autoSaveDelay: 1000,
  defaultLineEnding: 'LF',
  defaultEncoding: 'UTF-8',
  showMinimap: false,
};

export default function App() {
  // Splash Screen State (Seamless 2.8s fade without black screen gap)
  const [showSplash, setShowSplash] = useState(true);

  // Files & Tabs State
  const [files, setFiles] = useState<EditorFile[]>(() => {
    try {
      const saved = localStorage.getItem('myself_editor_files');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    // Inject user's exported files if running from InfinityFree ZIP
    if ((window as any).__INITIAL_FILES__) {
      return (window as any).__INITIAL_FILES__;
    }
    return DEFAULT_FILES;
  });

  const [activeFileId, setActiveFileId] = useState<string>(() => {
    return files[0]?.id || 'file-index-html';
  });

  const [openFileIds, setOpenFileIds] = useState<string[]>(() => {
    return files.slice(0, 4).map((f) => f.id);
  });

  // Settings State
  const [settings, setSettings] = useState<EditorSettings>(() => {
    try {
      const saved = localStorage.getItem('myself_editor_settings');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.theme || parsed.theme === 'sophisticated-dark') {
          parsed.theme = 'monokai';
        }
        return { ...DEFAULT_SETTINGS, ...parsed };
      }
    } catch (e) {}
    return { ...DEFAULT_SETTINGS, theme: 'monokai' };
  });

  // UI Panels State
  const [isExplorerOpen, setIsExplorerOpen] = useState(true);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);

  // Modals State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);
  const [isGoToLineOpen, setIsGoToLineOpen] = useState(false);
  const [isExportApkOpen, setIsExportApkOpen] = useState(false);
  const [unsavedCloseFileId, setUnsavedCloseFileId] = useState<string | null>(null);

  // Search State
  const [searchState, setSearchState] = useState<SearchState>({
    isOpen: false,
    query: '',
    replaceQuery: '',
    caseSensitive: false,
    matchWholeWord: false,
    useRegex: false,
    searchInSelection: false,
    matchesCount: 0,
    currentMatchIndex: 0,
  });

  // History Stacks for Undo/Redo
  const [undoStack, setUndoStack] = useState<Record<string, string[]>>({});
  const [redoStack, setRedoStack] = useState<Record<string, string[]>>({});

  // Direct Phone Storage Sync State
  const [syncedFolderName, setSyncedFolderName] = useState<string | null>(null);
  const [activeDirHandle, setActiveDirHandle] = useState<any>(null);

  const activeFile = files.find((f) => f.id === activeFileId) || null;

  // Open Direct Phone Storage Folder
  const handleOpenPhoneFolder = async () => {
    try {
      const result = await openDeviceFolder();
      if (!result || !result.files || result.files.length === 0) return;

      setFiles(result.files);
      setOpenFileIds(result.files.slice(0, 5).map((f) => f.id));
      if (result.files[0]) {
        setActiveFileId(result.files[0].id);
      }
      setSyncedFolderName(result.folderName);
      setActiveDirHandle(result.dirHandle);
    } catch (e) {
      console.error('Error opening phone storage folder:', e);
    }
  };

  const MIN_FONT_SIZE = 10;
  const MAX_FONT_SIZE = 28;
  const DEFAULT_FONT_SIZE = 14;

  const handleZoomIn = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      fontSize: Math.min(MAX_FONT_SIZE, prev.fontSize + 2),
    }));
  }, []);

  const handleZoomOut = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      fontSize: Math.max(MIN_FONT_SIZE, prev.fontSize - 2),
    }));
  }, []);

  const handleResetZoom = useCallback(() => {
    setSettings((prev) => ({
      ...prev,
      fontSize: DEFAULT_FONT_SIZE,
    }));
  }, []);

  const handleToggleTheme = useCallback(() => {
    setSettings((prev) => {
      const currentThemeConfig = THEMES[prev.theme] || THEMES['monokai'];
      const nextTheme: EditorTheme = currentThemeConfig.isDark ? 'sophisticated-light' : 'monokai';
      return {
        ...prev,
        theme: nextTheme,
      };
    });
  }, []);

  const zoomLevel = Math.round((settings.fontSize / DEFAULT_FONT_SIZE) * 100);

  // Sync document & body styling with active theme
  useEffect(() => {
    const currentTheme = THEMES[settings.theme] || THEMES['monokai'];
    document.documentElement.style.backgroundColor = currentTheme.bg;
    document.body.style.backgroundColor = currentTheme.bg;
    document.body.style.color = currentTheme.textColor;
    if (currentTheme.isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.theme]);

  // Persist files in localStorage
  useEffect(() => {
    try {
      localStorage.setItem('myself_editor_files', JSON.stringify(files));
    } catch (e) {}
  }, [files]);

  // Persist settings in localStorage
  useEffect(() => {
    try {
      localStorage.setItem('myself_editor_settings', JSON.stringify(settings));
    } catch (e) {}
  }, [settings]);

  // Calculate search matches count
  useEffect(() => {
    if (!searchState.isOpen || !searchState.query || !activeFile) {
      if (searchState.matchesCount !== 0) {
        setSearchState((prev) => ({ ...prev, matchesCount: 0, currentMatchIndex: 0 }));
      }
      return;
    }

    try {
      let flags = 'g';
      if (!searchState.caseSensitive) flags += 'i';
      let pattern = searchState.query;
      if (!searchState.useRegex) {
        pattern = pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      }
      if (searchState.matchWholeWord) {
        pattern = `\\b${pattern}\\b`;
      }
      const regex = new RegExp(pattern, flags);
      const matches = activeFile.content.match(regex);
      const count = matches ? matches.length : 0;
      setSearchState((prev) => ({
        ...prev,
        matchesCount: count,
        currentMatchIndex: count > 0 ? prev.currentMatchIndex % count : 0,
      }));
    } catch (e) {
      setSearchState((prev) => ({ ...prev, matchesCount: 0 }));
    }
  }, [
    searchState.query,
    searchState.caseSensitive,
    searchState.matchWholeWord,
    searchState.useRegex,
    searchState.isOpen,
    activeFile?.content,
  ]);

  // Update File Content
  const handleContentChange = (newContent: string) => {
    if (!activeFile) return;

    // Push to undo stack
    setUndoStack((prev) => ({
      ...prev,
      [activeFile.id]: [...(prev[activeFile.id] || []).slice(-30), activeFile.content],
    }));
    // Clear redo stack
    setRedoStack((prev) => ({ ...prev, [activeFile.id]: [] }));

    setFiles((prev) =>
      prev.map((f) =>
        f.id === activeFile.id ? { ...f, content: newContent, isModified: true } : f
      )
    );
  };

  // Save File directly to phone/device storage
  const handleSave = async () => {
    if (!activeFile) return;
    setFiles((prev) =>
      prev.map((f) => (f.id === activeFile.id ? { ...f, isModified: false } : f))
    );
    // Write directly to local file handle or device folder
    await saveFileToDeviceStorage(activeFile);
  };

  // Auto-Save effect to live-save edits to phone storage automatically
  useEffect(() => {
    if (!settings.autoSave || !activeFile || !activeFile.isModified) return;

    const timer = setTimeout(async () => {
      setFiles((prev) =>
        prev.map((f) => (f.id === activeFile.id ? { ...f, isModified: false } : f))
      );
      await saveFileToDeviceStorage(activeFile);
    }, settings.autoSaveDelay || 1000);

    return () => clearTimeout(timer);
  }, [activeFile?.content, activeFile?.isModified, settings.autoSave, settings.autoSaveDelay]);

  // Undo
  const handleUndo = () => {
    if (!activeFile) return;
    const history = undoStack[activeFile.id] || [];
    if (history.length === 0) return;

    const prevContent = history[history.length - 1];
    setUndoStack((prev) => ({
      ...prev,
      [activeFile.id]: history.slice(0, -1),
    }));
    setRedoStack((prev) => ({
      ...prev,
      [activeFile.id]: [...(prev[activeFile.id] || []), activeFile.content],
    }));

    setFiles((prev) =>
      prev.map((f) =>
        f.id === activeFile.id ? { ...f, content: prevContent, isModified: true } : f
      )
    );
  };

  // Redo
  const handleRedo = () => {
    if (!activeFile) return;
    const forward = redoStack[activeFile.id] || [];
    if (forward.length === 0) return;

    const nextContent = forward[forward.length - 1];
    setRedoStack((prev) => ({
      ...prev,
      [activeFile.id]: forward.slice(0, -1),
    }));
    setUndoStack((prev) => ({
      ...prev,
      [activeFile.id]: [...(prev[activeFile.id] || []), activeFile.content],
    }));

    setFiles((prev) =>
      prev.map((f) =>
        f.id === activeFile.id ? { ...f, content: nextContent, isModified: true } : f
      )
    );
  };

  // Insert Symbol from Quick Toolbar
  const handleInsertSymbol = (symbol: string) => {
    if (!activeFile) return;
    const updated = activeFile.content + symbol;
    handleContentChange(updated);
  };

  // Toggle Comment
  const handleToggleComment = () => {
    if (!activeFile) return;
    const lines = activeFile.content.split('\n');
    const commentPrefix =
      activeFile.language === 'python' || activeFile.language === 'shell'
        ? '# '
        : activeFile.language === 'sql'
        ? '-- '
        : '// ';

    const updated = lines
      .map((l) => (l.startsWith(commentPrefix) ? l.substring(commentPrefix.length) : commentPrefix + l))
      .join('\n');
    handleContentChange(updated);
  };

  // Create File
  const handleCreateFile = async (name: string, content = '') => {
    const lang = detectLanguage(name);
    let fileHandle = null;

    if (activeDirHandle) {
      fileHandle = await createFileInDeviceFolder(activeDirHandle, name, content);
    }

    const newFile: EditorFile = {
      id: `file-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      name,
      path: `/${name}`,
      language: lang,
      content,
      encoding: settings.defaultEncoding,
      lineEnding: settings.defaultLineEnding,
      isModified: false,
      fileHandle,
      dirHandle: activeDirHandle,
      isSyncedLocal: !!activeDirHandle,
    };

    setFiles((prev) => [...prev, newFile]);
    setOpenFileIds((prev) => [...prev, newFile.id]);
    setActiveFileId(newFile.id);
  };

  // Rename File
  const handleRenameFile = (fileId: string, newName: string) => {
    const lang = detectLanguage(newName);
    setFiles((prev) =>
      prev.map((f) => (f.id === fileId ? { ...f, name: newName, path: `/${newName}`, language: lang } : f))
    );
  };

  // Delete File
  const handleDeleteFile = async (fileId: string) => {
    const target = files.find((f) => f.id === fileId);
    if (target && activeDirHandle) {
      await deleteFileFromDeviceFolder(activeDirHandle, target.name);
    }

    setFiles((prev) => prev.filter((f) => f.id !== fileId));
    setOpenFileIds((prev) => prev.filter((id) => id !== fileId));
    if (activeFileId === fileId) {
      const remaining = files.filter((f) => f.id !== fileId);
      if (remaining.length > 0) {
        setActiveFileId(remaining[0].id);
      }
    }
  };

  // Duplicate File
  const handleDuplicateFile = (fileId: string) => {
    const target = files.find((f) => f.id === fileId);
    if (!target) return;
    const parts = target.name.split('.');
    const ext = parts.length > 1 ? `.${parts.pop()}` : '';
    const baseName = parts.join('.');
    const dupName = `${baseName}_copy${ext}`;
    handleCreateFile(dupName, target.content);
  };

  // Select File from Explorer or Tab
  const handleSelectFile = (fileId: string) => {
    setActiveFileId(fileId);
    if (!openFileIds.includes(fileId)) {
      setOpenFileIds((prev) => [...prev, fileId]);
    }
  };

  // Close Tab
  const handleCloseTab = (fileId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const file = files.find((f) => f.id === fileId);
    if (file && file.isModified) {
      setUnsavedCloseFileId(fileId);
      return;
    }
    executeCloseTab(fileId);
  };

  const executeCloseTab = (fileId: string) => {
    const newOpenIds = openFileIds.filter((id) => id !== fileId);
    setOpenFileIds(newOpenIds);

    if (activeFileId === fileId) {
      if (newOpenIds.length > 0) {
        setActiveFileId(newOpenIds[newOpenIds.length - 1]);
      }
    }
  };

  // Find Next / Prev
  const handleFindNext = () => {
    if (searchState.matchesCount === 0) return;
    setSearchState((prev) => ({
      ...prev,
      currentMatchIndex: (prev.currentMatchIndex + 1) % prev.matchesCount,
    }));
  };

  const handleFindPrev = () => {
    if (searchState.matchesCount === 0) return;
    setSearchState((prev) => ({
      ...prev,
      currentMatchIndex: (prev.currentMatchIndex - 1 + prev.matchesCount) % prev.matchesCount,
    }));
  };

  // Replace Current Match
  const handleReplaceCurrent = () => {
    if (!activeFile || !searchState.query) return;
    try {
      let flags = '';
      if (!searchState.caseSensitive) flags += 'i';
      let pattern = searchState.query;
      if (!searchState.useRegex) {
        pattern = pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      }
      if (searchState.matchWholeWord) {
        pattern = `\\b${pattern}\\b`;
      }
      const regex = new RegExp(pattern, flags);
      const updated = activeFile.content.replace(regex, searchState.replaceQuery);
      handleContentChange(updated);
    } catch (e) {}
  };

  // Replace All Matches
  const handleReplaceAll = () => {
    if (!activeFile || !searchState.query) return;
    try {
      let flags = 'g';
      if (!searchState.caseSensitive) flags += 'i';
      let pattern = searchState.query;
      if (!searchState.useRegex) {
        pattern = pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      }
      if (searchState.matchWholeWord) {
        pattern = `\\b${pattern}\\b`;
      }
      const regex = new RegExp(pattern, flags);
      const updated = activeFile.content.replace(regex, searchState.replaceQuery);
      handleContentChange(updated);
    } catch (e) {}
  };

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const cmdKey = isMac ? e.metaKey : e.ctrlKey;

      if (cmdKey && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSave();
      } else if (cmdKey && e.key.toLowerCase() === 'f') {
        e.preventDefault();
        setSearchState((prev) => ({ ...prev, isOpen: true }));
      } else if (cmdKey && e.key.toLowerCase() === 'h') {
        e.preventDefault();
        setSearchState((prev) => ({ ...prev, isOpen: true }));
      } else if (cmdKey && e.key.toLowerCase() === 'g') {
        e.preventDefault();
        setIsGoToLineOpen(true);
      } else if (cmdKey && e.key.toLowerCase() === 'n') {
        e.preventDefault();
        handleCreateFile(`untitled_${Date.now().toString().slice(-4)}.js`, '');
      } else if (cmdKey && e.key.toLowerCase() === 'w') {
        e.preventDefault();
        if (activeFileId) {
          const newOpenIds = openFileIds.filter((id) => id !== activeFileId);
          setOpenFileIds(newOpenIds);
          if (newOpenIds.length > 0) setActiveFileId(newOpenIds[newOpenIds.length - 1]);
        }
      } else if (cmdKey && e.key === 'Enter') {
        e.preventDefault();
        setIsPreviewOpen((prev) => !prev);
      } else if (cmdKey && e.key === '`') {
        e.preventDefault();
        setIsTerminalOpen((prev) => !prev);
      } else if (e.key === 'F1') {
        e.preventDefault();
        setIsShortcutsOpen(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeFileId, openFileIds, activeFile]);

  const currentLineCount = activeFile ? activeFile.content.split('\n').length : 1;

  return (
    <div
      id="myself-editor-root"
      className="flex flex-col h-[100dvh] h-screen w-screen max-w-full overflow-hidden select-none"
      style={{
        backgroundColor: THEMES[settings.theme]?.bg || '#18181b',
        color: THEMES[settings.theme]?.textColor || '#d4d4d8',
      }}
    >
      {/* Seamless Splash Screen: 2.8s fade without black screen flicker */}
      {showSplash && (
        <SplashScreen
          onFinish={() => setShowSplash(false)}
          durationMs={2800}
        />
      )}

      {/* Main Top Header */}
      <Header
        appName="MYself_EDITOR"
        theme={settings.theme}
        isModified={!!activeFile?.isModified}
        onSave={handleSave}
        onRunPreview={() => setIsPreviewOpen(!isPreviewOpen)}
        onToggleTerminal={() => setIsTerminalOpen(!isTerminalOpen)}
        onToggleExplorer={() => setIsExplorerOpen(!isExplorerOpen)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
        onOpenGoToLine={() => setIsGoToLineOpen(true)}
        onOpenSearch={() => setSearchState((prev) => ({ ...prev, isOpen: true }))}
        onOpenExportApk={() => setIsExportApkOpen(true)}
        onOpenPhoneFolder={handleOpenPhoneFolder}
        syncedFolderName={syncedFolderName}
        onNewFile={() => handleCreateFile(`new_file_${Date.now().toString().slice(-4)}.js`)}
        onToggleTheme={handleToggleTheme}
        onZoomIn={handleZoomIn}
        onZoomOut={handleZoomOut}
        onResetZoom={handleResetZoom}
        zoomLevel={zoomLevel}
        isPreviewOpen={isPreviewOpen}
        isTerminalOpen={isTerminalOpen}
        isExplorerOpen={isExplorerOpen}
      />

      {/* Main Body Layout */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left File Explorer Sidebar */}
        <FileExplorer
          files={files}
          activeFileId={activeFileId}
          onSelectFile={handleSelectFile}
          onCreateFile={handleCreateFile}
          onRenameFile={handleRenameFile}
          onDeleteFile={handleDeleteFile}
          onDuplicateFile={handleDuplicateFile}
          isOpen={isExplorerOpen}
          onClose={() => setIsExplorerOpen(false)}
          onOpenExportApk={() => setIsExportApkOpen(true)}
          onOpenPhoneFolder={handleOpenPhoneFolder}
          syncedFolderName={syncedFolderName}
          theme={settings.theme}
        />

        {/* Center: Editor + Tabs + Terminal */}
        <div className="flex-1 flex flex-col h-full overflow-hidden relative">
          {/* Tabs Bar */}
          <TabsBar
            files={files}
            openFileIds={openFileIds}
            activeFileId={activeFileId}
            onSelectTab={handleSelectFile}
            onCloseTab={handleCloseTab}
            onNewFile={() => handleCreateFile(`untitled_${Date.now().toString().slice(-4)}.html`)}
            theme={settings.theme}
          />

          {/* Search Bar Overlay */}
          <SearchBar
            searchState={searchState}
            onSearchChange={(updates) => setSearchState((prev) => ({ ...prev, ...updates }))}
            onFindNext={handleFindNext}
            onFindPrev={handleFindPrev}
            onReplaceCurrent={handleReplaceCurrent}
            onReplaceAll={handleReplaceAll}
            onClose={() => setSearchState((prev) => ({ ...prev, isOpen: false }))}
            theme={settings.theme}
          />

          {/* Active Editor Area */}
          <div className="flex-1 flex overflow-hidden relative">
            <EditorArea
              file={activeFile}
              settings={settings}
              searchState={searchState}
              onContentChange={handleContentChange}
              onSave={handleSave}
              onZoomIn={handleZoomIn}
              onZoomOut={handleZoomOut}
              onResetZoom={handleResetZoom}
            />
          </div>

          {/* Quick Mobile Symbols Bar */}
          <QuickToolbar
            onUndo={handleUndo}
            onRedo={handleRedo}
            onInsertSymbol={handleInsertSymbol}
            onToggleComment={handleToggleComment}
            onSave={handleSave}
            onToggleWrap={() => setSettings((prev) => ({ ...prev, wordWrap: !prev.wordWrap }))}
            onZoomIn={handleZoomIn}
            onZoomOut={handleZoomOut}
            onResetZoom={handleResetZoom}
            zoomLevel={zoomLevel}
            isWrapped={settings.wordWrap}
            theme={settings.theme}
          />

          {/* Interactive Shell Terminal */}
          {isTerminalOpen && (
            <TerminalPanel
              files={files}
              onCreateFile={handleCreateFile}
              onDeleteFile={handleDeleteFile}
              onOpenFile={handleSelectFile}
              onBuildApk={() => setIsExportApkOpen(true)}
              isOpen={isTerminalOpen}
              onClose={() => setIsTerminalOpen(false)}
              theme={settings.theme}
            />
          )}
        </div>
      </div>

      {/* Modals & Dialogs */}
      <SettingsModal
        isOpen={isSettingsOpen}
        settings={settings}
        onUpdateSettings={(updates) => setSettings((prev) => ({ ...prev, ...updates }))}
        onReplaySplash={() => setShowSplash(true)}
        onClose={() => setIsSettingsOpen(false)}
      />

      <ShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />

      <GoToLineModal
        isOpen={isGoToLineOpen}
        maxLine={currentLineCount}
        currentLine={1}
        onGoToLine={() => {}}
        onClose={() => setIsGoToLineOpen(false)}
      />

      <ExportApkModal
        isOpen={isExportApkOpen}
        files={files}
        onClose={() => setIsExportApkOpen(false)}
        theme={settings.theme}
      />

      {/* Unsaved Changes Close Confirmation Modal */}
      {unsavedCloseFileId && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-[#121214] border border-zinc-700 rounded-xl p-5 max-w-sm w-full shadow-2xl text-white space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-cyan-500/25 text-cyan-400 flex items-center justify-center font-bold text-lg shrink-0">
                ⚠️
              </div>
              <div>
                <h3 className="font-semibold text-sm">Unsaved Changes</h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  "{files.find((f) => f.id === unsavedCloseFileId)?.name}" has unsaved changes. Save file or close anyway?
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-800">
              <button
                onClick={() => setUnsavedCloseFileId(null)}
                className="px-3 py-1.5 rounded-lg text-xs bg-zinc-800 text-zinc-300 hover:bg-zinc-700 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  executeCloseTab(unsavedCloseFileId);
                  setUnsavedCloseFileId(null);
                }}
                className="px-3 py-1.5 rounded-lg text-xs bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30 transition-colors cursor-pointer"
              >
                Close Anyway
              </button>
              <button
                onClick={() => {
                  setFiles((prev) =>
                    prev.map((f) => (f.id === unsavedCloseFileId ? { ...f, isModified: false } : f))
                  );
                  executeCloseTab(unsavedCloseFileId);
                  setUnsavedCloseFileId(null);
                }}
                className="px-3 py-1.5 rounded-lg text-xs bg-cyan-500 text-black font-semibold hover:bg-cyan-400 transition-colors cursor-pointer"
              >
                Save & Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fullscreen Live Web Preview View */}
      {isPreviewOpen && (
        <div className="fixed inset-0 z-50 bg-zinc-950 flex flex-col">
          <LivePreview
            files={files}
            isOpen={isPreviewOpen}
            onClose={() => setIsPreviewOpen(false)}
          />
        </div>
      )}
    </div>
  );
}
