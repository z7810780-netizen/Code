import JSZip from 'jszip';
import { EditorFile } from '../types';
import { generateStandaloneIdeHtml } from './ideBundleGenerator';

export interface ExportOptions {
  packageName?: string;
  appName?: string;
  versionName?: string;
  versionCode?: number;
  exportType?: 'ide' | 'user_app'; // 'ide' = Complete Mobile IDE App, 'user_app' = Just user's web project
}

/**
 * Generate a complete, ready-to-build Android Studio & Gradle project zip archive
 * with proper adaptive icons, Gradle wrapper, AndroidManifest, Kotlin code, and offline assets.
 */
export async function generateAndroidProjectZip(
  files: EditorFile[],
  options: ExportOptions = {}
): Promise<Blob> {
  const zip = new JSZip();

  const packageName = options.packageName || 'com.myselfsinghcodeeditor';
  const appName = options.appName || 'MYself_EDITOR';
  const versionName = options.versionName || '1.0.0';
  const versionCode = options.versionCode || 1;
  const exportType = options.exportType || 'ide';
  const packagePath = packageName.replace(/\./g, '/');

  // 1. Root build.gradle.kts
  zip.file(
    'build.gradle.kts',
    `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.jetbrains.kotlin.android) apply false
}
`
  );

  // 2. settings.gradle.kts
  zip.file(
    'settings.gradle.kts',
    `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "${appName}"
include(":app")
`
  );

  // 3. gradle/libs.versions.toml
  zip.file(
    'gradle/libs.versions.toml',
    `[versions]
agp = "8.4.0"
kotlin = "1.9.23"
coreKtx = "1.13.1"
appcompat = "1.6.1"
material = "1.12.0"
activity = "1.9.0"
constraintlayout = "2.1.4"
webkit = "1.11.0"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-appcompat = { group = "androidx.appcompat", name = "appcompat", version.ref = "appcompat" }
material = { group = "com.google.android.material", name = "material", version.ref = "material" }
androidx-activity = { group = "androidx.activity", name = "activity", version.ref = "activity" }
androidx-constraintlayout = { group = "androidx.constraintlayout", name = "constraintlayout", version.ref = "constraintlayout" }
androidx-webkit = { group = "androidx.webkit", name = "webkit", version.ref = "webkit" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
jetbrains-kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
`
  );

  // 4. gradle.properties
  zip.file(
    'gradle.properties',
    `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
`
  );

  // 5. gradle/wrapper/gradle-wrapper.properties
  zip.file(
    'gradle/wrapper/gradle-wrapper.properties',
    `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
  );

  // 6. gradlew & gradlew.bat
  zip.file(
    'gradlew',
    `#!/bin/sh
# Gradle start up script for POSIX systems
exec gradle "$@"
`
  );

  zip.file(
    'gradlew.bat',
    `@rem Gradle start up script for Windows
@gradle %*
`
  );

  // 7. app/build.gradle.kts
  zip.file(
    'app/build.gradle.kts',
    `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
}

android {
    namespace = "${packageName}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${packageName}"
        minSdk = 24
        targetSdk = 34
        versionCode = ${versionCode}
        versionName = "${versionName}"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.webkit)
}
`
  );

  // 8. app/proguard-rules.pro
  zip.file(
    'app/proguard-rules.pro',
    `# Add project specific ProGuard rules here.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
`
  );

  // 9. AndroidManifest.xml
  zip.file(
    'app/src/main/AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:hardwareAccelerated="true"
        android:theme="@style/Theme.MYselfEditor"
        android:usesCleartextTraffic="true">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden|screenLayout"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`
  );

  // 10. Res values (strings, colors, themes)
  zip.file(
    'app/src/main/res/values/strings.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${appName}</string>
</resources>
`
  );

  zip.file(
    'app/src/main/res/values/colors.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="black">#FF000000</color>
    <color name="white">#FFFFFFFF</color>
    <color name="cyan_500">#FF06B6D4</color>
    <color name="cyan_600">#FF0891B2</color>
    <color name="blue_600">#FF2563EB</color>
    <color name="zinc_900">#FF18181B</color>
    <color name="zinc_950">#FF09090B</color>
    <color name="ic_launcher_background">#FF0F172A</color>
</resources>
`
  );

  zip.file(
    'app/src/main/res/values/themes.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.MYselfEditor" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/cyan_500</item>
        <item name="colorPrimaryVariant">@color/cyan_600</item>
        <item name="colorOnPrimary">@color/white</item>
        <item name="android:statusBarColor">@color/zinc_950</item>
        <item name="android:navigationBarColor">@color/zinc_950</item>
        <item name="android:windowBackground">@color/zinc_950</item>
    </style>
</resources>
`
  );

  // 11. Android Adaptive Launcher Icons & Vector Graphics
  // 11a. Icon Background Drawable
  zip.file(
    'app/src/main/res/drawable/ic_launcher_background.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#0D1117"
        android:pathData="M0,0h108v108h-108z" />
    <path
        android:fillColor="#161B22"
        android:pathData="M0,0 L108,108 L0,108 Z" />
    <path
        android:fillColor="#06B6D4"
        android:fillAlpha="0.15"
        android:pathData="M54,54m-42,0a42,42 0,1 1,84 0a42,42 0,1 1,-84 0" />
</vector>
`
  );

  // 11b. Icon Foreground Drawable (Modern IDE Code Brackets </> with Cyan/Blue gradient styling)
  zip.file(
    'app/src/main/res/drawable/ic_launcher_foreground.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    
    <!-- Code Editor Window Frame -->
    <path
        android:strokeColor="#30363D"
        android:strokeWidth="1.5"
        android:fillColor="#161B22"
        android:pathData="M26,26h56a6,6 0 0 1 6,6v44a6,6 0 0 1 -6,6h-56a6,6 0 0 1 -6,-6v-44a6,6 0 0 1 6,-6z" />
        
    <!-- Window Controls (Red/Yellow/Green dots) -->
    <path android:fillColor="#EF4444" android:pathData="M28,31m-2,0a2,2 0 1 1 4,0a2,2 0 1 1 -4,0" />
    <path android:fillColor="#F59E0B" android:pathData="M34,31m-2,0a2,2 0 1 1 4,0a2,2 0 1 1 -4,0" />
    <path android:fillColor="#10B981" android:pathData="M40,31m-2,0a2,2 0 1 1 4,0a2,2 0 1 1 -4,0" />

    <!-- Left Bracket < -->
    <path
        android:strokeColor="#06B6D4"
        android:strokeWidth="3.5"
        android:strokeLineCap="round"
        android:strokeLineJoin="round"
        android:pathData="M42,44 L34,54 L42,64" />

    <!-- Slash / -->
    <path
        android:strokeColor="#3B82F6"
        android:strokeWidth="3.5"
        android:strokeLineCap="round"
        android:pathData="M51,65 L57,43" />

    <!-- Right Bracket > -->
    <path
        android:strokeColor="#06B6D4"
        android:strokeWidth="3.5"
        android:strokeLineCap="round"
        android:strokeLineJoin="round"
        android:pathData="M66,44 L74,54 L66,64" />

    <!-- Sparkle accent -->
    <path
        android:fillColor="#38BDF8"
        android:pathData="M78,32 L79.5,35.5 L83,37 L79.5,38.5 L78,42 L76.5,38.5 L73,37 L76.5,35.5 Z" />
</vector>
`
  );

  // 11c. Adaptive Icons XML (Standard & Round)
  zip.file(
    'app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
`
  );

  zip.file(
    'app/src/main/res/mipmap-anydpi-v26/ic_launcher_round.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
</adaptive-icon>
`
  );

  // 11d. Legacy drawable icon fallback for pre-v26 devices
  zip.file(
    'app/src/main/res/drawable/ic_launcher.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@drawable/ic_launcher_background" />
    <item android:drawable="@drawable/ic_launcher_foreground" />
</layer-list>
`
  );

  // 12. Activity Layout XML
  zip.file(
    'app/src/main/res/layout/activity_main.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/zinc_950">

    <WebView
        android:id="@+id/mainWebView"
        android:layout_width="0dp"
        android:layout_height="0dp"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>
`
  );

  // 13. MainActivity.kt with full hardware acceleration, native file picker support, and web settings
  zip.file(
    `app/src/main/java/${packagePath}/MainActivity.kt`,
    `package ${packageName}

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private val FILE_CHOOSER_REQUEST_CODE = 1001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.mainWebView)

        val webSettings: WebSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.allowFileAccess = true
        webSettings.allowContentAccess = true
        @Suppress("DEPRECATION")
        webSettings.allowFileAccessFromFileURLs = true
        @Suppress("DEPRECATION")
        webSettings.allowUniversalAccessFromFileURLs = true
        webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        webSettings.databaseEnabled = true
        webSettings.useWideViewPort = true
        webSettings.loadWithOverviewMode = true
        webSettings.setSupportZoom(true)
        webSettings.builtInZoomControls = false
        webSettings.displayZoomControls = false

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
            }
        }

        // WebChromeClient supporting native file picker for local storage access
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.filePathCallback?.onReceiveValue(null)
                this@MainActivity.filePathCallback = filePathCallback

                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE)
                } catch (e: Exception) {
                    this@MainActivity.filePathCallback = null
                    return false
                }
                return true
            }
        }

        // Load self-contained offline application
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback != null) {
                val results: Array<Uri>? = if (resultCode == Activity.RESULT_OK && data != null) {
                    if (data.clipData != null) {
                        val count = data.clipData!!.itemCount
                        val uris = Array<Uri>(count) { i -> data.clipData!!.getItemAt(i).uri }
                        uris
                    } else if (data.data != null) {
                        arrayOf(data.data!!)
                    } else {
                        null
                    }
                } else {
                    null
                }
                filePathCallback?.onReceiveValue(results)
                filePathCallback = null
            }
        }
    }

    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
`
  );

  // 14. Asset Packaging: Complete MYself_EDITOR Mobile IDE Application in assets/index.html
  const ideHtml = generateStandaloneIdeHtml(files, appName);
  zip.file('app/src/main/assets/index.html', ideHtml);

  // 15. Automated build script for GitHub Codespaces / Linux (installs SDK & builds APK automatically)
  zip.file(
    'build-apk-codespace.sh',
    `#!/bin/bash
set -e

echo "====================================================="
echo " Setting up Android SDK & Building MYself_EDITOR APK"
echo "====================================================="

export ANDROID_HOME="$HOME/android-sdk"
export ANDROID_SDK_ROOT="$ANDROID_HOME"

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
    echo ">> Installing Android SDK command-line tools..."
    sudo apt-get update -qq
    sudo apt-get install -y -qq openjdk-17-jdk wget unzip

    mkdir -p "$ANDROID_HOME/cmdline-tools"
    cd "$ANDROID_HOME/cmdline-tools"
    wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O cmdline-tools.zip
    unzip -q cmdline-tools.zip
    rm -f cmdline-tools.zip
    mv cmdline-tools latest 2>/dev/null || true
fi

export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

echo ">> Accepting Android SDK licenses and installing Android 34 build-tools..."
yes | sdkmanager --licenses > /dev/null 2>&1 || true
sdkmanager --install "platforms;android-34" "build-tools;34.0.0" "platform-tools" > /dev/null 2>&1

cd "$(dirname "$0")"

echo "sdk.dir=$ANDROID_HOME" > local.properties
chmod +x gradlew

echo ">> Compiling Android Debug APK..."
./gradlew assembleDebug

echo ""
echo "====================================================="
echo " ✅ APK BUILD SUCCESSFUL!"
echo " Output: app/build/outputs/apk/debug/app-debug.apk"
echo "====================================================="
`
  );

  // 16. GitHub Actions workflow for automatic cloud APK compilation (.github/workflows/build-apk.yml)
  zip.file(
    '.github/workflows/build-apk.yml',
    `name: Build Android APK

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
    - name: Checkout Code
      uses: actions/checkout@v4

    - name: Set up JDK 17
      uses: actions/setup-java@v4
      with:
        java-version: '17'
        distribution: 'temurin'
        cache: gradle

    - name: Grant execute permission for gradlew
      run: chmod +x gradlew

    - name: Build Debug APK
      run: ./gradlew assembleDebug --stacktrace

    - name: Upload APK Artifact
      uses: actions/upload-artifact@v4
      with:
        name: app-debug.apk
        path: app/build/outputs/apk/debug/app-debug.apk
        retention-days: 30
`
  );

  // 16. Comprehensive README.md with instructions
  zip.file(
    'README.md',
    `# ${appName} - Android Studio Project

Generated by **MYself_EDITOR** by **MYself_SINGH**.

## Contents
- **Launcher Icons**: Full adaptive vector icons in \`app/src/main/res/mipmap-anydpi-v26/\` and \`drawable/\`
- **Application Engine**: Standalone offline mobile application in \`app/src/main/assets/index.html\`
- **Automated CI/CD**: Cloud build pipeline in \`.github/workflows/build-apk.yml\`
- **AI Debug & Build Guide**: \`AI_DEBUG_INSTRUCTIONS.md\` for AI Coding Assistants / Codespaces

## How to Build the APK

### Method 1: Automated Script in Codespaces / Linux / Terminal
\`\`\`bash
chmod +x build-apk-codespace.sh
./build-apk-codespace.sh
\`\`\`

### Method 2: Standard Gradle Command
\`\`\`bash
chmod +x gradlew
./gradlew assembleDebug
\`\`\`
Output APK: \`app/build/outputs/apk/debug/app-debug.apk\`

### Method 3: Android Studio
1. Open Android Studio.
2. Click **File -> Open** and select this directory.
3. Wait for Gradle Sync to complete.
4. Click **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
5. Your compiled \`app-debug.apk\` is ready in \`app/build/outputs/apk/debug/\`!

### Method 4: GitHub Actions (Free Automated Cloud APK Build)
1. Push this project to a GitHub repository.
2. Open the **Actions** tab on GitHub.
3. GitHub Actions will build the APK automatically and attach \`app-debug.apk\` to the Artifacts download section!
`
  );

  // 17. Instructions specifically formatted for GitHub Codespaces AI & Copilot Assistants
  zip.file(
    'AI_DEBUG_INSTRUCTIONS.md',
    `# INSTRUCTIONS FOR CODESPACES / CURSOR / GITHUB COPILOT / AI ASSISTANTS

If you are an AI Assistant or automated build agent debugging or building this Android project in GitHub Codespaces or VS Code:

## 1. Project Type
This is a standard **Android Gradle Project** written in Kotlin and HTML5/JS.
- **Root Build File**: \`build.gradle.kts\`
- **App Module**: \`app/build.gradle.kts\`
- **Gradle Wrapper**: \`gradlew\` and \`gradlew.bat\`
- **Native Android Activity**: \`app/src/main/java/com/myselfsinghcodeeditor/MainActivity.kt\`
- **Web Application Assets**: \`app/src/main/assets/index.html\`

## 2. How to Build the Debug APK
Execute the following commands in the bash terminal:
\`\`\`bash
chmod +x gradlew
./gradlew assembleDebug --stacktrace
\`\`\`

If Java SDK or Android SDK is missing in Codespaces, run:
\`\`\`bash
chmod +x build-apk-codespace.sh
./build-apk-codespace.sh
\`\`\`

## 3. Output Location of Compiled APK
Upon successful completion of \`./gradlew assembleDebug\`, the compiled APK will be at:
\`app/build/outputs/apk/debug/app-debug.apk\`

## 4. Debugging & Common Issues
- **Permission Denied on gradlew**: Run \`chmod +x gradlew\`
- **JAVA_HOME / JDK Error**: Ensure Java 17 is installed (\`openjdk-17-jdk\`).
- **Offline Assets**: The entire IDE web application is packaged in \`app/src/main/assets/index.html\`. It is loaded by \`MainActivity.kt\` via \`webView.loadUrl("file:///android_asset/index.html")\`.
`
  );

  // 18. Quick Codespace Build Guide
  zip.file(
    'CODESPACE_BUILD_GUIDE.md',
    `# GitHub Codespaces Quick Build Guide

To build the \`app-debug.apk\` in GitHub Codespaces:

1. Open Terminal in Codespaces (\`Ctrl + \` \` or \`Cmd + \` \`).
2. Run:
   \`\`\`bash
   chmod +x build-apk-codespace.sh
   ./build-apk-codespace.sh
   \`\`\`
3. Download the generated APK from:
   \`app/build/outputs/apk/debug/app-debug.apk\`
`
  );

  // Generate binary ZIP Blob
  return await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });
}

/**
 * Generate a clean Zip archive containing all current workspace source files
 */
export async function generateWorkspaceZip(files: EditorFile[]): Promise<Blob> {
  const zip = new JSZip();

  files.forEach((file) => {
    const cleanPath = file.path.startsWith('/') ? file.path.substring(1) : file.path;
    zip.file(cleanPath || file.name, file.content);
  });

  zip.file(
    'PROJECT_INFO.txt',
    `Project: MYself_EDITOR Workspace
Export Date: ${new Date().toISOString()}
Total Files: ${files.length}
Files Included:
${files.map((f) => ` - ${f.name} (${f.language})`).join('\n')}
`
  );

  return await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });
}

/**
 * Generate a complete, ready-to-upload Website Zip archive preconfigured for InfinityFree,
 * cPanel, Apache, Netlify, Vercel, or GitHub Pages.
 * Contains index.html, .htaccess, robots.txt, and complete instructions.
 */
export async function generateInfinityFreeZip(files: EditorFile[]): Promise<Blob> {
  const zip = new JSZip();

  // 1. Standalone IDE index.html (Root entry point for InfinityFree htdocs)
  const standaloneHtml = generateStandaloneIdeHtml(files);
  zip.file('index.html', standaloneHtml);

  // 2. Apache .htaccess specifically optimized for InfinityFree / cPanel
  zip.file(
    '.htaccess',
    `# =============================================================
# InfinityFree / Apache Server Configuration - MYself_EDITOR
# =============================================================

# Set directory index to index.html
DirectoryIndex index.html index.php

# Prevent directory listings
Options -Indexes

# Set UTF-8 encoding
AddDefaultCharset UTF-8

# MIME Types configuration
<IfModule mod_mime.c>
  AddType text/html .html .htm
  AddType text/css .css
  AddType application/javascript .js .mjs
  AddType application/json .json
  AddType image/svg+xml .svg .svgz
  AddType image/png .png
  AddType image/jpeg .jpg .jpeg
  AddType image/webp .webp
  AddType image/x-icon .ico
  AddType font/woff .woff
  AddType font/woff2 .woff2
</IfModule>

# Browser Caching
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType text/html "access plus 0 seconds"
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/javascript "access plus 1 month"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/svg+xml "access plus 1 year"
</IfModule>

# Compression
<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json
</IfModule>
`
  );

  // 3. robots.txt
  zip.file('robots.txt', `User-agent: *\nAllow: /\n`);

  // 4. Step-by-Step InfinityFree Instruction Guide
  zip.file(
    'HOW_TO_HOST_ON_INFINITYFREE.txt',
    `========================================================================
MYself_EDITOR - InfinityFree 1-Click Web Hosting Guide
========================================================================

Follow these exact steps to host your website on InfinityFree for free:

STEP 1: Log in to your InfinityFree Account
- Visit https://infinityfree.com/ and log in.
- Click on your active Hosting Account.

STEP 2: Open File Manager
- Click on "Control Panel" or "Online File Manager" (Monsta FTP).
- Open the "htdocs" folder (e.g. /htdocs/ or /yourdomain/htdocs/).
- (Tip: Delete any default placeholder files like 'index2.html' if present).

STEP 3: Upload the files
- OPTION A (Fastest): Click "Upload" -> select this ZIP file -> right click and choose "Extract".
- OPTION B: Unzip this file on your computer/phone, and upload "index.html" and ".htaccess" directly into the "htdocs" folder.

STEP 4: View your Live Website!
- Open your InfinityFree domain (e.g. http://gtb.xo.je).
- Your MYself_EDITOR will launch immediately!

WHAT IS INCLUDED IN THIS PACKAGE:
✓ index.html: Fully self-contained web app with editor, preview, local files, and Monokai theme
✓ .htaccess: Configured specifically for Apache web servers & InfinityFree
✓ robots.txt: Search engine configuration

No Node.js, compilation, or extra server setup required!
========================================================================
`
  );

  return await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 9 },
  });
}

/**
 * Trigger browser file download helper
 */
export function triggerBlobDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
