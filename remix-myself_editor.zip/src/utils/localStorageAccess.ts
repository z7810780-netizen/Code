import { EditorFile } from '../types';
import { detectLanguage } from './syntax';

export interface OpenedFolderResult {
  folderName: string;
  files: EditorFile[];
  dirHandle: any;
}

/**
 * Open a folder directly from phone/device storage using File System Access API
 * or fallback webkitdirectory file input.
 */
export async function openDeviceFolder(): Promise<OpenedFolderResult | null> {
  // Method 1: Modern File System Access API (Chrome Android, Desktop Chrome, Edge)
  if ('showDirectoryPicker' in window) {
    try {
      const dirHandle = await (window as any).showDirectoryPicker({
        mode: 'readwrite',
      });

      const files: EditorFile[] = [];
      await readDirectoryRecursively(dirHandle, '', files, dirHandle);

      return {
        folderName: dirHandle.name || 'Phone Storage Folder',
        files,
        dirHandle,
      };
    } catch (err: any) {
      if (err.name === 'AbortError') return null; // User cancelled
      console.warn('showDirectoryPicker failed or was rejected, falling back to input:', err);
    }
  }

  // Method 2: Fallback via input element with webkitdirectory
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    (input as any).webkitdirectory = true;
    input.multiple = true;

    input.onchange = async () => {
      const fileList = input.files;
      if (!fileList || fileList.length === 0) {
        resolve(null);
        return;
      }

      const files: EditorFile[] = [];
      let folderName = 'Phone Storage';

      for (let i = 0; i < fileList.length; i++) {
        const file = fileList[i];
        const relativePath = file.webkitRelativePath || file.name;
        if (!folderName && relativePath.includes('/')) {
          folderName = relativePath.split('/')[0];
        }

        // Skip binary or heavy hidden files (node_modules, .git, etc.)
        if (
          relativePath.includes('/node_modules/') ||
          relativePath.includes('/.git/') ||
          relativePath.includes('/dist/') ||
          relativePath.includes('/.gradle/')
        ) {
          continue;
        }

        try {
          const content = await file.text();
          const name = file.name;
          files.push({
            id: `local-file-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
            name,
            path: `/${relativePath}`,
            content,
            language: detectLanguage(name),
            isModified: false,
            isSyncedLocal: true,
          });
        } catch (e) {
          console.warn(`Could not read file ${file.name}:`, e);
        }
      }

      resolve({
        folderName,
        files,
        dirHandle: null,
      });
    };

    input.click();
  });
}

/**
 * Read directory recursively using File System Access API handles
 */
async function readDirectoryRecursively(
  dirHandle: any,
  currentPath: string,
  resultFiles: EditorFile[],
  rootDirHandle: any
) {
  for await (const entry of dirHandle.values()) {
    // Ignore hidden or heavy folders
    if (
      entry.name === 'node_modules' ||
      entry.name === '.git' ||
      entry.name === 'dist' ||
      entry.name === '.gradle' ||
      entry.name.startsWith('.')
    ) {
      continue;
    }

    const itemPath = currentPath ? `${currentPath}/${entry.name}` : entry.name;

    if (entry.kind === 'file') {
      try {
        const fileObj = await entry.getFile();
        const content = await fileObj.text();
        resultFiles.push({
          id: `local-handle-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          name: entry.name,
          path: `/${itemPath}`,
          content,
          language: detectLanguage(entry.name),
          isModified: false,
          fileHandle: entry,
          dirHandle: rootDirHandle,
          isSyncedLocal: true,
        });
      } catch (e) {
        console.warn(`Failed reading handle file ${entry.name}:`, e);
      }
    } else if (entry.kind === 'directory') {
      await readDirectoryRecursively(entry, itemPath, resultFiles, rootDirHandle);
    }
  }
}

/**
 * Save file content directly back to phone/device storage
 */
export async function saveFileToDeviceStorage(file: EditorFile): Promise<{ success: boolean; message: string }> {
  // Option 1: File handle available directly
  if (file.fileHandle && typeof file.fileHandle.createWritable === 'function') {
    try {
      const writable = await file.fileHandle.createWritable();
      await writable.write(file.content);
      await writable.close();
      return { success: true, message: `Saved directly to ${file.name}` };
    } catch (err: any) {
      console.error('Error writing to fileHandle:', err);
      // Fall through to fallback
    }
  }

  // Option 2: Directory handle available
  if (file.dirHandle && typeof file.dirHandle.getFileHandle === 'function') {
    try {
      const cleanName = file.name;
      const fileHandle = await file.dirHandle.getFileHandle(cleanName, { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(file.content);
      await writable.close();
      file.fileHandle = fileHandle; // Attach handle for future fast writes
      return { success: true, message: `Saved directly to phone directory (${cleanName})` };
    } catch (err: any) {
      console.error('Error writing via dirHandle:', err);
    }
  }

  // Option 3: Standard Web Download fallback if handle was lost or unsupported
  try {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    return { success: true, message: `Exported ${file.name} to Downloads` };
  } catch (err: any) {
    return { success: false, message: err.message || 'Failed to write file' };
  }
}

/**
 * Create new file directly in phone storage directory
 */
export async function createFileInDeviceFolder(
  dirHandle: any,
  fileName: string,
  content: string = ''
): Promise<any | null> {
  if (dirHandle && typeof dirHandle.getFileHandle === 'function') {
    try {
      const fileHandle = await dirHandle.getFileHandle(fileName, { create: true });
      const writable = await fileHandle.createWritable();
      await writable.write(content);
      await writable.close();
      return fileHandle;
    } catch (err) {
      console.error('Failed creating file on phone storage:', err);
    }
  }
  return null;
}

/**
 * Delete file directly from phone storage directory
 */
export async function deleteFileFromDeviceFolder(dirHandle: any, fileName: string): Promise<boolean> {
  if (dirHandle && typeof dirHandle.removeEntry === 'function') {
    try {
      await dirHandle.removeEntry(fileName);
      return true;
    } catch (err) {
      console.error('Failed deleting file from phone storage:', err);
    }
  }
  return false;
}
