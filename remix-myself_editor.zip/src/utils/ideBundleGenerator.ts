import { EditorFile } from '../types';
import { DEFAULT_FILES } from './defaultFiles';

/**
 * Generates a 100% self-contained, offline, responsive mobile IDE application.
 * Built with full local file access (importing from phone storage/exporting to phone storage),
 * accurate line numbering, code formatting, syntax highlighting, mobile-optimized responsive layout,
 * live preview, and interactive terminal.
 */
export function generateStandaloneIdeHtml(
  initialFiles: EditorFile[],
  appName: string = 'MYself_EDITOR'
): string {
  const filesToEmbed = (initialFiles && initialFiles.length > 0) ? initialFiles : DEFAULT_FILES;

  const serializedFiles = JSON.stringify(
    filesToEmbed.map((f) => ({
      id: f.id,
      name: f.name,
      path: f.path,
      language: f.language,
      content: f.content,
      encoding: f.encoding || 'UTF-8',
      lineEnding: f.lineEnding || 'LF',
    }))
  ).replace(/<\/script>/gi, '<\\/script>');

  const fallbackFilesJson = JSON.stringify(
    DEFAULT_FILES.map((f) => ({
      id: f.id,
      name: f.name,
      path: f.path,
      language: f.language,
      content: f.content,
      encoding: f.encoding || 'UTF-8',
      lineEnding: f.lineEnding || 'LF',
    }))
  ).replace(/<\/script>/gi, '<\\/script>');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <title>${appName} - Mobile Studio</title>
  <style>
    :root {
      --bg: #090a0f;
      --header-bg: #0f111a;
      --sidebar-bg: #0c0e17;
      --editor-bg: #090a0f;
      --active-line: rgba(255,255,255,0.03);
      --text: #e2e8f0;
      --text-muted: #64748b;
      --border: #1e293b;
      --accent: #06b6d4;
      --accent-hover: #0891b2;
      --accent-glow: rgba(6, 182, 212, 0.18);
      --tab-bg: #0c0e17;
      --tab-active-bg: #090a0f;
      --font-size: 14px;
    }
    
    [data-theme="light"] {
      --bg: #f8fafc;
      --header-bg: #ffffff;
      --sidebar-bg: #f1f5f9;
      --editor-bg: #ffffff;
      --active-line: rgba(0,0,0,0.03);
      --text: #0f172a;
      --text-muted: #64748b;
      --border: #e2e8f0;
      --accent: #0284c7;
      --accent-hover: #0369a1;
      --accent-glow: rgba(2, 132, 199, 0.12);
      --tab-bg: #f1f5f9;
      --tab-active-bg: #ffffff;
    }

    [data-theme="midnight"] {
      --bg: #030712;
      --header-bg: #0b0f19;
      --sidebar-bg: #080c14;
      --editor-bg: #030712;
      --border: #1e1e38;
      --accent: #6366f1;
      --accent-glow: rgba(99, 102, 241, 0.2);
    }

    [data-theme="matrix"] {
      --bg: #020d06;
      --header-bg: #051a0c;
      --sidebar-bg: #031208;
      --editor-bg: #020d06;
      --border: #0d381b;
      --accent: #10b981;
      --accent-glow: rgba(16, 185, 129, 0.2);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
    html, body {
      width: 100%; height: 100%; height: 100dvh;
      overflow: hidden; background: var(--bg); color: var(--text);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      user-select: none;
    }

    #app { display: flex; flex-direction: column; width: 100vw; height: 100dvh; height: 100vh; overflow: hidden; }

    /* Top Navigation Bar */
    header {
      height: 44px; background: var(--header-bg); border-bottom: 1px solid var(--border);
      display: flex; align-items: center; justify-content: space-between; padding: 0 8px;
      flex-shrink: 0; z-index: 40; position: relative; gap: 6px;
    }

    .brand-section { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
    .brand-logo-btn {
      width: 28px; height: 28px; border-radius: 7px; background: #ffffff;
      display: flex; align-items: center; justify-content: center; color: #000; font-weight: 900; font-size: 14px; font-family: serif;
      box-shadow: 0 1px 4px rgba(0,0,0,0.3); border: none; cursor: pointer; transition: transform 0.1s;
    }
    .brand-logo-btn:active { transform: scale(0.92); }
    .brand-text { display: flex; flex-direction: column; }
    .brand-title { font-size: 12px; font-weight: 700; letter-spacing: 0.1em; line-height: 1.1; text-transform: uppercase; color: #fff; }
    .brand-sub { font-size: 8px; text-transform: uppercase; color: var(--text-muted); font-family: monospace; letter-spacing: 0.15em; }

    /* Action Toolbar in Header */
    .header-actions {
      display: flex; align-items: center; gap: 5px; flex-shrink: 0;
    }

    .btn-action {
      background: rgba(255,255,255,0.06); border: 1px solid var(--border); color: var(--text);
      border-radius: 7px; padding: 5px 9px; font-size: 11px; font-weight: 600; cursor: pointer;
      display: inline-flex; align-items: center; gap: 4px; white-space: nowrap; flex-shrink: 0;
      transition: all 0.15s ease;
    }
    .btn-action:active { transform: scale(0.95); background: var(--accent-glow); }
    .btn-action.active { background: var(--accent); color: #000; border-color: var(--accent); font-weight: 700; }
    .btn-action.accent { background: rgba(6, 182, 212, 0.15); border-color: var(--accent); color: var(--accent); }

    /* Zoom control */
    .zoom-group {
      display: inline-flex; align-items: center; border: 1px solid var(--border);
      border-radius: 6px; background: rgba(0,0,0,0.15); flex-shrink: 0; font-family: monospace; font-size: 11px;
    }
    .zoom-btn { background: none; border: none; color: var(--text); padding: 4px 7px; cursor: pointer; font-weight: bold; }
    .zoom-val { padding: 0 4px; font-size: 10px; color: var(--text-muted); }

    /* Workspace */
    .workspace { display: flex; flex: 1; overflow: hidden; position: relative; }

    /* Sidebar - File Explorer */
    aside {
      width: 240px; background: var(--sidebar-bg); border-right: 1px solid var(--border);
      display: flex; flex-direction: column; flex-shrink: 0; transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1), width 0.2s ease;
      z-index: 30;
    }
    aside.collapsed { width: 0; overflow: hidden; border-right: none; }

    @media (max-width: 768px) {
      aside {
        position: absolute; top: 0; bottom: 0; left: 0; width: 260px;
        box-shadow: 4px 0 25px rgba(0,0,0,0.6);
      }
      aside.collapsed { transform: translateX(-100%); width: 260px; }
    }

    .sidebar-header {
      padding: 8px 10px; font-size: 11px; font-weight: 700; text-transform: uppercase;
      letter-spacing: 0.5px; color: var(--text-muted); border-bottom: 1px solid var(--border);
      display: flex; align-items: center; justify-content: space-between; gap: 4px;
    }
    .sidebar-tools { display: flex; align-items: center; gap: 3px; }
    .tool-btn {
      background: transparent; border: 1px solid var(--border); color: var(--text);
      border-radius: 4px; padding: 3px 6px; font-size: 10px; cursor: pointer; display: flex; align-items: center; gap: 3px;
    }
    .tool-btn:active { background: var(--accent-glow); color: var(--accent); }

    .file-list { flex: 1; overflow-y: auto; padding: 6px; }
    .file-item {
      display: flex; align-items: center; justify-content: space-between; padding: 6px 8px;
      border-radius: 6px; font-size: 12px; cursor: pointer; margin-bottom: 2px; color: var(--text);
      transition: background 0.1s;
    }
    .file-item:hover { background: rgba(255,255,255,0.05); }
    .file-item.active { background: var(--accent-glow); color: var(--accent); font-weight: 600; }
    .file-name-wrap { display: flex; align-items: center; gap: 6px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; }
    .file-actions { display: none; align-items: center; gap: 2px; }
    .file-item:hover .file-actions, .file-item.active .file-actions { display: flex; }
    .mini-icon-btn { background: none; border: none; color: var(--text-muted); padding: 2px 4px; font-size: 10px; cursor: pointer; border-radius: 3px; }
    .mini-icon-btn:hover { color: #f43f5e; background: rgba(244,63,94,0.1); }

    /* Center Editor */
    main.editor-area { flex: 1; display: flex; flex-direction: column; overflow: hidden; background: var(--editor-bg); position: relative; }

    /* Tabs Bar */
    .tabs-bar {
      height: 36px; background: var(--tab-bg); border-bottom: 1px solid var(--border);
      display: flex; align-items: center; overflow-x: auto; flex-shrink: 0; scrollbar-width: none;
      -webkit-overflow-scrolling: touch;
    }
    .tabs-bar::-webkit-scrollbar { display: none; }
    .tab {
      display: flex; align-items: center; gap: 6px; padding: 0 12px; height: 100%;
      border-right: 1px solid var(--border); font-size: 12px; cursor: pointer; color: var(--text-muted);
      white-space: nowrap; position: relative; background: transparent; flex-shrink: 0;
    }
    .tab.active { background: var(--tab-active-bg); color: var(--accent); font-weight: 600; }
    .tab.active::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 2px; background: var(--accent); }
    .tab-close { opacity: 0.5; padding: 1px 4px; border-radius: 4px; font-size: 11px; margin-left: 2px; }
    .tab-close:hover { opacity: 1; background: rgba(255,255,255,0.15); color: #f43f5e; }

    /* Editor Core with Synchronized Line Numbers */
    .editor-wrapper {
      flex: 1; display: flex; overflow: hidden; position: relative;
      font-family: "JetBrains Mono", "Fira Code", "Courier New", Consolas, monospace;
    }

    .gutter {
      width: 44px; padding: 10px 6px 10px 0; text-align: right; color: var(--text-muted);
      background: var(--editor-bg); border-right: 1px solid var(--border); font-size: var(--font-size);
      line-height: 1.6; user-select: none; flex-shrink: 0; overflow: hidden; font-family: inherit;
    }

    .editor-textarea {
      flex: 1; height: 100%; border: none; outline: none; resize: none; background: transparent;
      color: var(--text); padding: 10px 12px; font-family: inherit; font-size: var(--font-size);
      line-height: 1.6; white-space: pre; tab-size: 2; overflow: auto; user-select: text;
      -webkit-font-smoothing: antialiased;
    }
    .editor-textarea.wrapped {
      white-space: pre-wrap; word-break: break-all;
    }

    /* Mobile Quick Keys Toolbar */
    .quick-toolbar {
      height: 38px; background: var(--header-bg); border-top: 1px solid var(--border);
      display: flex; align-items: center; padding: 0 6px; gap: 4px; overflow-x: auto; flex-shrink: 0;
      scrollbar-width: none; -webkit-overflow-scrolling: touch; z-index: 20;
    }
    .quick-toolbar::-webkit-scrollbar { display: none; }
    .key-btn {
      background: var(--bg); border: 1px solid var(--border); color: var(--text);
      padding: 5px 9px; border-radius: 5px; font-size: 11px; font-family: monospace; font-weight: 600;
      cursor: pointer; white-space: nowrap; flex-shrink: 0; user-select: none;
    }
    .key-btn:active { background: var(--accent); color: #fff; transform: scale(0.95); }

    /* Find & Replace Bar */
    .search-modal {
      position: absolute; top: 42px; right: 12px; z-index: 50; background: var(--header-bg);
      border: 1px solid var(--border); border-radius: 10px; padding: 10px; display: none;
      flex-direction: column; gap: 8px; box-shadow: 0 12px 30px rgba(0,0,0,0.6); width: 310px;
    }
    .search-modal.open { display: flex; }
    .search-input {
      background: var(--bg); border: 1px solid var(--border); color: var(--text);
      padding: 6px 10px; border-radius: 6px; font-size: 12px; outline: none; width: 100%;
    }
    .search-input:focus { border-color: var(--accent); }

    /* Live Preview Panel / Bottom Sheet */
    .preview-container {
      width: 50%; background: #ffffff; border-left: 1px solid var(--border);
      display: flex; flex-direction: column; flex-shrink: 0; position: relative; z-index: 25;
      transition: all 0.2s ease;
    }
    .preview-container.hidden { display: none; }

    @media (max-width: 768px) {
      .preview-container {
        position: absolute; top: 0; left: 0; right: 0; bottom: 38px; width: 100%;
        border-left: none; box-shadow: 0 -4px 20px rgba(0,0,0,0.5);
      }
    }

    .preview-bar {
      height: 36px; background: var(--header-bg); border-bottom: 1px solid var(--border);
      display: flex; align-items: center; justify-content: space-between; padding: 0 10px; font-size: 11px;
    }
    .preview-frame { flex: 1; width: 100%; height: 100%; border: none; background: #fff; }

    /* Interactive Terminal Panel */
    .terminal-container {
      height: 170px; background: #050608; border-top: 1px solid var(--border);
      display: flex; flex-direction: column; flex-shrink: 0; font-family: monospace; font-size: 12px; z-index: 20;
    }
    .terminal-container.hidden { display: none; }
    .term-bar {
      height: 30px; background: var(--header-bg); border-bottom: 1px solid var(--border);
      display: flex; align-items: center; justify-content: space-between; padding: 0 10px; font-size: 11px;
    }
    .term-content { flex: 1; padding: 8px 12px; overflow-y: auto; color: #a3e635; line-height: 1.4; user-select: text; }
    .term-prompt-row { display: flex; align-items: center; gap: 6px; padding: 4px 10px 8px; }
    .term-prompt-input { flex: 1; background: transparent; border: none; outline: none; color: #fff; font-family: inherit; font-size: 12px; }

    /* Modal / Popups */
    .modal-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,0.65); backdrop-filter: blur(4px);
      z-index: 100; display: none; align-items: center; justify-content: center; padding: 16px;
    }
    .modal-overlay.open { display: flex; }
    .modal-card {
      background: var(--header-bg); border: 1px solid var(--border); border-radius: 14px;
      padding: 16px; width: 100%; max-width: 420px; box-shadow: 0 20px 40px rgba(0,0,0,0.7);
      display: flex; flex-direction: column; gap: 12px;
    }
    .modal-header { display: flex; align-items: center; justify-content: space-between; font-weight: 700; font-size: 14px; }

    /* Toast Notification */
    #toast {
      position: fixed; bottom: 50px; left: 50%; transform: translateX(-50%);
      background: rgba(6, 182, 212, 0.95); color: #fff; padding: 7px 16px; border-radius: 20px;
      font-size: 12px; font-weight: 700; pointer-events: none; opacity: 0; transition: opacity 0.2s, transform 0.2s;
      z-index: 200; box-shadow: 0 6px 16px rgba(0,0,0,0.4);
    }
    #toast.show { opacity: 1; transform: translateX(-50%) translateY(-5px); }
  </style>
</head>
<body data-theme="dark">
  <!-- Seamless Splash Screen Overlay -->
  <div id="splashScreen" style="position:fixed;inset:0;z-index:999999;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at center, #1c1c20 0%, #0c0c0e 45%, #050505 100%);color:#ffffff;transition:opacity 0.6s ease-out;user-select:none;">
    <button onclick="dismissSplash()" style="position:absolute;top:24px;right:24px;display:flex;align-items:center;gap:6px;padding:6px 14px;border-radius:9999px;font-size:12px;font-weight:500;color:rgba(255,255,255,0.6);background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);cursor:pointer;backdrop-filter:blur(8px);">Skip ➔</button>
    <div style="width:90%;max-width:380px;text-align:center;display:flex;flex-direction:column;align-items:center;">
      <img src="https://i.ibb.co/m5z9k5gN/file-00000000f12071fa8b8a18fc6b32d937.png" alt="MYself_SINGH" style="width:110px;height:110px;object-fit:cover;border-radius:28px;margin-bottom:24px;box-shadow:0 20px 60px rgba(0,0,0,0.8);border:1px solid rgba(255,255,255,0.15);" />
      <h1 style="font-family:serif;font-size:28px;font-weight:normal;letter-spacing:0.2em;text-transform:uppercase;margin:0 0 8px 0;color:#fff;">MYself_SINGH</h1>
      <div style="font-family:monospace;font-size:10px;letter-spacing:0.25em;text-transform:uppercase;color:rgba(255,255,255,0.4);margin-bottom:32px;">Sophisticated Studio • Mobile IDE</div>
      <div style="width:100%;max-width:260px;height:3px;background:rgba(255,255,255,0.1);border-radius:9999px;overflow:hidden;position:relative;">
        <div id="splashProgress" style="width:0%;height:100%;background:#fff;border-radius:9999px;box-shadow:0 0 14px rgba(255,255,255,0.9);transition:width 0.05s linear;"></div>
      </div>
      <div style="margin-top:14px;font-family:monospace;font-size:11px;letter-spacing:0.2em;color:rgba(255,255,255,0.5);">INITIALIZING <span id="splashPct" style="color:#fff;font-weight:600;">0%</span></div>
    </div>
  </div>
  <script>
    let sp = 0;
    const spBar = document.getElementById('splashProgress');
    const spPct = document.getElementById('splashPct');
    const splashEl = document.getElementById('splashScreen');
    function dismissSplash() {
      if (!splashEl) return;
      splashEl.style.opacity = '0';
      setTimeout(() => splashEl.remove(), 600);
    }
    const spInterval = setInterval(() => {
      sp += 4;
      if (sp > 100) sp = 100;
      if (spBar) spBar.style.width = sp + '%';
      if (spPct) spPct.innerText = sp + '%';
      if (sp >= 100) {
        clearInterval(spInterval);
        setTimeout(dismissSplash, 300);
      }
    }, 80);
  </script>

  <div id="app">
    <!-- Header -->
    <header>
      <div class="brand-section">
        <!-- S Brand Logo toggles File Explorer Sidebar -->
        <button id="toggleSidebarBtn" class="brand-logo-btn" title="Toggle File Explorer (Files & Folders)">S</button>
        <div class="brand-text">
          <span class="brand-title">${appName}</span>
          <span class="brand-sub">STUDIO • MYself_SINGH</span>
        </div>
      </div>

      <!-- Action Buttons (Clean, High Contrast, Responsive) -->
      <div class="header-actions">
        <!-- Live Preview Button -->
        <button id="previewToggleBtn" class="btn-action accent" title="Toggle Live Web Preview">
          <span>▶</span> <span>Preview</span>
        </button>

        <!-- Import Local Files From Phone -->
        <button id="importBtn" class="btn-action" title="Import Files From Phone Storage">
          <span>📥</span> <span>Import</span>
        </button>

        <!-- Format Document -->
        <button id="formatBtn" class="btn-action" title="Format Document">
          <span>✨</span>
        </button>

        <!-- Find & Replace -->
        <button id="searchToggleBtn" class="btn-action" title="Find & Replace">
          <span>🔍</span>
        </button>

        <!-- Save / Export Current File -->
        <button id="saveFileBtn" class="btn-action" title="Save / Download File">
          <span>💾</span>
        </button>

        <!-- Theme Switcher -->
        <button id="themeToggleBtn" class="btn-action" title="Change Theme">
          <span>🌓</span>
        </button>
      </div>
    </header>

    <!-- Hidden Native File Inputs for Device Storage Access -->
    <input type="file" id="nativeFileInput" multiple accept="*/*" style="display:none;">
    <input type="file" id="nativeFolderInput" webkitdirectory directory multiple style="display:none;">

    <!-- Workspace -->
    <div class="workspace">
      <!-- File Explorer Sidebar -->
      <aside id="sidebar">
        <div class="sidebar-header">
          <span>Workspace Files</span>
          <div class="sidebar-tools">
            <button id="resetWorkspaceBtn" class="tool-btn" title="Reset Workspace & Restore Default Files">🔄 Reset</button>
            <button id="newFileQuickBtn" class="tool-btn" title="Create New File">+ File</button>
            <button id="importQuickBtn" class="tool-btn" title="Import from Phone">📥 Import</button>
          </div>
        </div>
        <div id="fileListContainer" class="file-list"></div>
      </aside>

      <!-- Center Code Editor -->
      <main class="editor-area">
        <!-- Multi-tab bar -->
        <div id="tabsContainer" class="tabs-bar"></div>

        <!-- Find & Replace Overlay -->
        <div id="searchBox" class="search-modal">
          <input type="text" id="searchInput" class="search-input" placeholder="Find in file...">
          <input type="text" id="replaceInput" class="search-input" placeholder="Replace with...">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span id="searchMatchesCount" style="font-size:11px; color:var(--text-muted);">0 matches</span>
            <div style="display:flex; gap:4px;">
              <button id="replaceOnceBtn" class="tool-btn">Replace</button>
              <button id="replaceAllBtn" class="btn-action accent" style="padding:2px 8px; font-size:11px;">Replace All</button>
              <button id="closeSearchBtn" class="tool-btn">✕</button>
            </div>
          </div>
        </div>

        <!-- Code Area & Gutter -->
        <div class="editor-wrapper">
          <div id="gutterContainer" class="gutter">1</div>
          <textarea id="codeTextArea" class="editor-textarea" spellcheck="false" autocomplete="off" autocapitalize="off"></textarea>
        </div>

        <!-- Mobile Quick Coding Toolbar -->
        <div class="quick-toolbar">
          <button class="key-btn" data-key="  ">TAB</button>
          <button class="key-btn" data-key="<">&lt;</button>
          <button class="key-btn" data-key=">">&gt;</button>
          <button class="key-btn" data-key="{">{}</button>
          <button class="key-btn" data-key="(">()</button>
          <button class="key-btn" data-key="[">[]</button>
          <button class="key-btn" data-key="=">=</button>
          <button class="key-btn" data-key=";">;</button>
          <button class="key-btn" data-key='"'>""</button>
          <button class="key-btn" data-key="'">''</button>
          <button class="key-btn" data-key="/">/</button>
          <button class="key-btn" data-key=":">:</button>
          <button class="key-btn" id="wrapBtn">Wrap: Off</button>
          <button class="key-btn" id="commentBtn">//</button>
          <button class="key-btn" id="exportCurrentBtn">📥 Download</button>
        </div>

        <!-- Integrated Terminal Panel -->
        <div id="terminalPanel" class="terminal-container hidden">
          <div class="term-bar">
            <span style="color:#06b6d4; font-weight:bold;">Gradle 8.7 & Shell Terminal</span>
            <button id="closeTermBtn" class="tool-btn">✕</button>
          </div>
          <div id="termLogs" class="term-content">
            <div><span style="color:#06b6d4;">MYself_EDITOR Environment v1.0.0 [Kotlin/Java/Web Ready]</span></div>
            <div>Type <span style="color:#eab308;">./gradlew assembleDebug</span> or <span style="color:#eab308;">help</span>.</div>
          </div>
          <div class="term-prompt-row">
            <span style="color:#06b6d4; font-weight:bold;">$</span>
            <input type="text" id="termInput" class="term-prompt-input" placeholder="Type command..." autocomplete="off">
          </div>
        </div>
      </main>

      <!-- Live Web Preview Split Screen / Bottom Sheet -->
      <section id="previewPanel" class="preview-container hidden">
        <div class="preview-bar">
          <div style="display:flex; align-items:center; gap:6px;">
            <span style="font-weight:700;">Live Web Preview</span>
            <span style="font-size:10px; color:var(--text-muted);">(Real-time Rendering)</span>
          </div>
          <div style="display:flex; align-items:center; gap:4px;">
            <button id="reloadPreviewBtn" class="tool-btn">🔄 Reload</button>
            <button id="closePreviewBtn" class="tool-btn">✕ Close</button>
          </div>
        </div>
        <iframe id="previewIframe" class="preview-frame" sandbox="allow-scripts allow-modals allow-forms allow-same-origin"></iframe>
      </section>
    </div>
  </div>

  <!-- Embedded Initial Project Data (Safe JSON Scripts) -->
  <script id="bundled-files-data" type="application/json">
${serializedFiles}
  </script>
  <script id="fallback-files-data" type="application/json">
${fallbackFilesJson}
  </script>

  <!-- Toast Notification -->
  <div id="toast">Saved</div>

  <script>
    // Global Error Guard
    window.onerror = function(msg, url, line) {
      console.error("IDE Runtime Error:", msg, "at", url, ":", line);
      try {
        var toast = document.getElementById('toast');
        if (toast) {
          toast.innerText = 'Notice: ' + msg;
          toast.classList.add('show');
          setTimeout(function() { toast.classList.remove('show'); }, 3000);
        }
      } catch(e) {}
      return false;
    };

    function loadJsonData(id) {
      try {
        const el = document.getElementById(id);
        if (el && el.textContent && el.textContent.trim()) {
          const parsed = JSON.parse(el.textContent.trim());
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed;
          }
        }
      } catch(e) {
        console.error('Failed to parse ' + id, e);
      }
      return null;
    }

    // State Initialization
    let defaultBundledFiles = loadJsonData('bundled-files-data') || [];
    let fallbackDefaultFiles = loadJsonData('fallback-files-data') || [];

    if (!Array.isArray(defaultBundledFiles) || defaultBundledFiles.length === 0) {
      defaultBundledFiles = fallbackDefaultFiles;
    }

    let files = [];
    try {
      const saved = localStorage.getItem('myself_editor_files_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          files = parsed;
        }
      }
    } catch(e) {
      console.warn("localStorage access warning:", e);
    }

    if (!Array.isArray(files) || files.length === 0) {
      files = (defaultBundledFiles && defaultBundledFiles.length > 0) ? defaultBundledFiles : fallbackDefaultFiles;
    }

    if (!Array.isArray(files) || files.length === 0) {
      files = [
        { id: 'f_index', name: 'index.html', path: '/index.html', language: 'html', content: '<!DOCTYPE html>\n<html>\n<head>\n  <meta charset="UTF-8">\n  <title>MYself_EDITOR</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <h1>Welcome to MYself_EDITOR</h1>\n  <p>Your mobile IDE is running offline successfully.</p>\n  <script src="script.js"><\\/script>\n</body>\n</html>' },
        { id: 'f_css', name: 'style.css', path: '/style.css', language: 'css', content: 'body {\n  font-family: sans-serif;\n  background: #090a0f;\n  color: #e2e8f0;\n  padding: 20px;\n}' },
        { id: 'f_js', name: 'script.js', path: '/script.js', language: 'javascript', content: 'console.log("MYself_EDITOR initialized successfully!");' }
      ];
    }

    let activeFileId = files[0] ? files[0].id : 'f_index';
    let fontSize = 14;
    let isWrapped = false;
    let themes = ['dark', 'light', 'midnight', 'matrix'];
    let currentThemeIdx = 0;

    // DOM References
    const sidebar = document.getElementById('sidebar');
    const toggleSidebarBtn = document.getElementById('toggleSidebarBtn');
    const fileListContainer = document.getElementById('fileListContainer');
    const tabsContainer = document.getElementById('tabsContainer');
    const codeTextArea = document.getElementById('codeTextArea');
    const gutterContainer = document.getElementById('gutterContainer');
    const toast = document.getElementById('toast');

    const previewToggleBtn = document.getElementById('previewToggleBtn');
    const previewPanel = document.getElementById('previewPanel');
    const previewIframe = document.getElementById('previewIframe');
    const reloadPreviewBtn = document.getElementById('reloadPreviewBtn');
    const closePreviewBtn = document.getElementById('closePreviewBtn');

    const termToggleBtn = document.getElementById('termToggleBtn');
    const terminalPanel = document.getElementById('terminalPanel');
    const termLogs = document.getElementById('termLogs');
    const termInput = document.getElementById('termInput');
    const closeTermBtn = document.getElementById('closeTermBtn');

    const searchToggleBtn = document.getElementById('searchToggleBtn');
    const searchBox = document.getElementById('searchBox');
    const searchInput = document.getElementById('searchInput');
    const replaceInput = document.getElementById('replaceInput');
    const searchMatchesCount = document.getElementById('searchMatchesCount');
    const replaceOnceBtn = document.getElementById('replaceOnceBtn');
    const replaceAllBtn = document.getElementById('replaceAllBtn');
    const closeSearchBtn = document.getElementById('closeSearchBtn');

    const zoomMinus = document.getElementById('zoomMinus');
    const zoomPlus = document.getElementById('zoomPlus');
    const zoomDisplay = document.getElementById('zoomDisplay');
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    const saveFileBtn = document.getElementById('saveFileBtn');
    const formatBtn = document.getElementById('formatBtn');
    const wrapBtn = document.getElementById('wrapBtn');
    const commentBtn = document.getElementById('commentBtn');
    const exportCurrentBtn = document.getElementById('exportCurrentBtn');

    const nativeFileInput = document.getElementById('nativeFileInput');
    const importBtn = document.getElementById('importBtn');
    const importQuickBtn = document.getElementById('importQuickBtn');
    const newFileQuickBtn = document.getElementById('newFileQuickBtn');

    function showToast(msg) {
      toast.innerText = msg;
      toast.classList.add('show');
      setTimeout(() => toast.classList.remove('show'), 1600);
    }

    function saveState() {
      try {
        if (files && files.length > 0) {
          localStorage.setItem('myself_editor_files_v2', JSON.stringify(files));
        }
      } catch(e) {}
    }

    function getActiveFile() {
      if (!files || files.length === 0) {
        files = defaultBundledFiles.length > 0 ? defaultBundledFiles : fallbackDefaultFiles;
        activeFileId = files[0].id;
      }
      return files.find(f => f.id === activeFileId) || files[0];
    }

    function getFileIcon(name) {
      if (name.endsWith('.html')) return '🌐';
      if (name.endsWith('.css')) return '🎨';
      if (name.endsWith('.js') || name.endsWith('.ts')) return '⚡';
      if (name.endsWith('.kt') || name.endsWith('.java')) return '🤖';
      if (name.endsWith('.py')) return '🐍';
      if (name.endsWith('.json')) return '📦';
      if (name.endsWith('.md')) return '📝';
      return '📄';
    }

    // Line numbering calculation
    function updateGutter() {
      const text = codeTextArea.value;
      const lines = text.split('\\n');
      let gutterText = '';
      for (let i = 1; i <= lines.length; i++) {
        gutterText += i + '\\n';
      }
      gutterContainer.innerText = gutterText;
      gutterContainer.scrollTop = codeTextArea.scrollTop;
    }

    function renderFileList() {
      fileListContainer.innerHTML = '';
      files.forEach(f => {
        const item = document.createElement('div');
        item.className = 'file-item' + (f.id === activeFileId ? ' active' : '');
        item.innerHTML = \`
          <div class="file-name-wrap">
            <span>\${getFileIcon(f.name)}</span>
            <span style="overflow:hidden; text-overflow:ellipsis;">\${f.name}</span>
          </div>
          <div class="file-actions">
            <button class="mini-icon-btn del-btn" title="Delete">🗑️</button>
          </div>
        \`;
        item.onclick = (e) => {
          if (e.target.classList.contains('del-btn')) {
            e.stopPropagation();
            deleteFile(f.id);
            return;
          }
          activeFileId = f.id;
          loadFileContent();
          renderFileList();
          renderTabs();
          if (window.innerWidth < 768) {
            sidebar.classList.add('collapsed');
          }
        };
        fileListContainer.appendChild(item);
      });
    }

    function renderTabs() {
      tabsContainer.innerHTML = '';
      files.forEach(f => {
        const tab = document.createElement('div');
        tab.className = 'tab' + (f.id === activeFileId ? ' active' : '');
        tab.innerHTML = \`
          <span>\${getFileIcon(f.name)} \${f.name}</span>
          \${files.length > 1 ? '<span class="tab-close" data-id="' + f.id + '">✕</span>' : ''}
        \`;
        tab.onclick = (e) => {
          if (e.target.classList.contains('tab-close')) {
            e.stopPropagation();
            deleteFile(f.id);
            return;
          }
          activeFileId = f.id;
          loadFileContent();
          renderFileList();
          renderTabs();
        };
        tabsContainer.appendChild(tab);
      });
    }

    function loadFileContent() {
      const f = getActiveFile();
      if (f) {
        codeTextArea.value = f.content || '';
        updateGutter();
      }
    }

    function deleteFile(id) {
      if (files.length <= 1) {
        showToast('Cannot delete the last file');
        return;
      }
      const target = files.find(f => f.id === id);
      if (confirm('Delete ' + (target ? target.name : 'file') + '?')) {
        files = files.filter(f => f.id !== id);
        if (activeFileId === id) {
          activeFileId = files[0].id;
        }
        loadFileContent();
        renderFileList();
        renderTabs();
        saveState();
        showToast('File deleted');
      }
    }

    // Input handlers
    codeTextArea.addEventListener('input', () => {
      const f = getActiveFile();
      if (f) {
        f.content = codeTextArea.value;
        updateGutter();
        saveState();
        if (!previewPanel.classList.contains('hidden')) {
          renderPreview();
        }
      }
    });

    codeTextArea.addEventListener('scroll', () => {
      gutterContainer.scrollTop = codeTextArea.scrollTop;
    });

    // Formatting / Beautifying Code
    function formatCode() {
      const f = getActiveFile();
      if (!f) return;
      let text = codeTextArea.value;
      const ext = f.name.split('.').pop() || '';

      if (ext === 'json') {
        try {
          const parsed = JSON.parse(text);
          text = JSON.stringify(parsed, null, 2);
          codeTextArea.value = text;
          f.content = text;
          updateGutter();
          saveState();
          showToast('JSON Formatted ✨');
          return;
        } catch(e) {
          showToast('Invalid JSON');
          return;
        }
      }

      // Clean Indentation Formatter for HTML / CSS / JS / Kotlin
      const lines = text.split('\\n');
      let indentLevel = 0;
      const formattedLines = [];

      for (let line of lines) {
        const trimmed = line.trim();
        if (!trimmed) {
          formattedLines.push('');
          continue;
        }

        // Check if line closes block
        if (trimmed.startsWith('}') || trimmed.startsWith('</') || trimmed.startsWith(']') || trimmed.startsWith(')')) {
          indentLevel = Math.max(0, indentLevel - 1);
        }

        formattedLines.push('  '.repeat(indentLevel) + trimmed);

        // Check if line opens block
        if ((trimmed.endsWith('{') || trimmed.endsWith('(') || (trimmed.startsWith('<') && !trimmed.startsWith('</') && !trimmed.endsWith('/>') && !trimmed.includes('</'))) && !trimmed.startsWith('<!--')) {
          indentLevel++;
        }
      }

      text = formattedLines.join('\\n');
      codeTextArea.value = text;
      f.content = text;
      updateGutter();
      saveState();
      showToast('Document Formatted ✨');
    }

    formatBtn.onclick = formatCode;

    // Word Wrap
    wrapBtn.onclick = () => {
      isWrapped = !isWrapped;
      codeTextArea.classList.toggle('wrapped', isWrapped);
      wrapBtn.innerText = isWrapped ? 'Wrap: On' : 'Wrap: Off';
      wrapBtn.style.color = isWrapped ? 'var(--accent)' : 'inherit';
      showToast(isWrapped ? 'Word Wrap Enabled' : 'Word Wrap Disabled');
    };

    // Zoom Controls
    function setZoom(newSize) {
      fontSize = Math.max(10, Math.min(30, newSize));
      document.documentElement.style.setProperty('--font-size', fontSize + 'px');
      zoomDisplay.innerText = Math.round((fontSize / 14) * 100) + '%';
    }
    zoomPlus.onclick = () => setZoom(fontSize + 2);
    zoomMinus.onclick = () => setZoom(fontSize - 2);

    // Sidebar Toggle
    toggleSidebarBtn.onclick = () => sidebar.classList.toggle('collapsed');

    // Reset Workspace to Default Starter Files
    const resetWorkspaceBtn = document.getElementById('resetWorkspaceBtn');
    if (resetWorkspaceBtn) {
      resetWorkspaceBtn.onclick = () => {
        if (confirm('Reset workspace to default starter files? This will replace current local workspace files.')) {
          const defaults = (defaultBundledFiles && defaultBundledFiles.length > 0) ? defaultBundledFiles : fallbackDefaultFiles;
          files = JSON.parse(JSON.stringify(defaults));
          activeFileId = files[0] ? files[0].id : 'f_index';
          saveState();
          renderFileList();
          renderTabs();
          loadFileContent();
          showToast('Workspace reset to starter files ✨');
        }
      };
    }

    // New File Creator
    function createNewFile() {
      const name = prompt('Enter filename (e.g. script.js, page.html, Main.kt, styles.css):');
      if (name && name.trim()) {
        const clean = name.trim();
        const ext = clean.split('.').pop() || 'txt';
        const newFile = {
          id: 'file_' + Date.now(),
          name: clean,
          path: '/' + clean,
          language: ext,
          content: ''
        };
        files.push(newFile);
        activeFileId = newFile.id;
        loadFileContent();
        renderFileList();
        renderTabs();
        saveState();
        showToast('Created ' + clean);
      }
    }
    newFileQuickBtn.onclick = createNewFile;

    // Native Storage File Import (Access Local Device Files)
    function triggerDeviceImport() {
      nativeFileInput.click();
    }
    importBtn.onclick = triggerDeviceImport;
    importQuickBtn.onclick = triggerDeviceImport;

    nativeFileInput.addEventListener('change', (e) => {
      const uploaded = e.target.files;
      if (!uploaded || uploaded.length === 0) return;

      Array.from(uploaded).forEach(file => {
        const reader = new FileReader();
        reader.onload = (ev) => {
          const content = ev.target.result;
          const ext = file.name.split('.').pop() || 'txt';
          const newF = {
            id: 'file_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
            name: file.name,
            path: '/' + file.name,
            language: ext,
            content: content || ''
          };
          files.push(newF);
          activeFileId = newF.id;
          loadFileContent();
          renderFileList();
          renderTabs();
          saveState();
          showToast('Imported ' + file.name + ' from storage!');
        };
        reader.readAsText(file);
      });
      nativeFileInput.value = '';
    });

    // Save / Download File to Phone Storage
    function downloadCurrentFile() {
      const f = getActiveFile();
      if (!f) return;
      const blob = new Blob([f.content || ''], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = f.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      showToast('Downloaded ' + f.name + ' to device');
    }
    saveFileBtn.onclick = downloadCurrentFile;
    exportCurrentBtn.onclick = downloadCurrentFile;

    // Live Web Preview
    function renderPreview() {
      const htmlFile = files.find(f => f.name === 'index.html' || f.name.endsWith('.html')) || getActiveFile();
      const cssFiles = files.filter(f => f.name.endsWith('.css'));
      const jsFiles = files.filter(f => f.name.endsWith('.js') && f.name !== 'service-worker.js');

      let combined = htmlFile ? htmlFile.content : '<h2>No HTML File</h2>';
      cssFiles.forEach(css => {
        combined += '<style>' + css.content + '</style>';
      });
      jsFiles.forEach(js => {
        combined += '<script>' + js.content + '<\\/script>';
      });

      const blob = new Blob([combined], { type: 'text/html;charset=utf-8' });
      previewIframe.src = URL.createObjectURL(blob);
    }

    previewToggleBtn.onclick = () => {
      previewPanel.classList.toggle('hidden');
      previewToggleBtn.classList.toggle('active', !previewPanel.classList.contains('hidden'));
      if (!previewPanel.classList.contains('hidden')) {
        renderPreview();
      }
    };
    reloadPreviewBtn.onclick = renderPreview;
    closePreviewBtn.onclick = () => {
      previewPanel.classList.add('hidden');
      previewToggleBtn.classList.remove('active');
    };

    // Terminal
    termToggleBtn.onclick = () => {
      terminalPanel.classList.toggle('hidden');
      termToggleBtn.classList.toggle('active', !terminalPanel.classList.contains('hidden'));
      if (!terminalPanel.classList.contains('hidden')) {
        termInput.focus();
      }
    };
    closeTermBtn.onclick = () => {
      terminalPanel.classList.add('hidden');
      termToggleBtn.classList.remove('active');
    };

    termInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const cmd = termInput.value.trim();
        if (!cmd) return;
        termInput.value = '';

        const row = document.createElement('div');
        row.innerHTML = '<span style="color:#06b6d4;">$ </span><span>' + cmd + '</span>';
        termLogs.appendChild(row);

        if (cmd === 'clear') {
          termLogs.innerHTML = '';
        } else if (cmd.includes('assembleDebug') || cmd.includes('gradlew build')) {
          const out = document.createElement('div');
          out.innerHTML = \`
            <div style="color:#eab308;">> Task :app:compileDebugKotlin</div>
            <div style="color:#eab308;">> Task :app:mergeDebugResources</div>
            <div style="color:#eab308;">> Task :app:packageDebug</div>
            <div style="color:#22c55e; font-weight:bold;">BUILD SUCCESSFUL in 1.2s</div>
            <div style="color:#38bdf8;">APK Ready: app/build/outputs/apk/debug/app-debug.apk</div>
          \`;
          termLogs.appendChild(out);
        } else if (cmd === 'ls') {
          const out = document.createElement('div');
          out.style.color = '#93c5fd';
          out.innerText = files.map(f => f.name).join('   ');
          termLogs.appendChild(out);
        } else if (cmd === 'help') {
          const out = document.createElement('div');
          out.innerHTML = \`
            Commands:
             - ./gradlew assembleDebug  : Compile Android APK
             - ls                       : List workspace files
             - clear                    : Clear terminal
             - help                     : View commands
          \`;
          termLogs.appendChild(out);
        } else {
          const out = document.createElement('div');
          out.style.color = '#f87171';
          out.innerText = 'Command not found: ' + cmd;
          termLogs.appendChild(out);
        }
        termLogs.scrollTop = termLogs.scrollHeight;
      }
    });

    // Theme Switcher
    themeToggleBtn.onclick = () => {
      currentThemeIdx = (currentThemeIdx + 1) % themes.length;
      const theme = themes[currentThemeIdx];
      document.body.setAttribute('data-theme', theme);
      showToast('Theme: ' + theme.toUpperCase());
    };

    // Quick Keys
    document.querySelectorAll('.key-btn[data-key]').forEach(btn => {
      btn.onclick = () => {
        const ins = btn.getAttribute('data-key');
        const start = codeTextArea.selectionStart;
        const end = codeTextArea.selectionEnd;
        const val = codeTextArea.value;
        codeTextArea.value = val.substring(0, start) + ins + val.substring(end);
        codeTextArea.selectionStart = codeTextArea.selectionEnd = start + ins.length;
        codeTextArea.focus();
        const f = getActiveFile();
        if (f) f.content = codeTextArea.value;
        updateGutter();
        saveState();
      };
    });

    commentBtn.onclick = () => {
      const start = codeTextArea.selectionStart;
      const val = codeTextArea.value;
      codeTextArea.value = val.substring(0, start) + '// ' + val.substring(start);
      codeTextArea.focus();
      const f = getActiveFile();
      if (f) f.content = codeTextArea.value;
      updateGutter();
      saveState();
    };

    // Search & Replace
    searchToggleBtn.onclick = () => {
      searchBox.classList.toggle('open');
      if (searchBox.classList.contains('open')) {
        searchInput.focus();
      }
    };
    closeSearchBtn.onclick = () => searchBox.classList.remove('open');

    searchInput.addEventListener('input', () => {
      const q = searchInput.value;
      if (!q) {
        searchMatchesCount.innerText = '0 matches';
        return;
      }
      const count = (codeTextArea.value.match(new RegExp(q, 'gi')) || []).length;
      searchMatchesCount.innerText = count + ' matches';
    });

    replaceOnceBtn.onclick = () => {
      const q = searchInput.value;
      const rep = replaceInput.value;
      if (q) {
        codeTextArea.value = codeTextArea.value.replace(new RegExp(q, 'i'), rep);
        const f = getActiveFile();
        if (f) f.content = codeTextArea.value;
        saveState();
        updateGutter();
        showToast('Replaced 1 occurrence');
      }
    };

    replaceAllBtn.onclick = () => {
      const q = searchInput.value;
      const rep = replaceInput.value;
      if (q) {
        const count = (codeTextArea.value.match(new RegExp(q, 'gi')) || []).length;
        codeTextArea.value = codeTextArea.value.replaceAll(new RegExp(q, 'gi'), rep);
        const f = getActiveFile();
        if (f) f.content = codeTextArea.value;
        saveState();
        updateGutter();
        showToast('Replaced ' + count + ' occurrences');
      }
    };

    // Initialize View
    renderFileList();
    renderTabs();
    loadFileContent();
  </script>
</body>
</html>`;
}
