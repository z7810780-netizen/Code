import { EditorFile } from '../types';

export const DEFAULT_FILES: EditorFile[] = [
  {
    id: 'file-index-html',
    name: 'index.html',
    path: '/index.html',
    language: 'html',
    encoding: 'UTF-8',
    lineEnding: 'LF',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MYself_EDITOR App</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="card">
    <div class="badge">MYself_EDITOR</div>
    <h1>Hello from Mobile IDE</h1>
    <p>Edit HTML, CSS, JavaScript, Kotlin, or Python with full live preview!</p>
    <button id="counterBtn" class="btn">Clicks: 0</button>
  </div>
  <script src="app.js"></script>
</body>
</html>`
  },
  {
    id: 'file-style-css',
    name: 'style.css',
    path: '/style.css',
    language: 'css',
    encoding: 'UTF-8',
    lineEnding: 'LF',
    content: `* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}

body {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: radial-gradient(circle at center, #1a1a24 0%, #0c0d14 100%);
  color: #f1f5f9;
  padding: 20px;
}

.card {
  background: rgba(30, 31, 46, 0.85);
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(12px);
  padding: 32px;
  border-radius: 16px;
  max-width: 440px;
  text-align: center;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.5);
}

.badge {
  display: inline-block;
  font-size: 11px;
  letter-spacing: 1.5px;
  font-weight: 700;
  color: #38bdf8;
  background: rgba(56, 189, 248, 0.12);
  padding: 4px 12px;
  border-radius: 9999px;
  margin-bottom: 16px;
}

h1 {
  font-size: 24px;
  font-weight: 700;
  margin-bottom: 12px;
  letter-spacing: -0.5px;
}

p {
  color: #94a3b8;
  font-size: 14px;
  line-height: 1.6;
  margin-bottom: 24px;
}

.btn {
  background: linear-gradient(135deg, #38bdf8, #6366f1);
  color: white;
  border: none;
  font-size: 14px;
  font-weight: 600;
  padding: 10px 24px;
  border-radius: 8px;
  cursor: pointer;
  transition: transform 0.15s, opacity 0.15s;
}

.btn:active {
  transform: scale(0.96);
}`
  },
  {
    id: 'file-app-js',
    name: 'app.js',
    path: '/app.js',
    language: 'javascript',
    encoding: 'UTF-8',
    lineEnding: 'LF',
    content: `// Interactive JavaScript logic
let count = 0;
const btn = document.getElementById('counterBtn');

if (btn) {
  btn.addEventListener('click', () => {
    count++;
    btn.textContent = \`Clicks: \${count}\`;
    console.log(\`[MYself_EDITOR] Counter updated to \${count}\`);
  });
}

console.log('MYself_EDITOR Web Preview initialized.');`
  },
  {
    id: 'file-main-activity',
    name: 'MainActivity.kt',
    path: '/app/src/main/java/com/myselfsinghcodeeditor/MainActivity.kt',
    language: 'kotlin',
    encoding: 'UTF-8',
    lineEnding: 'LF',
    content: `package com.myselfsinghcodeeditor

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.mainWebView)
        
        val webSettings: WebSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.allowFileAccess = true
        webSettings.allowContentAccess = true
        webSettings.databaseEnabled = true
        webSettings.useWideViewPort = true
        webSettings.loadWithOverviewMode = true

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
            }
        }

        // Load self-contained local IDE and asset package
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}`
  },
  {
    id: 'file-python-script',
    name: 'main.py',
    path: '/main.py',
    language: 'python',
    encoding: 'UTF-8',
    lineEnding: 'LF',
    content: `import sys

def main():
    print("Welcome to MYself_EDITOR - Python Runner!")
    languages = ["Kotlin", "Java", "Python", "JavaScript", "Rust", "C++"]
    print(f"Supported mobile IDE languages: {', '.join(languages)}")

if __name__ == "__main__":
    main()`
  },
  {
    id: 'file-readme-md',
    name: 'README.md',
    path: '/README.md',
    language: 'markdown',
    encoding: 'UTF-8',
    lineEnding: 'LF',
    content: `# MYself_EDITOR

A complete, high-performance Android & Web Code Editor and Mobile IDE.

## Features
- **Multi-Tab File System**: Create, edit, save, rename, and duplicate files.
- **Rich Syntax Highlighting**: Full tokenization for HTML, CSS, JS, TS, Kotlin, Python, C++, etc.
- **Built-in HTML Live Preview**: Live interactive rendering with console logs.
- **Integrated Terminal**: Execute interactive shell commands (\`help\`, \`ls\`, \`run\`, \`cat\`).
- **Customizable Themes & Typography**: Dracula, VS Dark, Monokai, Nord, Light themes.
- **Android APK Ready**: Complete gradle structure ready for GitHub Codespaces \`./gradlew assembleDebug\`.

## Generated By
**MYself_SINGH**`
  }
];
