export function detectLanguage(fileName: string): string {
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  switch (ext) {
    case 'html':
    case 'htm':
      return 'html';
    case 'css':
    case 'scss':
    case 'less':
      return 'css';
    case 'js':
    case 'mjs':
    case 'cjs':
      return 'javascript';
    case 'ts':
    case 'tsx':
    case 'jsx':
      return 'typescript';
    case 'kt':
    case 'kts':
      return 'kotlin';
    case 'java':
      return 'java';
    case 'py':
    case 'pyw':
      return 'python';
    case 'c':
    case 'h':
      return 'c';
    case 'cpp':
    case 'hpp':
    case 'cc':
      return 'cpp';
    case 'cs':
      return 'csharp';
    case 'json':
      return 'json';
    case 'xml':
    case 'svg':
      return 'xml';
    case 'md':
    case 'markdown':
      return 'markdown';
    case 'sql':
      return 'sql';
    case 'sh':
    case 'bash':
    case 'zsh':
      return 'shell';
    case 'rs':
      return 'rust';
    case 'go':
      return 'go';
    case 'php':
      return 'php';
    case 'yaml':
    case 'yml':
      return 'yaml';
    case 'toml':
      return 'toml';
    case 'dart':
      return 'dart';
    case 'lua':
      return 'lua';
    default:
      return 'plaintext';
  }
}

export interface HighlightToken {
  text: string;
  type:
    | 'keyword'
    | 'type'
    | 'string'
    | 'number'
    | 'comment'
    | 'function'
    | 'tag'
    | 'attr'
    | 'punctuation'
    | 'operator'
    | 'identifier'
    | 'plain';
}

const KEYWORDS_BY_LANG: Record<string, Set<string>> = {
  javascript: new Set([
    'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'do',
    'switch', 'case', 'break', 'continue', 'default', 'try', 'catch', 'finally',
    'throw', 'class', 'extends', 'super', 'this', 'new', 'import', 'export', 'from',
    'as', 'async', 'await', 'yield', 'typeof', 'instanceof', 'void', 'delete', 'in',
    'of', 'null', 'undefined', 'true', 'false', 'debugger'
  ]),
  typescript: new Set([
    'const', 'let', 'var', 'function', 'return', 'if', 'else', 'for', 'while', 'do',
    'switch', 'case', 'break', 'continue', 'default', 'try', 'catch', 'finally',
    'throw', 'class', 'extends', 'super', 'this', 'new', 'import', 'export', 'from',
    'as', 'async', 'await', 'yield', 'typeof', 'instanceof', 'void', 'delete', 'in',
    'of', 'null', 'undefined', 'true', 'false', 'type', 'interface', 'enum',
    'implements', 'declare', 'abstract', 'public', 'private', 'protected', 'readonly',
    'override', 'debugger'
  ]),
  kotlin: new Set([
    'package', 'import', 'class', 'interface', 'fun', 'val', 'var', 'object', 'companion',
    'if', 'else', 'when', 'for', 'while', 'do', 'return', 'break', 'continue',
    'throw', 'try', 'catch', 'finally', 'null', 'true', 'false', 'this', 'super',
    'is', 'in', 'as', 'override', 'open', 'final', 'data', 'sealed', 'suspend',
    'private', 'protected', 'public', 'internal', 'lateinit', 'inline', 'enum'
  ]),
  java: new Set([
    'package', 'import', 'public', 'private', 'protected', 'class', 'interface', 'enum',
    'extends', 'implements', 'static', 'final', 'void', 'return', 'if', 'else', 'for',
    'while', 'do', 'switch', 'case', 'break', 'continue', 'default', 'try', 'catch',
    'finally', 'throw', 'throws', 'new', 'this', 'super', 'null', 'true', 'false'
  ]),
  python: new Set([
    'def', 'class', 'return', 'if', 'elif', 'else', 'for', 'while', 'break', 'continue',
    'try', 'except', 'finally', 'raise', 'import', 'from', 'as', 'pass', 'with',
    'yield', 'async', 'await', 'lambda', 'global', 'nonlocal', 'assert', 'del',
    'None', 'True', 'False', 'and', 'or', 'not', 'is', 'in'
  ]),
  c: new Set([
    'auto', 'break', 'case', 'const', 'continue', 'default', 'do',
    'else', 'enum', 'extern', 'for', 'goto', 'if',
    'register', 'return', 'signed', 'sizeof', 'static', 'struct',
    'switch', 'typedef', 'union', 'unsigned', 'void', 'volatile', 'while', '#include', '#define'
  ]),
  cpp: new Set([
    'auto', 'break', 'case', 'const', 'continue', 'default', 'do',
    'else', 'enum', 'extern', 'for', 'goto', 'if',
    'register', 'return', 'signed', 'sizeof', 'static', 'struct',
    'switch', 'typedef', 'union', 'unsigned', 'void', 'volatile', 'while', '#include', '#define',
    'class', 'namespace', 'using', 'template', 'typename', 'public', 'private', 'protected',
    'virtual', 'override', 'constexpr', 'nullptr', 'true', 'false'
  ]),
  sql: new Set([
    'select', 'from', 'where', 'insert', 'into', 'values', 'update', 'set', 'delete',
    'create', 'table', 'drop', 'alter', 'index', 'primary', 'key', 'foreign',
    'references', 'join', 'left', 'right', 'inner', 'outer', 'on', 'group', 'by',
    'order', 'having', 'distinct', 'limit', 'offset', 'and', 'or', 'not', 'in',
    'like', 'is', 'null', 'as', 'union', 'all', 'case', 'when', 'then', 'else', 'end'
  ]),
  shell: new Set([
    'if', 'then', 'else', 'elif', 'fi', 'for', 'while', 'until', 'do', 'done',
    'case', 'esac', 'function', 'return', 'exit', 'export', 'echo', 'cd', 'ls',
    'mkdir', 'rm', 'cp', 'mv', 'cat', 'grep', 'chmod', 'sudo'
  ]),
  rust: new Set([
    'fn', 'let', 'mut', 'const', 'static', 'struct', 'enum', 'trait', 'impl', 'type',
    'if', 'else', 'match', 'for', 'while', 'loop', 'return', 'break', 'continue',
    'pub', 'use', 'mod', 'crate', 'self', 'Self', 'super', 'unsafe', 'where',
    'async', 'await', 'true', 'false', 'None', 'Some', 'Ok', 'Err'
  ]),
  go: new Set([
    'package', 'import', 'func', 'return', 'var', 'const', 'type', 'struct', 'interface',
    'if', 'else', 'switch', 'case', 'default', 'for', 'range', 'break', 'continue',
    'goto', 'fallthrough', 'defer', 'go', 'select', 'chan', 'map', 'nil', 'true', 'false'
  ]),
  php: new Set([
    'function', 'return', 'if', 'else', 'elseif', 'while', 'do', 'for', 'foreach', 'as',
    'switch', 'case', 'break', 'continue', 'default', 'try', 'catch', 'finally',
    'throw', 'class', 'extends', 'implements', 'interface', 'public', 'private', 'protected',
    'static', 'final', 'new', 'echo', 'print', 'include', 'require', 'null', 'true', 'false'
  ])
};

const TYPES_BY_LANG: Record<string, Set<string>> = {
  javascript: new Set(['Array', 'Object', 'String', 'Number', 'Boolean', 'Promise', 'Map', 'Set', 'Date', 'RegExp', 'Math', 'JSON', 'console', 'window', 'document']),
  typescript: new Set(['any', 'number', 'string', 'boolean', 'symbol', 'unknown', 'never', 'void', 'Array', 'Object', 'String', 'Number', 'Boolean', 'Promise', 'Map', 'Set', 'Record', 'Partial', 'Pick', 'Omit', 'React', 'ReactNode', 'FC', 'HTMLDivElement', 'HTMLInputElement', 'HTMLElement', 'Event', 'CustomEvent']),
  kotlin: new Set(['Int', 'Long', 'Float', 'Double', 'Boolean', 'String', 'Char', 'Byte', 'Short', 'Array', 'List', 'Map', 'Set', 'Any', 'Unit', 'Nothing']),
  java: new Set(['int', 'long', 'float', 'double', 'boolean', 'char', 'byte', 'short', 'String', 'Integer', 'Long', 'Float', 'Double', 'Boolean', 'List', 'Map', 'Set', 'ArrayList', 'HashMap', 'Object', 'System']),
  python: new Set(['int', 'float', 'str', 'bool', 'list', 'dict', 'set', 'tuple', 'bytes', 'object', 'type', 'print', 'len', 'range', 'enumerate']),
  c: new Set(['int', 'long', 'float', 'double', 'char', 'short', 'signed', 'unsigned', 'void', 'size_t']),
  cpp: new Set(['int', 'long', 'float', 'double', 'char', 'short', 'signed', 'unsigned', 'void', 'size_t', 'string', 'vector', 'map', 'set', 'pair', 'std']),
  rust: new Set(['i8', 'i16', 'i32', 'i64', 'i128', 'isize', 'u8', 'u16', 'u32', 'u64', 'u128', 'usize', 'f32', 'f64', 'bool', 'char', 'str', 'String', 'Vec', 'Option', 'Result']),
  go: new Set(['int', 'int8', 'int16', 'int32', 'int64', 'uint', 'uint8', 'uint16', 'uint32', 'uint64', 'float32', 'float64', 'string', 'bool', 'byte', 'rune', 'error'])
};

export function tokenizeLine(line: string, language: string): HighlightToken[] {
  if (!line) return [{ text: '', type: 'plain' }];

  const tokens: HighlightToken[] = [];
  let i = 0;
  const len = line.length;
  const keywords = KEYWORDS_BY_LANG[language] || KEYWORDS_BY_LANG['javascript'];

  // Check line comments
  const trimmed = line.trimStart();
  const indentLength = line.length - trimmed.length;

  if (
    (language === 'html' || language === 'xml') &&
    trimmed.startsWith('<!--')
  ) {
    return [{ text: line, type: 'comment' }];
  }

  while (i < len) {
    const char = line[i];

    // Single line comments
    if (
      (char === '/' && line[i + 1] === '/') ||
      (char === '#' && (language === 'python' || language === 'shell' || language === 'yaml' || language === 'toml')) ||
      (char === '-' && line[i + 1] === '-' && language === 'sql')
    ) {
      tokens.push({ text: line.slice(i), type: 'comment' });
      break;
    }

    // Strings
    if (char === '"' || char === "'" || char === '`') {
      const quote = char;
      let str = quote;
      let j = i + 1;
      let escaped = false;
      while (j < len) {
        const c = line[j];
        str += c;
        if (c === quote && !escaped) {
          j++;
          break;
        }
        if (c === '\\') {
          escaped = !escaped;
        } else {
          escaped = false;
        }
        j++;
      }
      tokens.push({ text: str, type: 'string' });
      i = j;
      continue;
    }

    // HTML / XML / JSX Tags
    if ((language === 'html' || language === 'xml' || language === 'typescript' || language === 'javascript') && char === '<' && (line[i+1] === '/' || /[a-zA-Z]/.test(line[i+1] || ''))) {
      let tagStr = '<';
      let j = i + 1;
      while (j < len && line[j] !== ' ' && line[j] !== '>' && line[j] !== '/' && line[j] !== '\t') {
        tagStr += line[j];
        j++;
      }
      tokens.push({ text: tagStr, type: 'tag' });
      i = j;
      continue;
    }

    // Numbers
    if (/\d/.test(char) && (i === 0 || /[\s\(\)\[\]\{\},\+\-\*\/=><;:!&|%]/.test(line[i - 1]))) {
      let numStr = '';
      let j = i;
      while (j < len && /[\d\.xXa-fA-FbBoO_]/.test(line[j])) {
        numStr += line[j];
        j++;
      }
      // check units like px, em, rem, ms, s, % in CSS
      if (language === 'css' && j < len && /[a-z%]/.test(line[j])) {
        while (j < len && /[a-z%]/.test(line[j])) {
          numStr += line[j];
          j++;
        }
      }
      tokens.push({ text: numStr, type: 'number' });
      i = j;
      continue;
    }

    // Identifiers, Types, Attributes & Keywords
    if (/[a-zA-Z_\$]/.test(char)) {
      let word = '';
      let j = i;
      while (j < len && /[a-zA-Z0-9_\$]/.test(line[j])) {
        word += line[j];
        j++;
      }

      // Check if followed by ( => function
      let isFunc = false;
      let k = j;
      while (k < len && (line[k] === ' ' || line[k] === '\t')) k++;
      if (k < len && line[k] === '(') {
        isFunc = true;
      }

      // Check if attribute in HTML/JSX (e.g. followed by =)
      let isAttr = false;
      if (k < len && line[k] === '=') {
        isAttr = true;
      }

      const types = TYPES_BY_LANG[language] || TYPES_BY_LANG['typescript'];
      const lowerWord = word.toLowerCase();

      if (keywords && (keywords.has(word) || (language === 'sql' && keywords.has(lowerWord)))) {
        tokens.push({ text: word, type: 'keyword' });
      } else if (types && types.has(word)) {
        tokens.push({ text: word, type: 'type' });
      } else if (isFunc) {
        tokens.push({ text: word, type: 'function' });
      } else if (isAttr) {
        tokens.push({ text: word, type: 'attr' });
      } else if (language === 'css' && (word.startsWith('--') || line.indexOf(':') > j - 1)) {
        tokens.push({ text: word, type: 'attr' });
      } else if (/^[A-Z][a-zA-Z0-9]*$/.test(word) && (language === 'typescript' || language === 'javascript' || language === 'java' || language === 'kotlin')) {
        tokens.push({ text: word, type: 'type' });
      } else {
        tokens.push({ text: word, type: 'identifier' });
      }
      i = j;
      continue;
    }

    // Multi-char operators like =>, ===, !==, <=, >=, &&, ||, ++, --, ->
    if (i + 1 < len) {
      const twoChar = line.slice(i, i + 2);
      const threeChar = i + 2 < len ? line.slice(i, i + 3) : '';
      if (threeChar === '===' || threeChar === '!==' || threeChar === '...') {
        tokens.push({ text: threeChar, type: 'operator' });
        i += 3;
        continue;
      }
      if (['=>', '->', '==', '!=', '<=', '>=', '&&', '||', '++', '--', '+=', '-=', '*=', '/=', '??'].includes(twoChar)) {
        tokens.push({ text: twoChar, type: 'operator' });
        i += 2;
        continue;
      }
    }

    // Operators & Punctuation
    if (/[\{\}\(\)\[\]]/.test(char)) {
      tokens.push({ text: char, type: 'punctuation' });
      i++;
      continue;
    }

    if (/[\+\-\*\/%=\<\>\&\|\!\?\:\;\,\.]/.test(char)) {
      tokens.push({ text: char, type: 'operator' });
      i++;
      continue;
    }

    // Plain characters (spaces, etc.)
    tokens.push({ text: char, type: 'plain' });
    i++;
  }

  return tokens;
}
