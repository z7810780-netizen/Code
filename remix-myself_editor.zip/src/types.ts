export interface EditorFile {
  id: string;
  name: string;
  path: string;
  content: string;
  language: string;
  isModified?: boolean;
  isReadOnly?: boolean;
  encoding?: string;
  lineEnding?: 'LF' | 'CRLF';
  fileHandle?: any;
  dirHandle?: any;
  isSyncedLocal?: boolean;
}

export interface FolderNode {
  id: string;
  name: string;
  path: string;
  isOpen?: boolean;
  children: (FolderNode | EditorFile)[];
}

export interface EditorTab {
  fileId: string;
  title: string;
  path: string;
  isModified: boolean;
}

export type EditorTheme =
  | 'sophisticated-dark'
  | 'sophisticated-light'
  | 'vs-dark'
  | 'dracula'
  | 'monokai'
  | 'nord'
  | 'github-dark'
  | 'one-dark'
  | 'github-light'
  | 'solarized-light';

export interface EditorSettings {
  theme: EditorTheme;
  fontSize: number;
  fontFamily: string;
  tabSize: number;
  useSpaces: boolean;
  wordWrap: boolean;
  autoCloseBrackets: boolean;
  autoCloseQuotes: boolean;
  autoIndent: boolean;
  showLineNumbers: boolean;
  highlightActiveLine: boolean;
  showWhitespace: boolean;
  autoSave: boolean;
  autoSaveDelay: number;
  defaultLineEnding: 'LF' | 'CRLF';
  defaultEncoding: string;
  showMinimap: boolean;
}

export interface SearchState {
  isOpen: boolean;
  query: string;
  replaceQuery: string;
  caseSensitive: boolean;
  matchWholeWord: boolean;
  useRegex: boolean;
  searchInSelection: boolean;
  showReplace: boolean;
  matchesCount: number;
  currentMatchIndex: number;
}

export interface TerminalOutput {
  id: string;
  type: 'command' | 'stdout' | 'stderr' | 'system';
  text: string;
  timestamp: string;
}
