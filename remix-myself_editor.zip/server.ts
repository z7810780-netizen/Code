import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { exec } from 'child_process';
import * as archiverModule from 'archiver';
const archiver = (archiverModule as any).default || archiverModule;
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // API to compile and export the web app for InfinityFree
  app.post('/api/export-web', async (req, res) => {
    try {
      const customFiles = req.body.files;
      console.log('Building React app for InfinityFree export...');

      exec('npm run build', (error, stdout, stderr) => {
        if (error) {
          console.error('Build failed:', error);
          return res.status(500).json({ error: 'Build failed' });
        }

        console.log('Build complete. Injecting custom workspace files...');
        
        const distPath = path.resolve(process.cwd(), 'dist');
        const indexPath = path.join(distPath, 'index.html');
        
        if (fs.existsSync(indexPath)) {
          let indexHtml = fs.readFileSync(indexPath, 'utf-8');
          if (customFiles && customFiles.length > 0) {
            // Inject current workspace files directly into the compiled index.html
            const injectedScript = `<script>window.__INITIAL_FILES__ = ${JSON.stringify(customFiles).replace(/<\/script>/g, '<\\/script>')};</script>`;
            indexHtml = indexHtml.replace('</head>', `${injectedScript}</head>`);
            fs.writeFileSync(indexPath, indexHtml);
          }
        }

        console.log('Zipping dist folder for download...');
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', 'attachment; filename=MYself_EDITOR_Web.zip');

        const archive = archiver('zip', { zlib: { level: 9 } });
        archive.on('error', (err) => {
          console.error('Archive error:', err);
          if (!res.headersSent) res.status(500).send('Archive error');
        });

        archive.pipe(res);
        
        // Add compiled Vite build
        archive.directory(distPath, false);
        
        // Add InfinityFree Apache specific .htaccess and instructions
        const htaccess = `# =============================================================\n# InfinityFree / Apache Server Configuration - MYself_EDITOR\n# =============================================================\n\nDirectoryIndex index.html index.php\nOptions -Indexes\nAddDefaultCharset UTF-8\n\n<IfModule mod_mime.c>\n  AddType text/html .html .htm\n  AddType text/css .css\n  AddType application/javascript .js .mjs\n</IfModule>\n`;
        archive.append(htaccess, { name: '.htaccess' });
        
        const instructions = `========================================================================\nMYself_EDITOR - InfinityFree 1-Click Web Hosting Guide\n========================================================================\n\nSTEP 1: Log in to InfinityFree Control Panel -> Online File Manager.\nSTEP 2: Open your 'htdocs' folder.\nSTEP 3: Upload all files extracted from this ZIP directly into 'htdocs'.\nSTEP 4: Open your website! It runs fully offline with your themes, settings, and full logic.\n========================================================================`;
        archive.append(instructions, { name: 'HOW_TO_HOST.txt' });
        
        archive.finalize();
      });
    } catch (err) {
      console.error(err);
      res.status(500).send('Server error');
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
